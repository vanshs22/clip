# clipper

Give an AI agent (or yourself) a video URL, a local file or a live stream. Get back finished 1080x1920 clips: highlights found with local signals (speech, audio, motion, chat), cut on complete thoughts, captioned, rendered, reviewed by an automatic editor-critic, quality-checked and exported.

```bash
clipper run "https://youtu.be/…" --clips 10 --export out/          # recorded video, one command
clipper watch "https://www.twitch.tv/…" --clips 10 --out live/     # livestream: records, finalizes by itself, exports
```

No paid service is required. The core is the Python standard library plus an ffmpeg binary; every AI model is optional and downloaded only when you ask. There is no API key anywhere: the model in your IDE scores the candidates (`clipper judge`), writes caption edits and recommends layouts, which you approve.

* **Start here: [SETUP.md](SETUP.md)** (install, first run, livestreams, agents). Install details: [INSTALLATION.md](INSTALLATION.md) (Windows 11 first). Use from an agent: [SKILL.md](SKILL.md), [docs/MCP.md](docs/MCP.md).
* How it works: [ARCHITECTURE.md](ARCHITECTURE.md). Choices and licences: [TECH_STACK.md](TECH_STACK.md), [THIRD_PARTY.md](THIRD_PARTY.md). Problems: [TROUBLESHOOTING.md](TROUBLESHOOTING.md).
* What was actually tested, and what was not: [docs/VALIDATION.md](docs/VALIDATION.md) and [docs/SPEC.md](docs/SPEC.md). Security: [SECURITY.md](SECURITY.md). Changes: [CHANGELOG.md](CHANGELOG.md).

**Honest scope.** Tested on interviews, panels and podcast-style conversation and on constructed media. There is no human-labelled gaming, sports, comedy or IRL footage in this repo, so quality claims there are untested. Twitch/Kick VOD chat and Kick live chat use unofficial public endpoints, were exercised against the real sites, and `clipper doctor --chat` tells you if one changes; YouTube live chat and RTMP ingest were tested with mocks/local streams only. Not tested: a real GPU encoder and a real multi-hour VOD download+render (see CHANGELOG).
