import React from 'react';
import {AbsoluteFill, Composition, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';

// Transparent 1080x1920 overlays for clipper (`clipper edit JOB N --overlay out/stat.webm@4.5:2.5`).
// No background is painted, so the render keeps its alpha channel. Fonts: system sans; swap in @remotion/google-fonts if you want Anton etc.
const font = 'Impact, "Arial Black", Helvetica, sans-serif';
const ACCENT = '#FFE500';

const usePop = (delay = 0) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: f - delay, fps, config: {damping: 12, mass: 0.6}});
};
const useFadeOut = (tail = 6) => {
  const f = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  return interpolate(f, [durationInFrames - tail, durationInFrames], [1, 0], {extrapolateLeft: 'clamp'});
};

// Big number / keyword with a slam-in. props: text, sub
export const StatCallout: React.FC<{text: string; sub?: string}> = ({text, sub}) => {
  const s = usePop();
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', opacity: useFadeOut()}}>
      <div style={{transform: `scale(${0.4 + 0.6 * s})`, textAlign: 'center', fontFamily: font}}>
        <div style={{fontSize: 210, color: '#fff', WebkitTextStroke: '12px #000', paintOrder: 'stroke fill', textShadow: '0 10px 0 #000'}}>{text}</div>
        {sub ? <div style={{fontSize: 70, color: ACCENT, WebkitTextStroke: '6px #000', paintOrder: 'stroke fill'}}>{sub}</div> : null}
      </div>
    </AbsoluteFill>
  );
};

// Name / topic tag sliding in from the left. props: title, subtitle
export const LowerThird: React.FC<{title: string; subtitle?: string}> = ({title, subtitle}) => {
  const s = usePop();
  return (
    <AbsoluteFill style={{opacity: useFadeOut()}}>
      <div style={{position: 'absolute', left: 60, top: 1180, transform: `translateX(${(1 - s) * -700}px)`, fontFamily: font}}>
        <div style={{background: ACCENT, color: '#000', fontSize: 64, padding: '10px 28px', display: 'inline-block'}}>{title}</div>
        {subtitle ? <div style={{background: '#000', color: '#fff', fontSize: 40, padding: '8px 28px', marginTop: 4, display: 'inline-block'}}>{subtitle}</div> : null}
      </div>
    </AbsoluteFill>
  );
};

// Explainer cards: bullets pop in one after another (use over b-roll or a still for non-podcast topics). props: heading, bullets[]
export const Explainer: React.FC<{heading: string; bullets: string[]}> = ({heading, bullets}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <AbsoluteFill style={{justifyContent: 'flex-start', alignItems: 'center', paddingTop: 260, opacity: useFadeOut()}}>
      <div style={{fontFamily: font, width: 920, background: 'rgba(0,0,0,0.72)', borderRadius: 32, padding: 44, borderLeft: `14px solid ${ACCENT}`}}>
        <div style={{color: ACCENT, fontSize: 68, marginBottom: 20}}>{heading}</div>
        {bullets.map((b, i) => {
          const p = spring({frame: f - 8 - i * 12, fps, config: {damping: 14}});
          return <div key={i} style={{color: '#fff', fontSize: 52, margin: '14px 0', opacity: p, transform: `translateX(${(1 - p) * 60}px)`}}>• {b}</div>;
        })}
      </div>
    </AbsoluteFill>
  );
};

// Animated bar chart. props: title, items[{label,value}]
export const BarChart: React.FC<{title: string; items: {label: string; value: number}[]}> = ({title, items}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const max = Math.max(...items.map((i) => i.value), 1);
  return (
    <AbsoluteFill style={{paddingTop: 300, alignItems: 'center', opacity: useFadeOut()}}>
      <div style={{fontFamily: font, width: 920, background: 'rgba(0,0,0,0.72)', borderRadius: 32, padding: 44}}>
        <div style={{color: '#fff', fontSize: 56, marginBottom: 24}}>{title}</div>
        {items.map((it, i) => {
          const p = spring({frame: f - 6 - i * 8, fps, config: {damping: 16}});
          return (
            <div key={i} style={{margin: '16px 0'}}>
              <div style={{color: '#fff', fontSize: 38}}>{it.label} <b style={{color: ACCENT}}>{it.value}</b></div>
              <div style={{height: 38, width: `${(it.value / max) * 100 * p}%`, background: ACCENT, borderRadius: 8}} />
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

export const Root: React.FC = () => (
  <>
    <Composition id="StatCallout" component={StatCallout} width={1080} height={1920} fps={30} durationInFrames={75} defaultProps={{text: '$10M', sub: 'in one year'}} />
    <Composition id="LowerThird" component={LowerThird} width={1080} height={1920} fps={30} durationInFrames={90} defaultProps={{title: 'DR. SMITH', subtitle: 'Food scientist'}} />
    <Composition id="Explainer" component={Explainer} width={1080} height={1920} fps={30} durationInFrames={150} defaultProps={{heading: 'Why it matters', bullets: ['Cheaper than whey', 'Lab-tested', 'Check the label']}} />
    <Composition id="BarChart" component={BarChart} width={1080} height={1920} fps={30} durationInFrames={120} defaultProps={{title: 'Protein per Rs 100', items: [{label: 'Egg', value: 18}, {label: 'Whey', value: 12}, {label: 'Plant', value: 9}]}} />
  </>
);
