#!/usr/bin/env bash
# ./render.sh <CompositionId> <out.webm> '<json props>'  -> transparent VP9 for `clipper edit JOB N --overlay out.webm@SECONDS:DURATION`
set -e
cd "$(dirname "$0")"
[ -d node_modules ] || npm install --no-audit --no-fund
npx remotion render src/index.ts "$1" "$2" --codec=vp9 --pixel-format=yuva420p --image-format=png --props="${3:-{\}}" --log=error
