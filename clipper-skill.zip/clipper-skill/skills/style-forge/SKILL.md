---
name: style-forge
description: Create, copy and verify edit styles for clipper (viral looks for shorts: pacing, zoom, captions, grade, sound effects, music). Use when the user wants a new look, wants to imitate a reference video, or an existing style does not fit the content. A style may only be used after it passes `clipper style verify`; never claim a style works without the verification output and a look at its contact sheet.
---

# style-forge

A **style pack** is one JSON file: the edit's pacing, zoom, captions, colour grade, sound effects and music. Shipped: `comedy storytime motivation news reaction` (in `clipper/styles/`). Yours go to `~/.clipper/styles/` (or `$CLIPPER_STYLES`).

## Choose, do not invent, when you can
`clipper style list`, read each pack's `when` line, pick the closest. Build a new one only when none fits or the user shows a reference.

| content | start from |
|---|---|
| stand-up, banter, roasts | `comedy` |
| a story with tension, confessions, true crime | `storytime` |
| speeches, coaching, advice | `motivation` |
| explainers, finance, news commentary | `news` |
| reactions, streamers, sports | `reaction` |
| two people talking | built-in `podcast` (stacked, waveform) |
| gameplay + facecam | built-in `gamer` |

## Workflow (every step is a command; do not skip the last two)
1. **Scaffold** `clipper style new NAME --extends viral` (or `from-reference`, below).
2. **Edit** the JSON. Only these keys exist under `edit`; a typo is an error, not a no-op:

| key | range | what it does |
|---|---|---|
| `gap` | null or 0.15-1.5 | silence longer than this is cut (null keeps every pause: cinematic/gaming) |
| `zoom` | [1.0, up to 1.3] x 1-3 | wide/tight levels alternated at every cut; capped by source height anyway |
| `emph` | 1.0-1.3 | snap-zoom on the payoff word (1.0 = off) |
| `hook`, `callouts`, `progress`, `flash`, `wave`, `coldopen` | bool | headline, number callouts, progress bar, white flash on cuts, voice waveform on a seam, strongest-phrase-first opening |
| `sfx` | 1.5-12 | minimum seconds between sound effects (lower = busier) |
| `music_db` | -32..-16 | music under speech |
| `mood` | chill upbeat tense epic funny inspire | bed character |
| `caps` | preset name or a dict of caption keys | `font` (Poppins ExtraBold/Bold/Medium, Anton, Bebas Neue), `size` (em: 60-110), `hi` (highlight, ASS colour `&H00BBGGRR`), `outline`, `shadow`, `words` (per line, 3-5), `upper`, `anim` (pop/fade/none), `mode` (pop/karaoke/plain/speaker), `border` (3 = box) |
| `grade` | one ffmpeg filter chain | `eq`, `colorbalance`, `vignette`, `curves`; no `;` `|` quotes |

3. **Verify** `clipper style verify NAME`. It renders a synthetic clip through the real studio and checks: schema, the grade runs, studio render (no fallback), 1080x1920 with audio, QC clean, effects not spammy, captions inside the safe zone and >= 48 px tall, loudness -14 +/- 3 LUFS, peak <= -1 dB, no clipped samples. FAIL lines name the number. Fix and rerun. (Example: `storytime` first failed because 66-px captions rendered 46 px tall.)
4. **Look** at `style_verify/NAME.png`: captions readable at thumbnail size, nothing on the hook box, colours as intended.
5. **Approve** `clipper style approve NAME --note "<what you saw, >= 8 words>"`. The note is recorded; "looks good" is rejected.
6. **Try it on real footage** `clipper run SRC --clips 2 --edit NAME --export out/`, then `clipper critique JOB --packet` and look at the frames. A style that passes synthetic checks can still look wrong on a face-heavy shot: only footage settles that.
Editing a verified pack changes its hash and it stops loading until verified again.

## Copy a reference video
`clipper style from-reference REF.mp4 NAME [--dir DIR]` writes a pack and prints the evidence. Measured: cuts/min and median shot length (pacing -> `gap`, `zoom`, `emph`, `sfx`, `flash`), pause rate, loudness and the level of the quietest moments relative to speech (a lifted floor means music -> `music_db`), saturation/contrast/warmth/vignette (-> `grade`), where captions sit, how tall they are and their highlight colour (-> `caps`), stacked/facecam/single layout (-> `extends`). Check each number against the clip yourself: the caption detector reports a confidence (< 0.3 = ignored). It does not copy fonts it cannot identify, music tracks, or the editing of a specific moment. Then run steps 3-6.
Only use references you may analyse; the pack stores measurements, not the video.

## Sound design rules (the verifier enforces the numbers)
- An effect marks something the viewer SEES: headline pop, topic cut, snap zoom, number callout. If you cannot name the visual event, no effect.
- Hits land on the cue, whooshes after the cut, risers end on it. Do not hand-place effects: `clipper edit --sfx-gain -3` lowers them, `--no-sfx` removes them.
- Music: at most one bed per clip, 16+ dB under speech, never over a punchline pause. Mood from the content (funny/tense/epic/chill/upbeat/inspire). Own tracks: `--music-dir`.
- Sound can only be measured here, not heard. Say so.

## Typography rules
Captions 3-4% of frame height, 3-4 words a line for fast styles, 5-6 for calm ones, max two lines. Bottom edge 420 px or more above the bottom, never over the eyes or mouth (the `placement` critic moves them with `--caption-y`). Highlight colour contrasts with the grade; one highlight colour per style. Hook headline: 3 s, at most 17 characters a line, never on a face (critic `hook_over_face`).
