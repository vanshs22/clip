---
name: clipper-remotion-graphics
description: Add animated graphics (stat callouts, lower thirds, explainer bullet cards, bar charts) over a clipper clip using Remotion. Use for explainer, educational or topic-driven videos where captions and cuts alone are not enough.
---

# Remotion graphics for clipper

Clipper's own overlays (hook headline, number callouts, progress bar, captions) are libass text and need nothing extra. Use Remotion when the clip needs a real motion graphic: a chart, a bulleted explainer card, a name tag, an animated stat.

1. **Learn Remotion's rules first.** `npx skills add remotion-dev/skills` (the official agent skills: https://github.com/remotion-dev/skills). Read its `remotion-best-practices` before writing new compositions. Remotion needs a licence for companies above its free-tier limits: tell the user.
2. **Use the template** in `remotion/` (compositions `StatCallout`, `LowerThird`, `Explainer`, `BarChart`, all 1080x1920, 30 fps, transparent). Add a composition in `remotion/src/Root.tsx` for anything new. Never paint a full-frame background: it kills the alpha.
3. **Render with alpha:** `remotion/render.sh StatCallout out/stat.webm '{"text":"50%","sub":"lost in fees"}'` (first run does `npm install` and downloads a headless browser). Output is VP9 with alpha.
4. **Composite:** `clipper edit JOB 3 --overlay out/stat.webm@6.5:2.5:0` (FILE@start_seconds:duration:y_offset, seconds are in the EDITED clip's timeline; `clipper status JOB` shows each clip's `studio.callouts`). Then `clipper render JOB`. Keep graphics out of the caption band (captions sit at about y=1450, or at the seam y=960 in the stacked layout) and the top 250 px (platform UI).
5. **Look at one frame** of the render before reporting. A graphic over a face or over the captions is a defect.

Verified here: render + composite with alpha. Not verified: Remotion on machines older than glibc 2.35 may refuse to render video (it printed that warning in the sandbox yet still wrote the file); use the Studio (`npm run studio`) or a newer OS if it fails.
