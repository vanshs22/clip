"""Pure helpers for reframing and b-roll. Detectors (YOLO/Haar) live in render.py; everything here is testable without models."""
import re
from pathlib import Path
from .util import median

MEDIA = {".png", ".jpg", ".jpeg", ".webp", ".mp4", ".mov", ".mkv", ".webm"}


def smooth_track(samples, dead=0.08, ramp=0.8):
    """samples: [(t, x|None)] inside ONE shot, t clip-relative. -> keyframes [(t, x)].
    Median-of-3 de-noising, then hysteresis: hold still until the subject leaves a dead zone around the crop,
    then glide to the new position over `ramp` s. Natural framing beats constant camera movement."""
    pts = [(t, x) for t, x in samples if x is not None]
    if not pts:
        return [(samples[0][0] if samples else 0.0, 0.5)]
    xs = [median([pts[max(0, i - 1)][1], pts[i][1], pts[min(len(pts) - 1, i + 1)][1]]) for i in range(len(pts))]
    kf, cur = [(pts[0][0], xs[0])], xs[0]
    for (t, _), x in zip(pts[1:], xs[1:]):
        if abs(x - cur) > dead:
            if kf[-1][0] < t:
                kf.append((t, cur))
            kf.append((t + ramp, x))
            cur = x
    return [(round(t, 2), round(x, 3)) for t, x in kf]


def pair_of(samples, min_gap=0.25, share=0.6):
    """samples: [[(x, size), ...] per sampled frame]. Two people persistently apart -> (left_x, right_x), else None."""
    pairs = []
    for fr in samples:
        top = sorted(sorted(fr, key=lambda d: -d[1])[:2], key=lambda d: d[0])
        if len(top) == 2 and top[1][0] - top[0][0] >= min_gap:
            pairs.append((top[0][0], top[1][0]))
    if not samples or len(pairs) / len(samples) < share:
        return None
    return round(median([p[0] for p in pairs]), 3), round(median([p[1] for p in pairs]), 3)


def match_broll(words, folder, clip_start, clip_end, max_n=3, dur=2.0, gap=6.0):
    """Keyword match between file names (pizza.png, golden_goal.mp4) and spoken words. Returns [{"file","t","dur"}], t clip-relative."""
    files = [p for p in sorted(Path(folder).iterdir()) if p.suffix.lower() in MEDIA]
    out = []
    for p in files:
        key = {k for k in re.split(r"[_\-\s]+", p.stem.lower()) if len(k) >= 4}
        hit = next((w for w in words if clip_start <= w["s"] <= clip_end - dur - 0.5 and re.sub(r"\W", "", w["w"].lower()) in key), None)
        if hit:
            out.append({"file": str(p.resolve()), "t": round(hit["s"] - clip_start, 2), "dur": dur})
    out.sort(key=lambda b: b["t"])
    keep = []
    for b in out:  # spacing: b-roll is seasoning
        if not keep or b["t"] - keep[-1]["t"] >= gap:
            keep.append(b)
    return keep[:max_n]


def frame_strip(src, start, end, out, n=4, h=360, label=None):
    """n evenly spaced frames of [start, end] side by side in one PNG (what a model can look at to judge a speech-free or gaming moment). -> path or None.
    label: text burned into the top-left corner (the candidate key + times). Images carry no name of their own and a model that opens several at once can get
    them back in a different order than it asked for: it happened (two candidates were judged from each other's pictures), so the picture says what it is."""
    from .util import ffmpeg, run
    from . import captions
    ts = [start + (end - start) * (k + .5) / n for k in range(n)]
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    cmd = [ffmpeg(), "-hide_banner", "-y", "-v", "error"]
    for t in ts:
        cmd += ["-ss", f"{t:.2f}", "-i", str(src)]
    fl = "".join(f"[{i}:v]scale=-2:{h}[f{i}];" for i in range(n)) + "".join(f"[f{i}]" for i in range(n)) + f"hstack=inputs={n}"
    if label:
        font = str(captions.FONTS / "Poppins-Bold.ttf").replace("\\", "/").replace(":", "\\:")
        txt = "".join(ch for ch in str(label) if ch.isalnum() or ch in " -_.")[:60]  # no characters that mean something to drawtext
        fl += f",drawtext=fontfile='{font}':text='{txt}':x=12:y=12:fontsize={max(18, h // 11)}:fontcolor=white:box=1:boxcolor=black@0.75:boxborderw=8"
    fl += "[o]"
    r = run([*cmd, "-filter_complex", fl, "-map", "[o]", "-frames:v", "1", str(out)], timeout=120)
    return str(out) if r.returncode == 0 and Path(out).exists() else None


def contact_sheets(strips, out_dir, per=5, width=1600):
    """Stack labelled frame strips (each already carries its KEY) into sheets of `per` rows: ONE image to open instead of many, so there is no order to mix up.
    -> [paths]."""
    from .util import ffmpeg, run
    out_dir, paths = Path(out_dir), []
    strips = [s for s in strips if s and Path(s).exists()]
    for k in range(0, len(strips), per):
        grp, dst = strips[k:k + per], out_dir / f"sheet_{k // per + 1}.png"
        cmd = [ffmpeg(), "-hide_banner", "-y", "-v", "error"]
        for p in grp:
            cmd += ["-i", str(p)]
        fl = "".join(f"[{i}:v]scale={width}:-2[s{i}];" for i in range(len(grp))) + "".join(f"[s{i}]" for i in range(len(grp))) + f"vstack=inputs={len(grp)}[o]"
        r = run([*cmd, "-filter_complex", fl, "-map", "[o]", "-frames:v", "1", str(dst)], timeout=120)
        if r.returncode == 0 and dst.exists():
            paths.append(str(dst))
    return paths
