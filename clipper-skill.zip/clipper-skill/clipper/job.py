"""Resumable pipeline. Every stage writes one artifact; a stage whose artifact exists is skipped.
So a crash, a failed render or an edit never repeats download, transcription or analysis."""
import concurrent.futures as cf, os, shutil, time, uuid
from pathlib import Path
from . import chat as chat_mod, ingest, judge, layouts, render as R, score, signals as S, transcribe as T
from .util import check_disk, digest, file_fingerprint, hms, jload, jsave, log_event, note_skipped, pid_alive, probe, skipped, validate_source

FAST_MIN_S = 900  # --fast only matters (and only applies) to sources longer than this
STAGES = ["ingest", "transcribe", "signals", "candidates", "select", "speakers", "render", "qc"]
ART = {"ingest": "source.json", "transcribe": "transcript.json", "signals": "signals.json", "candidates": "candidates.json",
       "select": "plan.json", "speakers": "speakers.json", "render": "render.json", "qc": "report.json"}
DEFAULTS = {"clips": 10, "profile": "auto", "style": "auto", "model": "balanced", "chat": None, "cookies": None,
            "transcript": None, "fast": False, "chat_full": False, "draft": False, "upscale": "auto", "speakers": "auto",
            "quality": "normal", "live_events": None, "style_file": None, "logo": None, "fade": False}
# which options each stage's result depends on. Upstream stages are chained in automatically, so e.g. `clips` (select) invalidates
# select/speakers?/render/qc but never ingest/transcribe/signals/candidates; `style` is only consulted at render time.
STAGE_OPTS = {
    "ingest": ("cookies", "chat_full"), "transcribe": ("model", "transcript", "fast"), "signals": ("chat",),
    "candidates": ("profile", "live_events"),
    "select": ("clips", "upscale"),
    "speakers": ("speakers",), "render": ("draft", "style", "style_file", "logo", "fade", "quality", "upscale"), "qc": ("draft",),
}
DEPS = {"ingest": [], "transcribe": ["ingest"], "signals": ["transcribe"], "candidates": ["signals"], "select": ["candidates"],
        "speakers": ["transcribe", "select"], "render": ["select", "speakers"], "qc": ["render"]}


def source_fingerprint(src):
    """Local file: size + sampled content hash. URL: the URL itself (the downloaded file is fingerprinted at ingest)."""
    p = Path(src)
    return "file:" + file_fingerprint(p) if p.exists() and p.is_file() else "url:" + digest(src)


def _optval(o, k):
    v = o.get(k)
    if k in ("chat", "transcript", "live_events", "style_file", "logo") and v and Path(str(v)).is_file():
        return [str(v), file_fingerprint(v)]  # an edited chat/transcript file must invalidate what depends on it
    return v


class Job:
    def __init__(self, root, jid):
        self.dir = Path(root) / jid
        self.id = jid

    def p(self, *a):
        return self.dir.joinpath(*a)

    @property
    def opts(self):
        return jload(self.p("job.json"), {})

    def log(self, event, **kw):
        log_event(self.p("run.log"), event, job=self.id, **kw)

    def expected_hash(self, st):
        """Hash of everything this stage's output depends on: its options, the source, and the hashes of upstream stages."""
        o = self.opts
        src = jload(self.p("source.json"), {}) if st != "ingest" else {}
        base = o.get("src_fp") if st == "ingest" else src.get("fingerprint")
        if st == "ingest":  # a local file is re-fingerprinted on every run: editing/replacing the file invalidates everything
            base = source_fingerprint(o.get("src", ""))
        extra = file_fingerprint(self.p("judgments.json")) if st == "select" and self.p("judgments.json").exists() else None  # agent scores change the selection
        if st == "transcribe" and o.get("fast"):
            extra = o.get("clips")  # fast mode transcribes ~3x `clips` windows, so the window count is an input there (and only there)
        return digest(st, base, {k: _optval(o, k) for k in STAGE_OPTS[st]}, [self.stored_hash(d) or "?" for d in DEPS[st]], extra, "v5")

    def stored_hash(self, st):
        return (jload(self.p("stages.json"), {}) or {}).get(st)

    def mark(self, st, h):
        d = jload(self.p("stages.json"), {}) or {}
        d[st] = h
        jsave(self.p("stages.json"), d)

    def done(self, st):
        """Artifact exists AND was produced from inputs identical to the current ones (chained through upstream stages)."""
        if not self.p(ART[st]).exists():
            return False
        stored = self.stored_hash(st)
        return bool(stored) and stored == self.expected_hash(st) and all(self.done(d) for d in DEPS[st])

    def invalidate(self, frm):
        """Remove `frm` and every stage that (transitively) depends on it."""
        todo, seen = [frm], set()
        while todo:
            st = todo.pop()
            if st in seen:
                continue
            seen.add(st)
            if st == "select" and self.p(ART[st]).exists():  # keep the user's/model's per-clip edits: _select carries them over to the same clips by key
                shutil.copyfile(self.p(ART[st]), self.p("plan.prev.json"))
            self.p(ART[st]).unlink(missing_ok=True)
            todo += [s for s, d in DEPS.items() if st in d]
        h = jload(self.p("stages.json"), {}) or {}
        for st in seen:
            h.pop(st, None)
        jsave(self.p("stages.json"), h)

    def lock(self):
        """One writer per job: a lock file naming this pid; a stale lock (dead pid) is taken over."""
        lf = self.p("job.lock")
        self.dir.mkdir(parents=True, exist_ok=True)
        for _ in range(2):
            try:
                fd = os.open(lf, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, str(os.getpid()).encode())
                os.close(fd)
                return True
            except FileExistsError:
                try:
                    pid = int(lf.read_text() or 0)
                except (OSError, ValueError):
                    pid = 0
                if pid_alive(pid) and pid != os.getpid():
                    return False
                lf.unlink(missing_ok=True)
        return False

    def unlock(self):
        self.p("job.lock").unlink(missing_ok=True)


def create(src, root, **opts):
    """One job directory per SOURCE content (so the expensive download/transcription is shared by every run on that source); options
    live in job.json and per-stage input hashes decide what is stale. Each run gets its own run_id for the report."""
    src = validate_source(src)
    jid = digest(source_fingerprint(src))[:10]
    j = Job(root, jid)
    # options are NOT inherited from earlier runs on this source: omitted means default (stage hashes keep what is still valid cached)
    new = {**DEFAULTS, "src": src, **{k: v for k, v in opts.items() if v is not None}, "run_id": uuid.uuid4().hex[:12]}
    jsave(j.p("job.json"), new)
    return j


def next_step(j):
    for st in STAGES:
        if not j.done(st):
            return st
    return None


def run_stage(j, st):
    o = j.opts
    t0 = time.time()
    j.log("stage_start", stage=st)
    globals()[f"_{st}"](j, o)
    j.mark(st, j.expected_hash(st))
    if skipped():
        jsave(j.p("features.json"), {**(jload(j.p("features.json"), {}) or {}), **skipped()})
    dt = round(time.time() - t0, 1)
    j.log("stage_done", stage=st, seconds=dt)
    return dt


def run(j, stop_after="qc", log=print):
    """Run stale stages in order. A stage whose inputs changed is re-run (and its downstream with it); finished stages are skipped."""
    if not j.lock():
        raise SystemExit(f"job {j.id} is being processed by another process (job.lock)")
    try:
        while (st := next_step(j)) and STAGES.index(st) <= STAGES.index(stop_after):
            if j.p(ART[st]).exists():  # stale: remove it and everything downstream
                j.invalidate(st)
            log(f"[{st}] ...")
            log(f"[{st}] done in {run_stage(j, st)}s")
    finally:
        j.unlock()
    return next_step(j)


EDIT_KEYS = {"start_shift", "end_shift", "captions", "caption_scale", "zoom", "layout", "focus_x", "drop", "broll_dir", "no_broll", "music",
             "music_db", "audio", "upscale", "interpolate", "zooms_clear", "zoom_add", "logo", "fade", "regions", "pct", "swap", "filler", "hook", "progress",
             "caption_edits", "caption_emoji", "caption_emphasis", "layout_proposal", "layout_approve", "layout_reject", "card"}


def edit_clip(j, cid, ops):
    """The single place clips are modified (CLI, MCP and critic auto-fixes all come here). Invalidates only the render."""
    from . import boundaries as B, extras
    bad = set(ops) - EDIT_KEYS
    if bad:
        raise SystemExit(f"unknown edit op(s): {sorted(bad)}")
    plan, words = jload(j.p("plan.json")), jload(j.p("transcript.json"))["words"]
    c = next((c for c in plan["clips"] if c["id"] == cid), None)
    if c is None:
        raise SystemExit(f"no such clip {cid}")
    if ops.get("start_shift") or ops.get("end_shift"):
        c["focus_auto"] = None  # shots changed
        c["final_start"] = round(max(0.0, c["final_start"] + ops.get("start_shift", 0)), 3)
        c["final_end"] = round(c["final_end"] + ops.get("end_shift", 0), 3)
    if "captions" in ops:
        c["caption"]["style"] = ops["captions"]
    if ops.get("caption_edits") is not None:  # the model's fixes/emphasis/emoji: strict, all-or-nothing, indices must be inside this clip
        from . import captions as CAP
        ed, errs = CAP.validate_edits(ops["caption_edits"], *c["final_words"])
        if errs:
            raise SystemExit("caption edits rejected, nothing applied:\n  " + "\n  ".join(errs))
        cur = c["caption"].setdefault("edits", {})
        for k, v in ed.items():
            cur[k] = {**cur.get(k, {}), **v} if isinstance(v, dict) else sorted({*cur.get(k, []), *v} if k != "emoji" else v, key=lambda x: x if isinstance(x, int) else x["word"])
    if ops.get("caption_edits") == {}:
        c["caption"].pop("edits", None)
    for k, ck in (("caption_emoji", "emoji"), ("caption_emphasis", "emphasis")):
        if k in ops:
            c["caption"][ck] = ops[k]
    if "caption_scale" in ops:
        c["caption"]["scale"] = ops["caption_scale"]
    if "zoom" in ops:
        c["zoom"] = None if ops["zoom"] <= 1 else ops["zoom"]
    if "zoom_add" in ops:
        c.setdefault("zooms", []).append(ops["zoom_add"])
    if ops.get("zooms_clear"):
        c["zooms"] = []
    if ops.get("layout") not in (None, "fill", "fit") and ops["layout"] not in layouts.LAYOUTS:
        raise SystemExit(f"unknown layout {ops['layout']!r}; choose from fill, fit, {', '.join(layouts.LAYOUTS)}")
    if ops.get("layout") in layouts.LAYOUTS:  # the USER decides on multi-region layouts: propose, show the preview, then approve
        raise SystemExit(f"layout {ops['layout']!r} needs the user's approval: clipper layout {j.id} {cid} --propose {ops['layout']} ... (shows a preview), then --approve")
    if ops.get("layout_proposal") is not None:
        pr = ops["layout_proposal"]
        if pr.get("layout") not in layouts.LAYOUTS and pr.get("layout") not in ("fill", "fit"):
            raise SystemExit(f"unknown layout {pr.get('layout')!r}")
        c["layout_proposal"] = {**pr, "status": "proposed"}
    if ops.get("layout_reject"):
        c.pop("layout_proposal", None)
    if ops.get("layout_approve"):
        pr = c.get("layout_proposal")
        if not pr or pr.get("status") != "proposed":
            raise SystemExit("no proposed layout for this clip: clipper layout JOB CLIP --propose NAME ...")
        c["layout"] = pr["layout"]
        for k in ("regions", "pct", "swap", "filler", "card"):
            if pr.get(k) is not None:
                c[k] = pr[k]
        c["layout_proposal"] = {**pr, "status": "approved"}
    if ops.get("layout") in ("fill", "fit"):
        c.pop("layout_proposal", None)
    for k in ("layout", "focus_x", "audio", "upscale", "interpolate", "logo", "fade", "pct", "swap", "progress", "card"):
        if k in ops:
            c[k] = ops[k]
    if "hook" in ops:  # the headline box text ("auto" = the judge's hook_text, else the title). NOT c["hook"]: that is the local hook SCORE the critics read
        c["headline"] = ops["hook"]
    if ops.get("regions"):  # {cam|cam2|game|ui: "x,y,w,h"} fractions of the SOURCE frame
        bad = set(ops["regions"]) - set(layouts.REGIONS)
        if bad:
            raise SystemExit(f"unknown region(s): {sorted(bad)}; use {layouts.REGIONS}")
        try:
            c.setdefault("regions", {}).update({k: layouts.parse_box(v) for k, v in ops["regions"].items()})
        except ValueError as ex:
            raise SystemExit(str(ex))
    if ops.get("filler"):
        if not Path(ops["filler"]).is_file():
            raise SystemExit(f"filler video not found: {ops['filler']}")
        c["filler"] = str(Path(ops["filler"]).resolve())
    if "broll_dir" in ops:
        c["broll"] = extras.match_broll(words, ops["broll_dir"], c["final_start"], c["final_end"])
    if ops.get("no_broll"):
        c["broll"] = []
    if ops.get("music"):
        c["music"] = {"file": str(Path(ops["music"]).resolve()), "db": ops.get("music_db", -22.0)}
    if ops.get("drop"):
        c["dropped"] = True
    ids = [i for i, w in enumerate(words) if w["s"] >= c["final_start"] - 0.05 and w["e"] <= c["final_end"] + 0.05]
    if ids:
        c["final_words"] = [ids[0], ids[-1]]
        c["issues"] = B.validate(words, c)
    jsave(j.p("plan.json"), plan)
    j.invalidate("render")
    return c


# ---- stages -------------------------------------------------------------------------------------------------
def _ingest(j, o):
    check_disk(j.dir, float(os.environ.get("CLIPPER_MIN_FREE_GB", 2)))
    meta = ingest.inspect(o["src"], o["cookies"])
    if meta["state"] == "live":
        raise SystemExit("This source is LIVE. Use `clipper watch <url>` (records, finds moments, finalizes automatically).")
    if meta["state"] in ("auth_required", "unavailable"):
        raise SystemExit(f"{meta['state']}: {meta.get('error')} {meta.get('hint', '')}".strip())
    path = o["src"] if meta["kind"] == "file" else str(ingest.download(o["src"], j.p("media"), o["cookies"]))
    if not path or path == "None" or not Path(path).exists():
        raise SystemExit("download produced no media file")
    info = probe(path)
    if info["duration"] <= 0 or not (info["width"] or info["audio"]):  # a failed download / renamed text file: stop here with a clear reason, not 0 clips and exit 0
        raise SystemExit(f"not a decodable media file (no video/audio stream or zero duration): {path}")
    chat = o["chat"] or next((str(p) for p in j.p("media").glob("*live_chat*")), None) or ingest.fetch_chat(o["src"], j.p("media"), info["duration"], bool(o.get("chat_full")))
    jsave(j.p("source.json"), {"path": str(Path(path).resolve()), "info": info, "meta": {k: v for k, v in meta.items() if k != "heatmap"},
                               "chat": chat, "fingerprint": file_fingerprint(path), "heatmap": meta.get("heatmap")})


def _transcribe(j, o):
    src = jload(j.p("source.json"))
    if o["transcript"]:
        words = T.from_file(o["transcript"])
    else:
        try:
            if o.get("fast") and src["info"]["duration"] > FAST_MIN_S:  # opt-in: only transcribe the windows the cheap signals (audio, chat, motion) point at
                words = T.transcribe_ranges(src["path"], _fast_ranges(src, o), j.p("cache", "whisper"), o["model"])
            else:
                words = T.transcribe(src["path"], src["info"]["duration"], j.p("cache", "whisper"), o["model"])
        except ImportError:
            # degrade, do not abort: audio/visual/chat highlights still work without words (event-only clips, no captions)
            note_skipped("transcription", "faster-whisper not installed: speech-based selection and captions are off (pip install faster-whisper, or pass --transcript)")
            words = []
    jsave(j.p("transcript.json"), {"words": words})


def _fast_ranges(src, o):
    """Windows worth transcribing, from signals that need no transcript: loudness + chat rate (+ motion for video). ~3x the clips wanted, 150 s each."""
    d, path = src["info"]["duration"], src["path"]
    series = []
    if src["info"]["audio"]:
        series.append(S.audio_rms(path, d))
    if src.get("chat"):
        series.append(S.chat_series_covered(ingest.load_chat(src["chat"]), d, chat_mod.load_coverage(src["chat"])))
    if src["info"]["width"]:
        series.append(S.motion_series(path, d))
    from .util import percentile_rank
    sig = [S.box(percentile_rank(x), 20) for x in series if x and any(x)]
    comb = [sum(s[i] for s in sig) for i in range(int(d) + 1)] if sig else [0.0] * (int(d) + 1)
    return T.pick_ranges(comb, d, max(10, 3 * int(o["clips"])))


def _signals(j, o):
    src, words = jload(j.p("source.json")), jload(j.p("transcript.json"))["words"]
    d = src["info"]["duration"]
    chat = ingest.load_chat(src["chat"]) if src.get("chat") else []
    vid = bool(src["info"]["width"])
    has_a = src["info"]["audio"]
    with cf.ThreadPoolExecutor(5) as ex:  # independent ffmpeg/model passes over the same file: run side by side (wall time = the slowest, not the sum)
        f_audio = ex.submit(S.audio_rms, src["path"], d) if has_a else None
        f_vis = ex.submit(S.visual_pass, src["path"], d) if vid else None  # cuts + motion from a single decode
        f_events = ex.submit(S.audio_events, src["path"], d) if has_a else None
        f_ocr = ex.submit(S.ocr_series, src["path"], d) if vid else None
        audio = [x + 90 for x in f_audio.result()] if f_audio else []
        cutd, cuts, motion, detail = f_vis.result() if f_vis else ([], [], [], [])
        visual = S.fuse_visual(motion, cutd) if f_vis else []
        events, ocr = (f_events.result() if f_events else []), (f_ocr.result() if f_ocr else [])
    shift = 0.0
    if chat and audio and chat_mod.load_align(src.get("chat")):  # Kick VOD chat: wall-clock stamps -> measure the real offset against the loudness bursts
        shift, _ = chat_mod.estimate_shift(chat, audio)
        chat = [{**c, "t": c["t"] + shift} for c in chat] if shift else chat
    chat_s, chat_info = S.chat_series_covered(chat, d, chat_mod.load_coverage(src.get("chat")), with_info=True) if chat else ([], {})
    if chat_info is not None and chat:
        chat_info["aligned_shift_s"] = shift
    sig = {"speech": S.text_series(words, d), "audio": audio, "visual": visual, "chat": chat_s, "heat": S.heat_series(src.get("heatmap"), d), "events": events, "ocr": ocr}
    jsave(j.p("signals.json"), {**sig, "cuts": cuts, "detail": detail, "chat_spikes": S.spikes(sig["chat"], min_abs=8) if chat else [], "chat_info": chat_info,
                                "models": [m for m, k in (("PANNs", "events"), ("RapidOCR", "ocr")) if any(sig[k])]})


def _candidates(j, o):
    src, words, sig = jload(j.p("source.json")), jload(j.p("transcript.json"))["words"], jload(j.p("signals.json"))
    d = src["info"]["duration"]
    prof = score.auto_profile(words, d, sig) if o["profile"] == "auto" else o["profile"]
    series = {k: sig.get(k, []) for k in ("speech", "audio", "visual", "chat", "events", "ocr", "heat")}
    cs = score.candidates(words, d, series, prof, cuts=sig.get("cuts"), reaction=sig.get("events"))
    if o.get("live_events") and Path(o["live_events"]).exists():  # candidates found during the stream: same refinement, small evidence bonus
        cs = score.dedupe(sorted(cs + score.live_candidates(words, d, jload(o["live_events"], []), sig.get("cuts")), key=lambda c: -c["score"]))
    flat = [c for c in cs if S.flat_share(sig.get("detail"), c["final_start"], c["final_end"]) >= S.FLAT_SHARE]  # ad breaks, "starting soon", solid/blurred slates are not moments
    cs = [c for c in cs if c not in flat]
    jsave(j.p("candidates.json"), {"candidates": cs, "profile": prof, "dropped_flat": [[round(c["final_start"], 1), round(c["final_end"], 1)] for c in flat]})


def auto_zoom(c, layout):
    """Conservative: at most ONE punch-in, only on a strong clip, on the fused peak, in fill layout. Render drops it if a cut is near."""
    d, t = c["final_end"] - c["final_start"], c["peak"] - c["final_start"] - 0.5
    ok = layout == "fill" and c["score"] >= 0.7 and d >= 15 and 1.5 <= t <= d - 3
    return [{"t": round(t, 2), "dur": 2.0, "amt": 1.12}] if ok else []


CARRY = ("caption", "layout", "regions", "pct", "swap", "filler", "layout_proposal", "headline", "card", "progress", "zoom", "focus_x", "dropped", "broll", "music", "audio", "interpolate", "logo", "fade")


def _select(j, o):
    words, cd = jload(j.p("transcript.json"))["words"], jload(j.p("candidates.json"))
    cs, prof = cd["candidates"], cd.get("profile", o["profile"])
    top, cost = judge.select(words, cs, o["clips"], judge.load(j.p("judgments.json")), reaction=(jload(j.p("signals.json"), {}) or {}).get("events"))
    dur = jload(j.p("source.json"))["info"]["duration"]
    for c in top:  # transcripts can run past the media (rounding, a trimmed file): never plan beyond what exists
        c["final_end"] = round(min(c["final_end"], dur), 3)
        if c["final_end"] - c["final_start"] < 3:
            c["issues"] = list(c.get("issues", [])) + ["clipped_by_media_end"]
    layout = score.PROFILES.get(prof, score.PROFILES["auto"])["layout"]
    clips = [{**c, "id": i + 1, "key": judge.key(c), "caption": {"style": None, "scale": 1.0}, "layout": layout, "zoom": None, "focus_x": None, "upscale": o["upscale"],
              "zooms": auto_zoom(c, layout)} for i, c in enumerate(top)]  # style None = the job default, resolved at render time
    prev = {c.get("key"): c for c in (jload(j.p("plan.prev.json"), {}) or {}).get("clips", []) if c.get("key")}
    for c in clips:  # re-selection (new scores, --clips) must not silently undo what was edited/approved for the same moment
        old = prev.get(c["key"])
        for k in CARRY if old else ():
            if k in old:
                c[k] = old[k]
    jsave(j.p("plan.json"), {"clips": clips, "judging": cost, "profile": prof})


def _speakers(j, o):
    """Whole-video active-speaker map (optional: off for single-speaker sources, gaming/sports, and when models are unavailable)."""
    src, words = jload(j.p("source.json")), jload(j.p("transcript.json"))["words"]
    prof = (jload(j.p("plan.json")) or {}).get("profile", o["profile"])
    spk = {"reliable": False, "reason": "off"}
    if o["speakers"] != "off" and src["info"]["width"] and prof not in ("gaming", "sports"):
        try:
            from . import speaker
            spk = speaker.timeline(src["path"], words, src["info"]["duration"])
        except ImportError as e:
            note_skipped("speaker following", f"opencv/numpy/speechbrain not installed: {e}")
            spk = {"reliable": False, "reason": "not installed"}
        except Exception as e:  # an optional model must never fail the render
            note_skipped("speaker following", f"{type(e).__name__}: {e}")
            spk = {"reliable": False, "reason": "error"}
    jsave(j.p("speakers.json"), spk)


QUALITY = {"draft": {"crf": 28, "preset": "veryfast"}, "normal": {"crf": 20, "preset": "medium"}, "high": {"crf": 17, "preset": "slow"}}


def _render(j, o):
    src, words, plan = jload(j.p("source.json")), jload(j.p("transcript.json"))["words"], jload(j.p("plan.json"))
    cuts = (jload(j.p("signals.json")) or {}).get("cuts", [])
    spk = jload(j.p("speakers.json"))
    ro = {"style": o["style"], "profile": (plan or {}).get("profile") or o.get("profile"), "style_file": o.get("style_file"), "logo": o.get("logo"), "fade": o.get("fade"), "src_fp": src["fingerprint"],
          "quality": QUALITY.get(o.get("quality", "normal"), QUALITY["normal"])}
    out, log = {}, []
    todo = [c for c in plan["clips"] if not c.get("dropped")]

    def one(c):
        try:
            return c["id"], str(R.render_clip(src["path"], c, j.p("renders"), words, src["info"], o["draft"], cuts=cuts, spk=spk, opts=ro)), None
        except RuntimeError as e:
            return c["id"], None, f"clip {c['id']}: {e}"  # one bad clip must not discard the others
    with cf.ThreadPoolExecutor(R.render_workers()) as ex:  # ffmpeg runs as a child process per clip: threads are enough
        for cid, f, err in ex.map(one, todo):
            if f:
                out[cid] = f
            if err:
                log.append(err)
    jsave(j.p("plan.json"), plan)  # framing discovered during render is persisted
    jsave(j.p("render.json"), {"files": out, "errors": log, "draft": o["draft"], "encoder": R.encoder()})


def _qc(j, o):
    plan, ren = jload(j.p("plan.json")), jload(j.p("render.json"))
    rep = {"clips": [], "judging": plan["judging"]}
    for c in plan["clips"]:
        if c.get("dropped"):
            continue
        f = ren["files"].get(str(c["id"]))
        iss = list(c.get("issues", []))
        warns = list(c.get("warn", []))
        if f:
            ri, _, rw = R.qc(f, c, ren["draft"], detail=(jload(j.p("signals.json"), {}) or {}).get("detail"))
            iss += ri
            warns += rw
        else:
            iss.append("render_failed")
        rep["clips"].append({"id": c["id"], "file": f, "start": hms(c["final_start"]), "end": hms(c["final_end"]), "score": c["final_score"],
                             "title": c.get("title", ""), "issues": iss, "warnings": warns, "boundary_quality": c.get("boundary_quality"), "pass": not iss})
    sig, spk = jload(j.p("signals.json"), {}), jload(j.p("speakers.json"), {})
    rep["errors"] = ren["errors"]
    rep["run"] = {"run_id": o.get("run_id"), "profile": plan.get("profile"), "judging": plan["judging"],
                  "local_models": sorted(set(["faster-whisper" if not o.get("transcript") else "(transcript supplied)"] + sig.get("models", []) +
                                             (["YuNet", "SpeechBrain ECAPA"] if spk.get("reliable") else []))),
                  "features_skipped": {**(jload(j.p("features.json"), {}) or {}), **skipped()}, "encoder": ren.get("encoder")}
    jsave(j.p("report.json"), rep)
