"""Royalty-free audio by construction: sound effects and music beds are SYNTHESISED here (numpy), so nothing is downloaded or licensed.
The beds are simple (pad + bass + pluck + drums) and sit 20+ dB under speech; for real tracks pass --music-dir (files named after a mood, e.g. chill_01.mp3).
bed() renders ONE stereo 48 kHz wav per clip: music (looped, ducked by the actual word timeline) + sound effects at exact times."""
import wave
from pathlib import Path

SR = 48000
MOODS = {  # bpm, chord roots/notes (MIDI) per bar, drum pattern, plucks per bar
    "chill":   dict(bpm=76, bars=[(57, 60, 64, 67), (53, 57, 60, 64), (48, 52, 55, 59), (55, 59, 62, 65)], drums="lofi", arp=8),
    "upbeat":  dict(bpm=118, bars=[(60, 64, 67), (55, 59, 62), (57, 60, 64), (53, 57, 60)], drums="four", arp=8),
    "tense":   dict(bpm=92, bars=[(50, 53, 57), (50, 53, 57), (46, 50, 53), (49, 53, 56)], drums="pulse", arp=4),
    "epic":    dict(bpm=100, bars=[(57, 60, 64), (53, 57, 60), (48, 52, 55), (55, 59, 62)], drums="epic", arp=0),
    "funny":   dict(bpm=112, bars=[(60, 64, 67), (65, 69, 72), (67, 71, 74), (60, 64, 67)], drums="bounce", arp=4),
    "inspire": dict(bpm=96, bars=[(60, 64, 67, 71), (57, 60, 64, 67), (53, 57, 60, 64), (55, 59, 62, 65)], drums="soft", arp=8),
}
SFX_DB = {"whoosh": -8, "swipe": -9, "pop": -6, "thud": -7, "riser": -11, "ding": -9, "tick": -12}  # level vs speech (speech is normalised first)
SFX_LEN = {"whoosh": 0.6, "swipe": 0.3, "pop": 0.14, "thud": 0.6, "riser": 1.1, "ding": 0.9, "tick": 0.04}


def _np():
    import numpy as np
    return np


def _hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def _lp_noise(np, n, w0, w1, rng):
    """White noise through a moving average whose window slides w0 -> w1 samples (low -> high cutoff for w0 > w1)."""
    x = rng.standard_normal(n + 400)
    out = np.empty(n)
    for k in range(0, n, 256):
        w = max(1, int(w0 + (w1 - w0) * k / max(1, n)))
        seg = x[k:k + 256 + w]
        out[k:k + 256] = np.convolve(seg, np.ones(w) / w, "valid")[:min(256, n - k)] if len(seg) >= w else 0
    return out / (np.abs(out).max() + 1e-9)


def sfx(kind):
    """-> mono float array, peak ~0.9"""
    np = _np()
    n = int(SFX_LEN[kind] * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(7)
    if kind in ("whoosh", "swipe"):
        x = _lp_noise(np, n, 120, 6, rng) * np.sin(np.pi * np.linspace(0, 1, n)) ** 2
    elif kind == "riser":
        x = (_lp_noise(np, n, 90, 4, rng) * 0.7 + 0.3 * np.sin(2 * np.pi * np.cumsum(180 + 1800 * (t / t[-1]) ** 2) / SR)) * (t / t[-1]) ** 1.7
        x[-int(0.02 * SR):] *= np.linspace(1, 0, int(0.02 * SR))
    elif kind == "pop":
        x = np.sin(2 * np.pi * np.cumsum(900 * np.exp(-t * 14) + 300) / SR) * np.exp(-t * 38)
    elif kind == "thud":
        x = np.sin(2 * np.pi * np.cumsum(150 * np.exp(-t * 9) + 38) / SR) * np.exp(-t * 7) + 0.35 * _lp_noise(np, n, 40, 40, rng) * np.exp(-t * 30)
    elif kind == "ding":
        x = (np.sin(2 * np.pi * 1318 * t) + 0.4 * np.sin(2 * np.pi * 2637 * t) + 0.2 * np.sin(2 * np.pi * 3951 * t)) * np.exp(-t * 5.5)
    else:  # tick
        x = rng.standard_normal(n) * np.exp(-t * 160)
    x[:int(0.002 * SR)] *= np.linspace(0, 1, int(0.002 * SR))
    return 0.9 * x / (np.abs(x).max() + 1e-9)


def _kick(np, n=int(0.28 * SR)):
    t = np.arange(n) / SR
    return np.sin(2 * np.pi * np.cumsum(110 * np.exp(-t * 22) + 45) / SR) * np.exp(-t * 11)


def _hat(np, rng, n=int(0.05 * SR)):
    t = np.arange(n) / SR
    x = rng.standard_normal(n)
    return np.diff(x, prepend=0) * np.exp(-t * 90) * 0.5


def _clap(np, rng, n=int(0.16 * SR)):
    t = np.arange(n) / SR
    return rng.standard_normal(n) * np.exp(-t * 28) * 0.6


def music(mood, seconds):
    """8-bar procedural loop of `mood` tiled to `seconds` -> mono float array, RMS ~0.1."""
    np = _np()
    m = MOODS[mood]
    rng = np.random.default_rng(11)
    beat = 60.0 / m["bpm"]
    bar = int(4 * beat * SR)
    loop = np.zeros(bar * 8)
    def add(buf, at, snd, g=1.0):
        a = int(at)
        if 0 <= a < len(buf):
            seg = snd[:len(buf) - a]
            buf[a:a + len(seg)] += seg * g
    for b in range(8):
        notes = m["bars"][b % len(m["bars"])]
        o = b * bar
        tt = np.arange(bar) / SR
        win = np.sin(np.pi * np.clip(tt / (bar / SR), 0, 1)) ** 0.5  # zero at both bar edges: no clicks at chord changes
        for nt in notes:  # pad: two slightly detuned sines + 2nd harmonic
            f = _hz(nt)
            loop[o:o + bar] += win * 0.11 * (np.sin(2 * np.pi * f * tt) + np.sin(2 * np.pi * f * 1.004 * tt) + 0.3 * np.sin(2 * np.pi * 2 * f * tt))
        root = _hz(notes[0] - 24)
        for hit in (0, 2):  # bass on beats 1 and 3
            n = int(2 * beat * SR)
            tb = np.arange(n) / SR
            add(loop, o + hit * beat * SR, 0.35 * np.sin(2 * np.pi * root * tb) * np.exp(-tb * 2.2) * np.minimum(1, tb * 200))
        if m["arp"]:
            step = 4 * beat / m["arp"]
            for k in range(m["arp"]):
                f = _hz(notes[k % len(notes)] + 12)
                n = int(0.5 * SR)
                tp = np.arange(n) / SR
                add(loop, o + k * step * SR, 0.18 * (np.sin(2 * np.pi * f * tp) + 0.3 * np.sin(4 * np.pi * f * tp)) * np.exp(-tp * 9) * np.minimum(1, tp * 400))
        dr = m["drums"]
        kick, hat, clap = _kick(np), _hat(np, rng), _clap(np, rng)
        for q in range(4):
            if dr in ("four", "epic", "soft") or (dr in ("lofi", "bounce", "pulse") and q in (0, 2)):
                add(loop, o + q * beat * SR, kick, 0.55 if dr != "soft" else 0.3)
            if dr in ("lofi", "four", "epic", "bounce") and q in (1, 3):
                add(loop, o + q * beat * SR, clap, 0.5 if dr != "lofi" else 0.3)
            if dr != "epic":
                add(loop, o + (q + 0.5) * beat * SR, hat, 0.35 if dr == "four" else 0.2)
                if dr == "pulse":
                    add(loop, o + q * beat * SR, hat, 0.3)
    loop = loop / (np.sqrt((loop ** 2).mean()) + 1e-9) * 0.1
    reps = int(seconds * SR // len(loop)) + 1
    return np.tile(loop, reps)[:int(seconds * SR)]


def _duck(np, words, dur, hi_db, lo_db):
    """Per-sample gain: `lo_db` while someone speaks (fast attack), rising to `hi_db` in pauses (slow release)."""
    n10 = int(dur * 100) + 2
    act = np.zeros(n10)
    for w in words:
        act[max(0, int((w["s"] - 0.08) * 100)):max(0, int((w["e"] + 0.18) * 100)) + 1] = 1
    g, cur = np.empty(n10), 1.0
    for i, a in enumerate(act):
        cur += (a - cur) * (0.5 if a > cur else 0.04)
        g[i] = cur
    db = hi_db + (lo_db - hi_db) * g
    return 10 ** (np.interp(np.arange(int(dur * SR)) / SR, np.arange(n10) / 100, db) / 20)


def bed(path, dur, words, mood, music_db, events, music_file=None):
    """Write the clip's audio bed. words: output-timeline words. events: [{"t","kind","db"(optional extra)}]. Returns the path.
    music_file: a user track (looped) instead of the synthesised mood. mood None = sound effects only."""
    np = _np()
    n = int(dur * SR)
    out = np.zeros(n)
    if mood or music_file:
        if music_file:
            raw = _decode(music_file, dur)
            mus = raw / (np.sqrt((raw ** 2).mean()) + 1e-9) * 0.1
        else:
            mus = music(mood, dur)
        mus = mus[:n] if len(mus) >= n else np.pad(mus, (0, n - len(mus)))
        fade = np.minimum(1, np.minimum(np.arange(n) / (0.6 * SR), (n - np.arange(n)) / (1.4 * SR)))
        out += mus * _duck(np, words, dur, music_db + 6, music_db) * fade
    from . import ears
    placed = []
    for ev in events:
        k = ev["kind"]
        tk = ears.take(k, SR)  # earshot bank take with a measured sync point; the built-in synthesis when earshot is unavailable
        if tk:
            s, lead = tk["y"].astype("float64"), tk["align_s"]
            tgt = ev["t"] + (0.04 if k in ("whoosh", "swipe") else 0.0)  # whoosh peaks land just AFTER the cut they announce
        else:
            s, lead, tgt = sfx(k), 0.0, ev["t"]
        a = int(round((tgt - lead) * SR))
        if a < 0:
            s, a = s[-a:], 0
        if a < n:
            seg = s[:n - a]
            out[a:a + len(seg)] += seg * 10 ** ((SFX_DB[k] + ev.get("db", 0) + 6) / 20) * 0.1 * 4
            placed.append({"t": round(ev["t"], 3), "kind": k, "id": tk["id"] if tk else "synth", "point": tk["point"] if tk else "start", "target_t": round(tgt, 3),
                           "at": round(a / SR + lead, 3), "ok": tk["ok"] if tk else True, "warnings": tk["warnings"] if tk else [], "len": round(len(seg) / SR, 3)})
    out = np.tanh(out * 1.2) / 1.2  # soft limit, no hard clipping
    import json
    Path(str(path) + ".sfx.json").write_text(json.dumps(placed))
    pcm = (np.clip(out, -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(2), w.setsampwidth(2), w.setframerate(SR)
        w.writeframes(np.repeat(pcm, 2).tobytes())
    return Path(path)


def _decode(file, dur):
    """User music -> mono float at 48 kHz (looped to `dur`) via ffmpeg."""
    import subprocess
    from .util import ffmpeg
    np = _np()
    r = subprocess.run([ffmpeg(), "-v", "error", "-stream_loop", "-1", "-i", str(file), "-t", f"{dur:.2f}", "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True)
    if r.returncode or not r.stdout:
        raise RuntimeError(f"cannot decode music file {file}")
    return np.frombuffer(r.stdout, dtype="<f4").astype("float64")
