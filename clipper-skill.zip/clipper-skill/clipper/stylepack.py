"""Style packs: an edit style as a JSON file that a human or an AI can write, and that must PASS VERIFICATION before it can be used.
  clipper/styles/*.json (shipped) | ~/.clipper/styles/*.json | $CLIPPER_STYLES/*.json
A pack = {"name", "description", "when", "extends": <builtin or other pack>, "edit": {overrides}, "verified": {...}} (see skills/style-forge/SKILL.md).
`verified` is written ONLY by `clipper style verify`; it holds a hash of the pack's content, so any later edit makes the pack unusable until re-verified.
Verification is measured, not declared: schema ranges, the colour grade runs, a real render of a synthetic clip passes QC, captions sit in the safe zone,
loudness/peak are in range, effects are not spammy. `clipper style approve` records that a human/agent LOOKED at the contact sheet."""
import hashlib, json, os, re, subprocess, tempfile, time
from pathlib import Path
from . import captions, director as D

HERE = Path(__file__).resolve().parent.parent
DIRS = [Path(__file__).resolve().parent / "styles", Path.home() / ".clipper" / "styles"] + ([Path(os.environ["CLIPPER_STYLES"])] if os.environ.get("CLIPPER_STYLES") else [])
GRADE_OK = re.compile(r"^[A-Za-z0-9_=.,:+\-*/()\s]+$")  # no ; or | or quotes: a grade is ONE filter chain and can not open a second graph
# key: (checker, human description). Every style key the director/studio reads is here; a pack may only override these.
RANGES = {
    "gap": (lambda v: v is None or (isinstance(v, (int, float)) and 0.15 <= v <= 1.5), "null (keep every pause) or 0.15-1.5 s of silence cut"),
    "zoom": (lambda v: isinstance(v, list) and 1 <= len(v) <= 3 and v[0] == 1.0 and all(isinstance(z, (int, float)) and 1.0 <= z <= 1.3 for z in v), "list of 1-3 levels, first 1.0, each <= 1.3"),
    "emph": (lambda v: isinstance(v, (int, float)) and 1.0 <= v <= 1.3, "snap-zoom 1.0-1.3"),
    "hook": (lambda v: isinstance(v, bool), "bool"), "callouts": (lambda v: isinstance(v, bool), "bool"), "progress": (lambda v: isinstance(v, bool), "bool"),
    "flash": (lambda v: isinstance(v, bool), "bool"), "wave": (lambda v: isinstance(v, bool), "bool"), "coldopen": (lambda v: isinstance(v, bool), "bool"),
    "sfx": (lambda v: isinstance(v, (int, float)) and 1.5 <= v <= 12, "minimum seconds between sound effects, 1.5-12 (below 1.5 is spam)"),
    "music_db": (lambda v: isinstance(v, (int, float)) and -32 <= v <= -16, "-32..-16 dB under speech (louder buries the words)"),
    "mood": (lambda v: v in ("chill", "upbeat", "tense", "epic", "funny", "inspire"), "chill|upbeat|tense|epic|funny|inspire"),
    "caps": (lambda v: isinstance(v, dict) or v in captions.PRESETS, "a caption preset name or a dict of caption keys"),
    "grade": (lambda v: isinstance(v, str) and bool(GRADE_OK.match(v)) and len(v) < 240, "an ffmpeg video filter chain (eq, colorbalance, vignette, curves...)"),
}


def canon(pack):
    return hashlib.sha256(json.dumps({k: pack.get(k) for k in ("extends", "edit")}, sort_keys=True).encode()).hexdigest()[:16]


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def find(name):
    for d in DIRS:
        f = d / f"{name}.json"
        if f.exists():
            return f
    return None


def resolve(pack, depth=0):
    """-> the full style dict: the base style (a built-in or another pack) with the pack's overrides on top."""
    base = pack.get("extends") or "viral"
    if base in D.BUILTIN:
        b = dict(D.BUILTIN[base])
    elif depth < 3 and find(base):
        b = resolve(_read(find(base)), depth + 1)
    else:
        raise ValueError(f"extends {base!r}: not a built-in style or a pack")
    return {"wave": False, "coldopen": True, **b, **(pack.get("edit") or {})}


def validate(pack):
    """-> list of problems (empty = schema ok). Unknown keys are errors: a typo must not silently do nothing."""
    bad = []
    if not re.fullmatch(r"[a-z][a-z0-9_]{1,23}", str(pack.get("name", ""))):
        bad.append("name: lowercase letters/digits/underscore, 2-24 chars")
    if pack.get("name") in D.BUILTIN:
        bad.append("name: collides with a built-in style")
    for k in ("description", "when"):
        if not str(pack.get(k, "")).strip():
            bad.append(f"{k}: required (what it is / when an agent should pick it)")
    ed = pack.get("edit") or {}
    for k, v in ed.items():
        if k not in RANGES:
            bad.append(f"edit.{k}: unknown key (allowed: {sorted(RANGES)})")
        elif not RANGES[k][0](v):
            bad.append(f"edit.{k}={v!r}: must be {RANGES[k][1]}")
    try:
        full = resolve(pack)
        missing = [k for k in RANGES if k not in full]
        bad += [f"missing {k}" for k in missing]
        if isinstance(full.get("caps"), dict):
            captions.style(full["caps"])
    except (ValueError, KeyError) as e:
        bad.append(str(e))
    return bad


def _synthetic(tmp, style_dict, name):
    """Render a 14 s synthetic clip with this style through the real studio renderer. -> (mp4 path, clip dict, words)."""
    from . import render as R
    from .util import ffmpeg, probe
    src = Path(tmp) / "s.mp4"
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=1280x720:r=25:d=16", "-f", "lavfi", "-i", "sine=f=220:d=16", "-filter_complex",
                    "[1:a]volume=0.35,tremolo=f=3:d=0.7[a]", "-map", "0:v", "-map", "[a]", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(src)], check=True)
    ws, t = [], 0.4
    txt = "this changed everything about how we make money and nobody told us the secret until now so listen closely because it is a million dollar lesson".split()
    for i, w in enumerate(txt):
        ws.append({"w": w, "s": round(t, 3), "e": round(t + 0.3, 3)})
        t += 0.3 + (0.9 if i in (9, 18) else 0.05)
    clip = {"id": 1, "final_start": 0.3, "final_end": min(15.5, ws[-1]["e"] + 0.4), "layout": "fill", "focus_x": 0.5, "title": "Verify this style", "caption": {"style": None, "scale": 1.0}}
    D.STYLES[name] = style_dict  # visible to the renderer for this process only
    out = tempfile.mkdtemp(dir=tmp)
    f = R.render_clip(str(src), clip, out, ws, probe(str(src)), opts={"style": "auto", "edit": name, "profile": "podcast", "src_fp": "verify", "edit_opts": {"style": name}})
    return Path(f), clip, ws


def verify(name, log=print, sheet_dir=None):
    """Run every check; on success write `verified` into the pack file. -> (ok, [results])."""
    f = find(name)
    if not f:
        raise SystemExit(f"no style pack {name!r} in {[str(d) for d in DIRS]}")
    pack = _read(f)
    res = []

    def chk(what, ok, detail=""):
        res.append({"check": what, "ok": bool(ok), "detail": detail})
        log(f"  {'ok  ' if ok else 'FAIL'} {what}{(' - ' + str(detail)) if detail else ''}")
        return ok
    bad = validate(pack)
    if not chk("schema and ranges", not bad, "; ".join(bad)):
        return False, res
    full = resolve(pack)
    from .util import ffmpeg, probe
    from . import placement as PL, critics as C, ears, render as R
    with tempfile.TemporaryDirectory() as tmp:
        g = subprocess.run([ffmpeg(), "-v", "error", "-f", "lavfi", "-i", "testsrc2=s=320x180:d=0.2:r=5", "-vf", full["grade"], "-f", "null", "-"], capture_output=True, text=True)
        if not chk("colour grade runs in ffmpeg", g.returncode == 0, g.stderr.strip()[:120]):
            return False, res
        try:
            mp4, clip, ws = _synthetic(tmp, full, "__verify__")
        except Exception as e:
            chk("synthetic clip renders", False, f"{type(e).__name__}: {e}")
            return False, res
        studio = clip.get("studio") or {}
        chk("rendered by the studio renderer (no fallback to classic)", studio.get("style") == "__verify__", studio.get("style"))
        info = probe(str(mp4))
        chk("1080x1920 with audio", (info["width"], info["height"]) == (1080, 1920) and info["audio"], f"{info['width']}x{info['height']}")
        hard = R.qc(str(mp4), clip)[0]
        chk("render QC has no hard faults", not hard, hard)
        d = info["duration"]
        sfx_n = len(studio.get("sfx") or [])
        chk("sound effects not spammy (<= 1 per 2 s)", sfx_n <= max(2, d / 2), f"{sfx_n} in {d:.0f}s")
        a = PL.analyse(mp4.parent, 1, mp4, d)
        if a:
            chk("captions inside the platform safe zone", a["before"]["unsafe"] == 0, a["before"])
            chk("captions readable (text height >= 48 px of 1920)", a["line_h"] >= 48, a["line_h"])
        else:
            chk("captions rendered", False, "no caption file")
        err = subprocess.run([ffmpeg(), "-hide_banner", "-nostats", "-i", str(mp4), "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
        li, pk = re.findall(r"I:\s+(-?[\d.]+) LUFS", err), re.findall(r"Peak:\s+(-?[\d.]+) dBFS", err)
        chk("loudness -14 +/- 3 LUFS", li and abs(float(li[-1]) + 14) <= 3, li[-1:] )
        chk("true peak <= -1 dBFS", pk and float(pk[-1]) <= -0.9, pk[-1:])
        m = ears.measure(mp4)
        if m:
            chk("no clipped samples (earshot)", not m.get("clipped_samples"), m.get("clipped_samples"))
        if sheet_dir:
            Path(sheet_dir).mkdir(parents=True, exist_ok=True)
            sheet = Path(sheet_dir) / f"{name}.png"
            subprocess.run([ffmpeg(), "-v", "error", "-y", "-i", str(mp4), "-vf", "select='eq(n,10)+eq(n,90)+eq(n,170)+eq(n,260)+eq(n,330)',scale=216:-2,tile=5x1", "-frames:v", "1", str(sheet)])
            log(f"  contact sheet: {sheet} (open it before `clipper style approve`)")
    D.STYLES.pop("__verify__", None)
    ok = all(r["ok"] for r in res)
    pack["verified"] = {"hash": canon(pack), "automatic": ok, "at": time.strftime("%Y-%m-%d %H:%M"), "checks": [r["check"] for r in res if r["ok"]],
                        "visual": (pack.get("verified") or {}).get("visual") if (pack.get("verified") or {}).get("hash") == canon(pack) else None}
    f.write_text(json.dumps(pack, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return ok, res


def approve(name, note):
    """Record that the contact sheet (and ideally a real clip) was LOOKED AT. The note must say what was seen."""
    f = find(name)
    pack = _read(f)
    v = pack.get("verified") or {}
    if v.get("hash") != canon(pack) or not v.get("automatic"):
        raise SystemExit("verify first (`clipper style verify NAME`): the pack changed or never passed")
    if len(note.split()) < 8:
        raise SystemExit("--note must describe what you saw in the frames (>= 8 words): captions, face, colour, anything off")
    v["visual"] = {"note": note, "at": time.strftime("%Y-%m-%d %H:%M")}
    pack["verified"] = v
    f.write_text(json.dumps(pack, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def usable(pack):
    v = pack.get("verified") or {}
    return v.get("automatic") is True and v.get("hash") == canon(pack) and not validate(pack)


def load_all(allow_unverified=False):
    """Add every usable pack to director.STYLES. -> {name: status} for `style list`."""
    seen = {}
    for d in DIRS:
        for f in sorted(d.glob("*.json")) if d.is_dir() else []:
            try:
                pk = _read(f)
                n = pk["name"]
            except (ValueError, KeyError):
                continue
            ok = usable(pk)
            seen[n] = "approved" if ok and (pk["verified"].get("visual")) else "verified" if ok else "UNVERIFIED"
            if ok or allow_unverified:
                try:
                    D.STYLES[n] = resolve(pk)
                except ValueError:
                    seen[n] = "INVALID"
    return seen
