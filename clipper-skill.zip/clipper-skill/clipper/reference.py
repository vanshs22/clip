"""Reference video -> style pack. Measures what a finished short LOOKS and SOUNDS like and writes an (unverified) style pack that imitates it.
Everything is measured with ffmpeg/OpenCV/librosa, nothing is guessed from the file name; each field carries the evidence and a confidence so an agent knows
what to trust. The pack must still pass `clipper style verify`. It imitates PACING, GRADE, CAPTION PLACEMENT/COLOUR, LAYOUT and MUSIC LEVEL, not the content."""
import json, re, subprocess
from pathlib import Path
from .util import ffmpeg, probe, run, median

DEF_MV = 420  # where our captions sit by default (px from the bottom)


def _frames(path, fps, n, w=540):
    import numpy as np
    info = probe(str(path))
    h = int(w * info["height"] / info["width"]) // 2 * 2
    p = subprocess.run([ffmpeg(), "-v", "error", "-i", str(path), "-an", "-vf", f"fps={fps},scale={w}:{h}", "-frames:v", str(n), "-f", "rawvideo", "-pix_fmt", "bgr24", "-"], capture_output=True)
    a = np.frombuffer(p.stdout, dtype=np.uint8)
    k = len(a) // (w * h * 3)
    return a[:k * w * h * 3].reshape(k, h, w, 3), info


def pacing(path, dur):
    """Cuts per minute at 10 fps with a LOW scene threshold: jump cuts inside one camera shot (a punch-in, a removed pause) score only ~0.05-0.2."""
    r = run([ffmpeg(), "-hide_banner", "-nostats", "-i", str(path), "-an", "-t", f"{dur:.1f}", "-vf", "fps=10,scale=160:-2,select='gt(scene,0.06)',showinfo", "-f", "null", "-"])
    cuts = []
    for t in (float(m[1]) for m in re.finditer(r"pts_time:([\d.]+)", r.stderr)):
        if t > 0.5 and (not cuts or t - cuts[-1] >= 0.5):
            cuts.append(round(t, 2))
    shots = [y - x for x, y in zip([0.0] + cuts, cuts + [dur])]
    return {"cuts": len(cuts), "median_shot_s": round(median(shots), 2) if shots else dur, "cuts_per_min": round(len(cuts) * 60 / max(dur, 1), 1)}


def audio(path, dur):
    """Speech pauses, loudness and how loud the room/music is between words (= the bed under speech)."""
    err = run([ffmpeg(), "-hide_banner", "-nostats", "-i", str(path), "-vn", "-af", "silencedetect=noise=-38dB:d=0.12,ebur128=peak=true", "-f", "null", "-"]).stderr
    sil = [float(x) for x in re.findall(r"silence_duration: ([\d.]+)", err)]
    li = re.findall(r"I:\s+(-?[\d.]+) LUFS", err)
    out = {"lufs": float(li[-1]) if li else None, "pauses_over_0.12s": len(sil), "pauses_per_min": round(len(sil) * 60 / max(dur, 1), 1), "longest_pause_s": round(max(sil, default=0), 2)}
    try:
        import numpy as np
        a = np.frombuffer(subprocess.run([ffmpeg(), "-v", "error", "-i", str(path), "-vn", "-ac", "1", "-ar", "16000", "-f", "f32le", "-"], capture_output=True).stdout, dtype=np.float32)
        n = 1600
        k = len(a) // n
        db = 20 * np.log10(np.maximum(np.sqrt((a[:k * n].reshape(k, n) ** 2).mean(1)), 1e-6))
        sp, quiet = float(np.percentile(db, 85)), float(np.percentile(db, 10))
        out["speech_db"], out["between_words_db"] = round(sp, 1), round(quiet, 1)
        out["bed_under_speech_db"] = round(quiet - sp, 1)  # how far the quietest moments sit under speech: a music bed lifts this floor
    except Exception:
        pass
    return out


def grade(frames):
    """Saturation, contrast, warmth and vignette from the frames, as an ffmpeg eq/colorbalance/vignette chain (relative to a neutral picture)."""
    import cv2, numpy as np
    sat, con, wb, vig, lum = [], [], [], [], []
    for f in frames[:: max(1, len(frames) // 24)]:
        hsv = cv2.cvtColor(f, cv2.COLOR_BGR2HSV)
        g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(float)
        sat.append(hsv[..., 1].mean() / 255)
        con.append(g.std() / 255)
        lum.append(g.mean() / 255)
        wb.append((f[..., 2].mean() - f[..., 0].mean()) / 255)  # red minus blue
        h, w = g.shape
        vig.append(g[: h // 5, : w // 5].mean() / max(g[2 * h // 5: 3 * h // 5, 2 * w // 5: 3 * w // 5].mean(), 1))
    s, c, w_, v = float(np.mean(sat)), float(np.mean(con)), float(np.mean(wb)), float(np.mean(vig))
    clampf = lambda x, a, b: max(a, min(b, x))
    parts = [f"eq=contrast={clampf(0.9 + c * 0.45, 1.0, 1.15):.2f}:saturation={clampf(0.6 + s * 1.3, 0.85, 1.3):.2f}"]
    if abs(w_) > 0.05:
        k = clampf(w_ * 0.5, -0.06, 0.06)
        parts.append(f"colorbalance=rs={k:.2f}:bs={-k:.2f}")
    if v < 0.8:
        parts.append("vignette=PI/8")
    return ",".join(parts), {"saturation": round(s, 2), "contrast": round(c, 2), "red_minus_blue": round(w_, 3), "corner_vs_centre": round(v, 2)}


def caption_band(frames):
    """Where text appears and changes: bright, high-gradient pixels whose row profile varies over time (captions change, backgrounds do not)."""
    import cv2, numpy as np
    if len(frames) < 12:
        return None
    frames = frames[8:]  # the first 4 s carry the hook headline, not the captions
    h, w = frames.shape[1:3]
    prof, cols = [], []
    for f in frames:
        g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
        gx = cv2.Sobel(g, cv2.CV_32F, 1, 0)
        m = (np.abs(gx) > 250) & ((g > 190) | (cv2.cvtColor(f, cv2.COLOR_BGR2HSV)[..., 1] > 170))
        prof.append(m.sum(axis=1).astype(float))
        cols.append(m)
    prof = np.array(prof)
    present = (prof > 6).mean(axis=0)  # captions are on screen most of the time; a one-off graphic is not
    var = prof.std(axis=0) * (present > 0.35)
    var[: int(h * 0.12)] = 0
    var[int(h * 0.93):] = 0
    k = 9
    sm = np.convolve(var, np.ones(k) / k, "same")
    y = int(sm.argmax())
    if sm[y] < 3:
        return None
    rows = np.where(sm > sm[y] * 0.35)[0]
    rows = rows[(rows > y - h * 0.08) & (rows < y + h * 0.08)]
    y0, y1 = int(rows.min()), int(rows.max())
    sel = np.zeros((h, w), bool)
    sel[y0:y1 + 1] = np.any(cols, axis=0)[y0:y1 + 1]
    col = None
    ys, xs = np.where(sel)
    if len(ys) > 50:
        pix = []
        for f in frames[:: max(1, len(frames) // 12)]:
            hv = cv2.cvtColor(f, cv2.COLOR_BGR2HSV)
            m = sel & (hv[..., 1] > 150) & (hv[..., 2] > 190)  # a highlight colour is saturated AND bright
            pix.append(f[m])
        pix = np.concatenate(pix) if pix else np.zeros((0, 3))
        if len(pix) > 30:
            b, g_, r = (float(v) for v in np.median(pix, axis=0))
            col = f"&H00{int(b):02X}{int(g_):02X}{int(r):02X}"
    return {"y_centre_frac": round((y0 + y1) / 2 / h, 3), "bottom_frac": round(y1 / h, 3), "height_frac": round((y1 - y0 + 1) / h, 3), "highlight": col, "confidence": round(min(1.0, float(sm[y]) / 20), 2)}


def layout(frames):
    """Stacked two-person (podcast), a corner facecam over gameplay, or a single subject."""
    from . import speaker
    tops = bots = single = corner = n = 0
    for f in frames[:: max(1, len(frames) // 16)]:
        fs = speaker.detect_faces(f, 0.6)
        n += 1
        up, dn = [x for x in fs if x["cy"] < 0.5 and x["size"] > 0.01], [x for x in fs if x["cy"] >= 0.5 and x["size"] > 0.01]
        tops, bots = tops + bool(up), bots + bool(dn)
        single += len(fs) == 1
        corner += any(x["size"] < 0.012 and (x["cx"] < 0.25 or x["cx"] > 0.75) and (x["cy"] < 0.3 or x["cy"] > 0.7) for x in fs)
    n = max(n, 1)
    if tops / n > 0.5 and bots / n > 0.5:
        return "stacked", {"top_face": round(tops / n, 2), "bottom_face": round(bots / n, 2)}
    return ("facecam" if corner / n > 0.4 else "single"), {"single_face": round(single / n, 2), "corner_face": round(corner / n, 2)}


def analyse(path):
    path = Path(path)
    info = probe(str(path))
    dur = min(info["duration"], 120)
    frames, _ = _frames(path, 2, int(dur * 2))
    ev = {"duration_s": round(info["duration"], 1), "size": f"{info['width']}x{info['height']}", "pacing": pacing(path, dur), "audio": audio(path, dur) if info["audio"] else {}}
    ev["grade"], ev["grade_stats"] = grade(frames)
    ev["captions"] = caption_band(frames)
    ev["layout"], ev["layout_stats"] = layout(frames)
    return ev


def make(name, ref, outdir=None):
    """Write an unverified pack imitating `ref`. -> dict(pack path, evidence, notes)."""
    ev = analyse(ref)
    pc, au, cp = ev["pacing"], ev["audio"], ev["captions"]
    shot = pc["median_shot_s"]
    gap = 0.25 if au.get("pauses_per_min", 99) < 6 and shot < 4 else 0.4 if shot < 6 else 0.55  # a reference with almost no audible pauses has had them cut out
    gap = max(0.22, min(0.7, gap))
    hot = pc["cuts_per_min"] > 18
    bed = au.get("bed_under_speech_db")
    music_db = max(-30, min(-17, bed - 6)) if bed is not None and bed > -35 else -24  # a lifted floor means a bed; place ours 6 dB under it
    edit = {"gap": round(gap, 2), "zoom": [1.0, 1.14 if hot else 1.08], "emph": 1.2 if hot else 1.1, "sfx": round(max(2.0, min(7.0, shot * 1.2)), 1),
            "music_db": round(music_db, 0), "grade": ev["grade"], "flash": bool(hot and pc["cuts_per_min"] > 30), "progress": hot}
    notes = []
    caps = {"font": "Poppins ExtraBold", "size": 84, "words": 3, "upper": True, "anim": "pop"}
    if cp and cp["confidence"] >= 0.3:
        from . import captions
        H = 1920
        bottom_px = cp["bottom_frac"] * H
        mv = int(round(H - bottom_px))
        caps["mv"] = max(captions.SAFE_MV, mv) if cp["y_centre_frac"] > 0.6 else mv  # captions that sit mid-frame in the reference stay mid-frame (the seam/centre look)
        caps["size"] = int(max(56, min(110, cp["height_frac"] * H / 0.8)))
        if cp["highlight"]:
            caps["hi"] = cp["highlight"]
        notes.append(f"captions found at y={cp['y_centre_frac']:.2f} of the frame (confidence {cp['confidence']})")
    else:
        notes.append("no caption band found in the reference: kept the default caption look")
    edit["caps"] = caps
    base = {"stacked": "podcast", "facecam": "gamer"}.get(ev["layout"], "hype" if hot else "viral")
    if ev["layout"] in ("stacked", "facecam"):
        notes.append(f"layout {ev['layout']}: the studio picks this automatically from the footage; the pack carries the pacing/caption/grade")
    pack = {"name": name, "description": f"Imitates {Path(ref).name}: {pc['cuts_per_min']} cuts/min, median shot {shot}s, {ev['layout']} layout.", "when": f"Content that should feel like {Path(ref).name}. Measured, not copied: see evidence.",
            "extends": base, "edit": edit, "evidence": ev}
    d = Path(outdir) if outdir else Path.home() / ".clipper" / "styles"
    d.mkdir(parents=True, exist_ok=True)
    f = d / f"{name}.json"
    f.write_text(json.dumps(pack, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return {"pack": str(f), "next": f"clipper style verify {name}", "edit": edit, "notes": notes, "evidence": ev}
