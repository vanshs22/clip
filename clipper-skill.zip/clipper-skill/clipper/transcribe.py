"""Local transcription: faster-whisper, word timestamps, VAD, overlapping chunks, each chunk cached."""
import shutil
from pathlib import Path
from .util import ffmpeg, run, jload, jsave

CHUNK, OVERLAP = 1200, 20  # 20-minute chunks, 20 s overlap


def _model(profile):
    """-> (model, batched pipeline or None). Batched inference (faster-whisper >= 1.1) decodes many speech segments at once and is several times faster than the
    sequential decoder on the same weights; it falls back to the plain model if the installed version has no pipeline."""
    from faster_whisper import WhisperModel
    gpu = bool(shutil.which("nvidia-smi"))
    name = {"light": "small", "balanced": "large-v3-turbo" if gpu else "small", "quality": "large-v3-turbo"}.get(profile, profile)
    m = WhisperModel(name, device="cuda" if gpu else "cpu", compute_type="float16" if gpu else "int8")
    try:
        from faster_whisper import BatchedInferencePipeline
        return m, BatchedInferencePipeline(model=m)
    except ImportError:
        return m, None


def _chunk(mp, src, a, length, wav, language):
    """Transcribe src[a, a+length) -> (words with ABSOLUTE times, detected language)."""
    model, pipe = mp if isinstance(mp, tuple) else (mp, None)
    run([ffmpeg(), "-y", "-hide_banner", "-ss", str(a), "-t", str(length), "-i", src, "-vn", "-ac", "1", "-ar", "16000", wav])
    if pipe is not None:
        segs, info = pipe.transcribe(str(wav), word_timestamps=True, language=language, batch_size=16 if shutil.which("nvidia-smi") else 8)
    else:
        segs, info = model.transcribe(str(wav), word_timestamps=True, vad_filter=True, language=language)
    part = [{"w": w.word.strip(), "s": round(float(a + w.start), 3), "e": round(float(a + w.end), 3), "p": round(float(w.probability), 3)} for s in segs for w in (s.words or []) if w.word.strip()]
    Path(wav).unlink(missing_ok=True)
    return part, (info.language if getattr(info, "language_probability", 0) >= 0.7 else None)


def transcribe(src, duration, cache_dir, profile="balanced", language=None):
    """Return [{"w","s","e","p"}...]. A crash resumes at the first uncached chunk. The language detected on the first confident chunk is reused for the rest
    (saves a detection pass per chunk and stops a music-only chunk flipping the language)."""
    cache_dir, mp, words = Path(cache_dir), None, []
    starts = list(range(0, int(duration), CHUNK))
    cache_dir.mkdir(parents=True, exist_ok=True)
    for k, a in enumerate(starts):
        f = cache_dir / f"chunk_{k:04d}.json"
        part = jload(f)
        if part is None:
            mp = mp or _model(profile)
            part, lang = _chunk(mp, src, a, CHUNK + OVERLAP, cache_dir / "tmp.wav", language)
            language = language or lang
            jsave(f, part)
        lo = a + (OVERLAP / 2 if k else 0)
        hi = a + CHUNK + (OVERLAP / 2 if k + 1 < len(starts) else OVERLAP)
        words += [w for w in part if lo <= w["s"] < hi]  # overlap is only a safety margin; each instant is owned by one chunk
    return words


def transcribe_ranges(src, ranges, cache_dir, profile="balanced", language=None):
    """Fast mode: transcribe only [(start, end)] windows (picked from cheap signals). Cached per window; overlapping windows must be merged by the caller."""
    cache_dir, mp, words = Path(cache_dir), None, []
    cache_dir.mkdir(parents=True, exist_ok=True)
    for a, b in ranges:
        f = cache_dir / f"range_{int(a)}_{int(b)}.json"
        part = jload(f)
        if part is None:
            mp = mp or _model(profile)
            part, lang = _chunk(mp, src, a, b - a, cache_dir / "tmp.wav", language)
            language = language or lang
            jsave(f, part)
        words += part
    return sorted(words, key=lambda w: w["s"])


def pick_ranges(series, duration, n, win=150.0, sep=None):
    """Top-n non-overlapping windows of `win` seconds around the strongest points of a per-second series -> merged, sorted [(a, b)]."""
    sep = sep or win
    order = sorted(range(len(series)), key=lambda i: -series[i])
    picks = []
    for t in order:
        if all(abs(t - u) >= sep for u in picks):
            picks.append(t)
        if len(picks) >= n:
            break
    rs = sorted((max(0.0, t - win / 2), min(float(duration), t + win / 2)) for t in picks)
    merged = []
    for a, b in rs:
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [(a, b) for a, b in merged if b - a >= 5]


def from_file(path):
    """Use an existing transcript: {"words":[...]} or faster-whisper/whisper style segments with words."""
    j = jload(path)
    if isinstance(j, dict) and "words" in j:
        return j["words"]
    ws = [w for s in (j.get("segments", []) if isinstance(j, dict) else j) for w in s.get("words", [])]
    return [{"w": (w.get("word") or w.get("w")).strip(), "s": w.get("start", w.get("s")), "e": w.get("end", w.get("e")), "p": w.get("probability", 1.0)} for w in ws]
