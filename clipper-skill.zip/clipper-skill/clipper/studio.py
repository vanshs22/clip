"""Studio renderer: turns director.plan() into ONE ffmpeg call.
Picture: every segment is its own seek-limited input, cropped from the SOURCE pixels and resampled exactly once (no crop-then-scale-then-zoom chain,
so zooms are never softer than the base shot), then concatenated. Audio: kept ranges with 6 ms edge fades, normalised, mixed with a synthesised bed
(music ducked by the real word timeline + sound effects). Text (hook, callouts, progress bar, captions) is libass, so it is crisp at any zoom.
Segment lengths sit on a 30 fps grid so picture and sound cannot drift."""
import json, os, re, textwrap
from pathlib import Path
from . import captions, director as D, sfxsynth
from .util import digest, ffmpeg, note_skipped, probe, run, sha256_file

W, H = 1080, 1920
VERSION = 4
LAN = "flags=lanczos+accurate_rnd+full_chroma_int"
YELLOW, WHITE = "&H0000E5FF", "&H00FFFFFF"


def _even(x):
    return max(2, int(x) // 2 * 2)


def _box(info, z, aspect):
    """Largest crop of `aspect` (w/h) inside the source, divided by zoom z -> (w, h) even ints."""
    sw, sh = info["width"], info["height"]
    bw, bh = (sh * aspect, sh) if sw / sh >= aspect else (sw, sw / aspect)
    return _even(bw / z), _even(bh / z)


def _crop(info, z, aspect, fx, ybias=0.15):
    cw, ch = _box(info, z, aspect)
    cw, ch = min(cw, info["width"]), min(ch, info["height"])
    x = min(max(fx * info["width"] - cw / 2, 0), info["width"] - cw)
    y0 = (info["height"] - _box(info, 1.0, aspect)[1]) / 2
    y = min(max(y0 + (_box(info, 1.0, aspect)[1] - ch) * ybias, 0), info["height"] - ch)
    return f"crop={cw}:{ch}:{int(x) // 2 * 2}:{int(y) // 2 * 2}"


def _wrap(text, width):
    return r"\N".join(textwrap.wrap(text, width)[:3])


def overlay_ass(p, st, dur):
    """Hook headline, big number callouts and a progress bar, as ASS (animated by libass)."""
    L = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}", "WrapStyle: 2", "ScaledBorderAndShadow: yes", "", "[V4+ Styles]",
         "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
         f"Style: Hook,Anton,76,&H00000000,&H00000000,{YELLOW},&H00000000,0,0,0,0,100,100,1,0,3,20,0,8,64,64,300,1",
         f"Style: Call,Anton,150,{WHITE},{WHITE},&H00000000,&H90000000,0,0,0,0,100,100,2,0,1,10,5,5,60,60,0,1",
         "Style: Bar,Poppins,20,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1",
         "", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text"]
    ev = lambda a, b, sty, txt: L.append(f"Dialogue: 1,{captions._t(a)},{captions._t(b)},{sty},,0,0,0,,{txt}")
    if p["hook"]:
        ev(0.0, min(3.4, dur * 0.35), "Hook", r"{\fad(0,260)\fscx88\fscy88\t(0,170,\fscx100\fscy100)}" + _wrap(captions._clean(p["hook"]).upper(), 17))
    for c in p["callouts"]:
        ev(c["t"], c["t"] + c["dur"], "Call", r"{\pos(540,760)\fscx45\fscy45\t(0,130,\fscx112\fscy112)\t(130,260,\fscx100\fscy100)\fad(0,200)}" + captions._clean(c["text"]))
    if st["progress"]:
        L.append(f"Dialogue: 2,{captions._t(0)},{captions._t(dur)},Bar,,0,0,0,,{{\\an7\\pos(0,1880)\\p1\\c{YELLOW}&\\fscx0\\t(0,{int(dur * 1000)},\\fscx100)}}m 0 0 l 1080 0 1080 12 0 12{{\\p0}}")
    return "\n".join(L) + "\n"


def _pick_music(music_dir, mood, key):
    if not music_dir or not Path(music_dir).is_dir():
        return None
    fs = sorted(f for f in Path(music_dir).iterdir() if f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg", ".flac", ".aac"))
    hit = [f for f in fs if mood and mood in f.stem.lower()] or fs
    return str(hit[key % len(hit)]) if hit else None


def build_graph(p, layout, info, geom, st, sharp, flash_ids, inputs):
    """-> (filter_complex, nseg). inputs: dict with indices {'aud','bed','ovl':[(idx,spec)]}. geom: split pair / facecam rect."""
    N = len(p["segs"])
    fl = []
    for i, sg in enumerate(p["segs"]):
        head = f"[{i}:v]fps=30,setpts=PTS-STARTPTS"
        if sg.get("lay") == "split" or layout == "split":
            g = sg.get("geom") or geom
            a = _crop(info, 1.0, W / (H // 2), g[0], 0.0)
            b = _crop(info, 1.0, W / (H // 2), g[1], 0.0)
            fl.append(f"{head},split[sa{i}][sb{i}];[sa{i}]{a},scale={W}:{H // 2}:{LAN}[ta{i}];[sb{i}]{b},scale={W}:{H // 2}:{LAN}[tb{i}];[ta{i}][tb{i}]vstack,"
                      f"drawbox=x=0:y={H // 2 - 3}:w={W}:h=6:color=white@0.9:t=fill,setsar=1[v{i}]")
        elif layout == "fill":
            fl.append(f"{head},{_crop(info, sg['z'], 9 / 16, sg['x'])},scale={W}:{H}:{LAN},setsar=1[v{i}]")
        else:
            fl.append(f"{head},setsar=1[v{i}]")
    fl.append("".join(f"[v{i}]" for i in range(N)) + f"concat=n={N}:v=1:a=0[vc]")
    cur = "vc"
    if layout == "fit":
        fl.append(f"[{cur}]split[fa][fb];[fa]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=30:5,eq=brightness=-0.1[fbg];"
                  f"[fb]scale={W}:-2:{LAN}[ffg];[fbg][ffg]overlay=(W-w)/2:(H-h)/2[vl]")
        cur = "vl"
    elif layout == "game":
        fx, fy, fw, fh = geom
        cw, ch = _even(fw * info["width"]), _even(fh * info["height"])
        fl.append(f"[{cur}]split=3[ga][gb][gc];[ga]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=30:5,eq=brightness=-0.15[gbg];"
                  f"[gb]scale={W}:-2:{LAN}[ggm];[gc]crop={cw}:{ch}:{_even(fx * info['width'])}:{_even(fy * info['height'])},scale={W}:880:force_original_aspect_ratio=increase:{LAN},crop={W}:880[gcam];"
                  f"[gbg][ggm]overlay=(W-w)/2:230[gt];[gt][gcam]overlay=0:1000[vl]")
        cur = "vl"
    tail = [st["grade"], "unsharp=5:5:0.7:5:5:0.0" if sharp else "unsharp=3:3:0.35:3:3:0.0"]
    for t in p["flashes"]:
        tail.append(f"drawbox=x=0:y=0:w=iw:h=ih:color=white@0.45:t=fill:enable='between(t,{t:.2f},{t + 0.07:.2f})'")
    fl.append(f"[{cur}]{','.join(x for x in tail if x)}[vg]")
    cur = "vg"
    for j, (idx, spec) in enumerate(inputs["ovl"]):
        t, d = spec["t"], spec.get("dur", 3.0)
        fl.append(f"[{idx}:v]format=rgba,setpts=PTS-STARTPTS+{t}/TB,scale={W}:-2[ov{j}];[{cur}][ov{j}]overlay=0:{spec.get('y', 0)}:eof_action=pass:enable='between(t,{t},{t + d})'[vo{j}]")
        cur = f"vo{j}"
    subs = ",".join(f"subtitles={f}:fontsdir=fonts" for f in inputs["ass"])
    fl.append(f"[{cur}]{subs or 'null'}[v]")
    return ";".join(fl)


def audio_graph(p, aud_idx, bed_idx, clean, dur):
    R = p["ranges"]
    fl = []
    if len(R) > 1:
        fl.append(f"[{aud_idx}:a]asplit={len(R)}" + "".join(f"[x{k}]" for k in range(len(R))))
    for k, (a, b) in enumerate(R):
        src = f"[x{k}]" if len(R) > 1 else f"[{aud_idx}:a]"
        d = b - a
        fl.append(f"{src}atrim=start={a:.4f}:end={b:.4f},asetpts=PTS-STARTPTS,afade=t=in:st=0:d=0.006,afade=t=out:st={max(0, d - 0.006):.4f}:d=0.006[r{k}]")
    fl.append("".join(f"[r{k}]" for k in range(len(R))) + f"concat=n={len(R)}:v=0:a=1[am]")
    voice = "highpass=f=80,afftdn=nf=-25," if clean else ""
    base = f"[am]aresample=48000,aformat=channel_layouts=stereo,{voice}"
    edge = f"afade=t=in:st=0:d=0.015,afade=t=out:st={max(0, dur - 0.03):.3f}:d=0.03"
    if bed_idx is None:
        fl.append(f"{base}loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,{edge}[a]")
    else:
        fl.append(f"{base}loudnorm=I=-16:TP=-2:LRA=9,aresample=48000[vo];[{bed_idx}:a]aformat=sample_rates=48000:channel_layouts=stereo[bd];"
                  f"[vo][bd]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.94,{edge}[a]")
    return ";".join(fl)


def render_clip(src, clip, out_dir, words, info, draft=False, force=False, cuts=(), spk=None, opts=None):
    from . import render as R
    opts = opts or {}
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    ed = {**(opts.get("edit_opts") or {}), **(clip.get("edit") or {})}
    name, st = D.style_for(ed.get("style") or opts.get("edit"), opts.get("profile"))
    cap = clip.get("caption") or {}
    sty = cap.get("style") or (opts.get("style") if opts.get("style") not in (None, "auto") else None) or st["caps"]
    sfile = opts.get("style_file")
    mdir = opts.get("music_dir")
    spec = {k: clip.get(k) for k in ("final_start", "final_end", "layout", "focus_x", "id", "audio", "music", "facecam", "overlays")}
    spec.update(v=VERSION, edit=ed, style=name, caps=sty, scale=cap.get("scale", 1.0), style_file=sha256_file(sfile) if sfile and Path(sfile).is_file() else None,
                draft=draft, src=opts.get("src_fp"), quality=opts.get("quality"), logo=opts.get("logo"), mdir=sorted(os.listdir(mdir)) if mdir and Path(mdir).is_dir() else None,
                reliable_spk=bool((spk or {}).get("reliable")), profile=opts.get("profile"), nomusic=opts.get("no_music"), nosfx=opts.get("no_sfx"), nocuts=opts.get("no_cuts"))
    tag = "_draft" if draft else ""
    out = out_dir / f"clip_{clip['id']:02d}{tag}_{digest(spec)}.mp4"
    if out.exists() and not force:
        return out
    for old in out_dir.glob(f"clip_{clip['id']:02d}{tag}_*.mp4"):
        old.unlink()
    s, e = clip["final_start"], clip["final_end"]
    cr = R.shot_cuts(s, e, cuts)
    lay = clip.get("layout", "fill")
    geom = None
    if clip.get("focus_x") is None:
        R.plan_framing(src, clip, cr, info, spk)
    wide_src = info["width"] / max(1, info["height"]) > 9 / 16 + 0.01
    if lay == "game" and clip.get("facecam"):
        geom = clip["facecam"]
    elif lay == "game":
        lay = "fit"
    elif lay == "split" or (lay == "fill" and clip.get("split_auto") and wide_src and clip.get("focus_x") is None):
        lay, geom = "split", tuple(clip.get("split_auto") or (0.28, 0.72))
    pairs = clip.get("pair_auto") or []
    edit_on = not ed.get("no_cuts") and not opts.get("no_cuts")
    p = D.plan(clip, words, info, st, opts.get("profile"), cr, cuts_on=edit_on, layout=lay, music=not (ed.get("no_music") or opts.get("no_music")),
               sfx_on=not (ed.get("no_sfx") or opts.get("no_sfx")), user_hook=("" if ed.get("hook") == "off" else ed.get("hook")))
    dur = p["dur"]
    for sg in p["segs"]:  # a two-shot with an unknown speaker is stacked; a close-up (or a followed speaker) stays a single framed picture
        pr = pairs[min(sg["shot"], len(pairs) - 1)] if pairs else None
        if lay == "split":
            sg["lay"], sg["geom"], sg["z"] = "split", geom, 1.0
        elif lay == "fill" and pr and wide_src and clip.get("focus_x") is None:
            sg["lay"], sg["geom"], sg["z"] = "split", tuple(pr), 1.0
    ass = []
    cw = p["words"]
    if sty != "none" and cw:
        stc = captions.style(sty, sfile)
        sg = p["segs"]
        inv = lambda t: next((s + x["a"] + (t - x["o"]) for x in reversed(sg) if t >= x["o"]), s)
        look = R._speaker_lookup(spk)
        stacked = sum(x["b"] - x["a"] for x in sg if x.get("lay") == "split") > dur / 2  # captions sit on the seam between the two stacked people
        (out_dir / f"clip_{clip['id']:02d}.ass").write_text(captions.build(cw, 0.0, stc, cap.get("scale", 1.0), y_offset=(H // 2 - 430 - stc["size"] // 2 + 20 if stacked else 0), speaker_at=(lambda t: look(inv(t))) if look else None), encoding="utf-8")
        ass.append(f"clip_{clip['id']:02d}.ass")
        clip["captions_n"] = (out_dir / ass[-1]).read_text(encoding="utf-8").count("\nDialogue:")
        clip["captions_overflow"] = captions.overflow(cw, stc, cap.get("scale", 1.0))
    else:
        clip["captions_n"], clip["captions_overflow"] = 0, 0
    if p["hook"] or p["callouts"] or st["progress"]:
        (out_dir / f"clip_{clip['id']:02d}_fx.ass").write_text(overlay_ass(p, st, dur), encoding="utf-8")
        ass.append(f"clip_{clip['id']:02d}_fx.ass")
    if ass:
        captions.install_fonts(out_dir)
    # audio bed
    bed_path, mfile = None, None
    if info["audio"] and (p["sfx"] or p["mood"]):
        try:
            mus = clip.get("music")
            mfile = mus["file"] if mus and os.path.exists(mus["file"]) else _pick_music(mdir, p["mood"], clip["id"])
            bed_path = sfxsynth.bed(out_dir / f"clip_{clip['id']:02d}_bed.wav", dur, cw, p["mood"], (mus or {}).get("db", st["music_db"]), p["sfx"], mfile)
        except ImportError as e:
            note_skipped("music and sound effects", f"numpy missing: {e}")
        except Exception as e:  # an optional layer must never fail the render
            note_skipped("music and sound effects", f"{type(e).__name__}: {e}")
    # source quality: how many source lines feed the 1920 output lines
    zs = [x["z"] for x in p["segs"]]
    fills = [x["z"] for x in p["segs"] if x.get("lay") != "split"]
    up = H / (_box(info, max(fills), 9 / 16)[1] if lay == "fill" and fills else info["height"] * (0.5 if lay == "split" or not fills else 1.0))
    clip["warn"] = ["low_res_source"] if up >= 2.0 else []
    clip["caps_used"] = sty
    clip["out_dur"], clip["studio"] = dur, {"style": name, "layout": lay, "segments": len(p["segs"]), "removed_s": p["removed_s"], "hook": p["hook"], "mood": p["mood"] if bed_path else None,
                                          "sfx": [e_["kind"] for e_ in p["sfx"]] if bed_path else [], "callouts": [c["text"] for c in p["callouts"]], "zoom_max": max(zs) if zs else 1.0,
                                          "music_file": Path(mfile).name if mfile else None, "emphasis": p["emphasis"]}
    # inputs
    cmd = [ffmpeg(), "-hide_banner", "-y"]
    for sg in p["segs"]:
        cmd += ["-ss", f"{s + sg['a']:.4f}", "-t", f"{sg['b'] - sg['a']:.4f}", "-i", os.path.abspath(src)]
    N = len(p["segs"])
    cmd += ["-ss", f"{s:.4f}", "-t", f"{(e - s):.4f}", "-i", os.path.abspath(src)]
    aud = N
    bed_idx = None
    if bed_path:
        cmd += ["-i", os.path.abspath(bed_path)]
        bed_idx = N + 1
    ovl = []
    for o in (clip.get("overlays") or ed.get("overlays") or []):
        if os.path.exists(o["file"]):
            pre = ["-c:v", "libvpx-vp9"] if o["file"].endswith(".webm") else (["-loop", "1"] if o["file"].lower().endswith((".png", ".jpg", ".webp")) else [])
            cmd += pre + ["-i", os.path.abspath(o["file"])]
            ovl.append((N + 1 + (1 if bed_path else 0) + len(ovl), o))
    vg = build_graph(p, lay, info, geom, st, up >= 1.5, None, {"ovl": ovl, "ass": ass})
    if draft:
        vg = vg.replace("[v]", "[vz];[vz]scale=540:960[v]")
    ag = audio_graph(p, aud, bed_idx, clip.get("audio") == "clean", dur) if info["audio"] else None
    qual = {"preset": "veryfast", "crf": 28} if draft else (opts.get("quality") or {"preset": "faster", "crf": 19})
    enc0 = R.encoder()

    def go(codec):
        c = cmd + ["-filter_complex", vg + (";" + ag if ag else ""), "-map", "[v]", *(["-map", "[a]"] if ag else []), "-t", f"{dur:.4f}", "-r", "30",
                   "-c:v", codec, *R.ENC_ARGS[codec](qual), "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out.name]
        return run(c, cwd=out_dir, timeout=7200)
    r = go(enc0)
    if r.returncode and enc0 != "libx264":
        note_skipped(f"hardware encoder {enc0}", "failed during render; used libx264")
        r = go("libx264")
    if r.returncode:
        out.unlink(missing_ok=True)
        raise RuntimeError(f"ffmpeg failed for clip {clip['id']}: {r.stderr[-700:]}")
    if opts.get("intro") or opts.get("outro"):
        R._wrap(out, opts.get("intro"), opts.get("outro"), out_dir, qual)
    return out
