"""Studio renderer: turns director.plan() into ONE ffmpeg call.
Picture: every segment is its own seek-limited input, cropped from the SOURCE pixels and resampled exactly once (no crop-then-scale-then-zoom chain,
so zooms are never softer than the base shot), then concatenated. Audio: kept ranges with 6 ms edge fades, normalised, mixed with a synthesised bed
(music ducked by the real word timeline + sound effects). Text (hook, callouts, progress bar, captions) is libass, so it is crisp at any zoom.
Segment lengths sit on a 30 fps grid so picture and sound cannot drift."""
import json, os, re, textwrap
from pathlib import Path
from . import captions, director as D, sfxsynth
from .util import digest, ffmpeg, note_skipped, probe, run, sha256_file

W, H = 1080, 1920
VERSION = 15
LAN = "flags=lanczos+accurate_rnd+full_chroma_int"
YELLOW, WHITE = "&H0000E5FF", "&H00FFFFFF"


def _even(x):
    return max(2, int(x) // 2 * 2)


def _box(info, z, aspect):
    """Largest crop of `aspect` (w/h) inside the source, divided by zoom z -> (w, h) even ints."""
    sw, sh = info["width"], info["height"]
    bw, bh = (sh * aspect, sh) if sw / sh >= aspect else (sw, sw / aspect)
    return _even(bw / z), _even(bh / z)


def _crop(info, z, aspect, fx, ybias=0.15, cy=None):
    """cy: face centre height (0..1) -> placed 38% from the top of the crop, so a person sitting low in the frame is not cut off."""
    cw, ch = _box(info, z, aspect)
    cw, ch = min(cw, info["width"]), min(ch, info["height"])
    if isinstance(fx, str):  # time expression (clip-relative t) -> per-frame crop x
        x = f"'min(max(({fx})*{info['width']}-{cw / 2},0),{info['width'] - cw})'"
    else:
        x = int(min(max(fx * info["width"] - cw / 2, 0), info["width"] - cw)) // 2 * 2
    y0 = (info["height"] - _box(info, 1.0, aspect)[1]) / 2
    y = y0 + (_box(info, 1.0, aspect)[1] - ch) * ybias
    if cy is not None:
        y = cy * info["height"] - 0.38 * ch
    y = min(max(y, 0), info["height"] - ch)
    return f"crop={cw}:{ch}:{x}:{int(y) // 2 * 2}"


def game_geom(info, fc):
    """Stacked gameplay + facecam: the camera panel keeps the camera's own aspect (3 people in a row are ~2:1), the game panel takes the rest."""
    fw, fh = fc[2] * info["width"], fc[3] * info["height"]
    cam_h = int(min(860, max(440, W * fh / fw))) // 2 * 2
    game_h = int(min(960, H - 150 - 110 - cam_h - 12)) // 2 * 2
    y0 = max(150, (H - (game_h + 12 + cam_h)) // 2)
    return {"cam_h": cam_h, "game_h": game_h, "y0": y0, "y1": y0 + game_h + 12}


def _wrap(text, width):
    return r"\N".join(textwrap.wrap(text, width)[:3])


def overlay_ass(p, st, dur):
    """Hook headline, big number callouts and a progress bar, as ASS (animated by libass)."""
    L = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}", "WrapStyle: 2", "ScaledBorderAndShadow: yes", "", "[V4+ Styles]",
         "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
         f"Style: Hook,Anton,118,&H00000000,&H00000000,{YELLOW},&H00000000,0,0,0,0,100,100,1,0,3,20,0,8,64,64,300,1",
         f"Style: Call,Anton,150,{WHITE},{WHITE},&H00000000,&H90000000,0,0,0,0,100,100,2,0,1,10,5,5,60,60,0,1",
         "Style: Bar,Poppins,20,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1",
         "", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text"]
    ev = lambda a, b, sty, txt: L.append(f"Dialogue: 1,{captions._t(a)},{captions._t(b)},{sty},,0,0,0,,{txt}")
    if p["hook"]:
        ev(0.0, min(3.4, dur * 0.35), "Hook", r"{\fad(0,260)\fscx88\fscy88\t(0,170,\fscx100\fscy100)}" + _wrap(captions._clean(p["hook"]).upper(), 17))
    for c in p["callouts"]:
        ev(c["t"], c["t"] + c["dur"], "Call", r"{\pos(540,760)\fscx45\fscy45\t(0,130,\fscx112\fscy112)\t(130,260,\fscx100\fscy100)\fad(0,200)}" + captions._clean(c["text"]))
    if st["progress"]:
        L.append(f"Dialogue: 2,{captions._t(0)},{captions._t(dur)},Bar,,0,0,0,,{{\\an7\\pos(0,1880)\\p1\\c{YELLOW}&\\fscx0\\t(0,{int(dur * 1000)},\\fscx100)}}m 0 0 l 1080 0 1080 12 0 12{{\\p0}}")
    return "\n".join(L) + "\n"


def auto_facecam(src, info, s, e, n=6):
    """Streamer's camera box (x, y, w, h as fractions of the source), found by looking for small faces parked in a corner over several frames.
    None if there is no such box (a talking head fills the frame, or no faces / no OpenCV)."""
    try:
        import cv2
        from . import speaker
    except ImportError:
        return None
    cap = cv2.VideoCapture(str(src))
    boxes = []
    for k in range(n):
        cap.set(cv2.CAP_PROP_POS_MSEC, (s + (e - s) * (k + 0.5) / n) * 1000)
        ok, fr = cap.read()
        if not ok:
            continue
        allf = speaker.detect_faces(fr, 0.6)
        if any(f["size"] >= 0.03 for f in allf):  # a big face means a talking-head video, not a game with a camera in the corner
            return None
        fs = [f for f in allf if f["size"] < 0.012 and (f["cx"] < 0.3 or f["cx"] > 0.7) and (f["cy"] < 0.35 or f["cy"] > 0.65)]
        if fs:
            side = lambda f: (f["size"] * fr.shape[1] * fr.shape[0]) ** 0.5
            boxes.append((min(f["cx"] - side(f) / 2 / fr.shape[1] for f in fs), min(f["cy"] - side(f) / 2 / fr.shape[0] for f in fs),
                          max(f["cx"] + side(f) / 2 / fr.shape[1] for f in fs), max(f["cy"] + side(f) / 2 / fr.shape[0] for f in fs)))
    cap.release()
    if len(boxes) < max(2, n // 2):
        return None
    m = lambda i: sorted(b[i] for b in boxes)[len(boxes) // 2]
    x0, y0, x1, y1 = m(0), m(1), m(2), m(3)
    w, h = (x1 - x0) * 1.3, (y1 - y0) * 1.6
    ar = w * info["width"] / max(h * info["height"], 1e-6)  # keep the camera's own aspect, between 1.3:1 and 2.6:1
    if ar > 2.6:
        h = w * info["width"] / 2.6 / info["height"]
    elif ar < 1.3:
        w = h * info["height"] * 1.3 / info["width"]
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2 + (y1 - y0) * 0.05
    w, h = min(w, 1.0), min(h, 1.0)
    return [float(round(min(max(cx - w / 2, 0), 1 - w), 4)), float(round(min(max(cy - h / 2, 0), 1 - h), 4)), float(round(w, 4)), float(round(h, 4))]


def face_ys(src, info, t0, t1, pair, n=3):
    """Heights (0..1) of the two people of a stacked shot: median face centre near each x. None where no face was found."""
    try:
        import cv2
        from . import speaker
    except ImportError:
        return (None, None)
    cap = cv2.VideoCapture(str(src))
    ys = ([], [])
    for k in range(n):
        cap.set(cv2.CAP_PROP_POS_MSEC, (t0 + (t1 - t0) * (k + 0.5) / n) * 1000)
        ok, fr = cap.read()
        if ok:
            for f in speaker.detect_faces(fr, 0.6):
                i = min((0, 1), key=lambda j: abs(f["cx"] - pair[j]))
                if abs(f["cx"] - pair[i]) < 0.2:
                    ys[i].append(float(f["cy"]))
    cap.release()
    med = lambda v: sorted(v)[len(v) // 2] if v else None
    return (med(ys[0]), med(ys[1]))


def _pick_music(music_dir, mood, key):
    if not music_dir or not Path(music_dir).is_dir():
        return None
    fs = sorted(f for f in Path(music_dir).iterdir() if f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg", ".flac", ".aac"))
    hit = [f for f in fs if mood and mood in f.stem.lower()] or fs
    return str(hit[key % len(hit)]) if hit else None


def build_graph(p, layout, info, geom, st, sharp, flash_ids, inputs):
    """-> (filter_complex, nseg). inputs: dict with indices {'aud','bed','ovl':[(idx,spec)]}. geom: split pair / facecam rect."""
    from . import render as R
    N = len(p["segs"])
    fl = []
    for i, sg in enumerate(p["segs"]):
        head = f"[{i}:v]fps=30,setpts=PTS-STARTPTS"
        if sg.get("lay") == "split" or layout == "split":
            g = sg.get("geom") or geom
            cwf = _box(info, 1.0, W / (H // 2))[0] / info["width"]  # share of the frame one half would show
            zs = min(1.6, max(1.0, cwf * 1.05 / max(abs(g[1] - g[0]), 0.2)))  # two people close together: tighten so each half shows only its own person
            ys = sg.get("ys") or (None, None)
            a = _crop(info, zs, W / (H // 2), g[0], 0.25, ys[0])
            b = _crop(info, zs, W / (H // 2), g[1], 0.25, ys[1])
            fl.append(f"{head},split[sa{i}][sb{i}];[sa{i}]{a},scale={W}:{H // 2}:{LAN}[ta{i}];[sb{i}]{b},scale={W}:{H // 2}:{LAN}[tb{i}];[ta{i}][tb{i}]vstack,"
                      f"drawbox=x=0:y={H // 2 - 3}:w={W}:h=6:color=white@0.9:t=fill,setsar=1[v{i}]")
        elif layout == "fill":
            fl.append(f"{head},{_crop(info, sg['z'], 9 / 16, R._lerp([tuple(k) for k in sg['kf']], None) if sg.get('kf') else sg['x'])},scale={W}:{H}:{LAN},setsar=1[v{i}]")
        else:
            fl.append(f"{head},setsar=1[v{i}]")
    fl.append("".join(f"[v{i}]" for i in range(N)) + f"concat=n={N}:v=1:a=0[vc]")
    cur = "vc"
    if layout == "fit":
        fl.append(f"[{cur}]split[fa][fb];[fa]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=30:5,eq=brightness=-0.1[fbg];"
                  f"[fb]scale={W}:-2:{LAN}[ffg];[fbg][ffg]overlay=(W-w)/2:(H-h)/2[vl]")
        cur = "vl"
    elif layout == "game":
        sh = "".join(f"+if(between(t,{a:.2f},{a + 0.35:.2f}),{{A}}*sin(t*{{F}}),0)" for a in p.get("shakes", []))
        sh_x, sh_y = sh.replace("{A}", "16").replace("{F}", "95"), sh.replace("{A}", "12").replace("{F}", "131")
        fx, fy, fw, fh = geom
        gg = game_geom(info, geom)
        gw = _even(min(info["width"], info["height"] * W / gg["game_h"]))
        cw, ch = _even(fw * info["width"]), _even(fh * info["height"])
        cx0, cy0 = _even(fx * info["width"]), _even(fy * info["height"])
        # hide the camera inside the game panel (it has its own panel): cover it with the neighbouring game pixels, slightly blurred
        px = cx0 - cw if cx0 - cw >= 0 else min(cx0 + cw, info["width"] - cw)
        py = cy0
        fl.append(f"[{cur}]split=3[ga][gb][gc];[ga]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=30:5,eq=brightness=-0.15[gbg];"
                  f"[gb]split[g1][g2];[g2]crop={cw}:{ch}:{px}:{py},boxblur=6:2[gpatch];[g1][gpatch]overlay={_even(fx * info['width'])}:{_even(fy * info['height'])}[gclean];"
                  f"[gclean]crop={gw}:ih:{(info['width'] - gw) // 2 // 2 * 2}:0,scale={W}:{gg['game_h']}:{LAN}[ggm];"
                  f"[gc]crop={cw}:{ch}:{_even(fx * info['width'])}:{_even(fy * info['height'])},scale={W}:{gg['cam_h']}:{LAN}[gcam];"
                  f"[gbg][ggm]overlay=x='0{sh_x}':y='{gg['y0']}{sh_y}':eval=frame[gt];[gt][gcam]overlay=0:{gg['y1']}[vl]")
        cur = "vl"
    tail = [st["grade"], "unsharp=5:5:0.7:5:5:0.0" if sharp else "unsharp=3:3:0.35:3:3:0.0"]
    for t in p["flashes"]:
        tail.append(f"drawbox=x=0:y=0:w=iw:h=ih:color=white@0.45:t=fill:enable='between(t,{t:.2f},{t + 0.07:.2f})'")
    fl.append(f"[{cur}]{','.join(x for x in tail if x)}[vg]")
    cur = "vg"
    if inputs.get("wave") is not None:  # podcast twist: a live waveform of the voice on the seam
        fl.append(f"[{cur}][wv]overlay=0:{inputs['wave']}:eof_action=pass[vw]")
        cur = "vw"
    for j, (idx, spec) in enumerate(inputs["ovl"]):
        t, d = spec["t"], spec.get("dur", 3.0)
        fl.append(f"[{idx}:v]format=rgba,setpts=PTS-STARTPTS+{t}/TB,scale={W}:-2[ov{j}];[{cur}][ov{j}]overlay=0:{spec.get('y', 0)}:eof_action=pass:enable='between(t,{t},{t + d})'[vo{j}]")
        cur = f"vo{j}"
    subs = ",".join(f"subtitles={f}:fontsdir=fonts" for f in inputs["ass"])
    fl.append(f"[{cur}]{subs or 'null'}[v]")
    return ";".join(fl)


def audio_graph(p, aud_idx, bed_idx, clean, dur, wave=False):
    R = p["ranges"]
    fl = []
    if len(R) > 1:
        fl.append(f"[{aud_idx}:a]asplit={len(R)}" + "".join(f"[x{k}]" for k in range(len(R))))
    for k, (a, b) in enumerate(R):
        src = f"[x{k}]" if len(R) > 1 else f"[{aud_idx}:a]"
        d = b - a
        fl.append(f"{src}atrim=start={a:.4f}:end={b:.4f},asetpts=PTS-STARTPTS,afade=t=in:st=0:d=0.006,afade=t=out:st={max(0, d - 0.006):.4f}:d=0.006[r{k}]")
    fl.append("".join(f"[r{k}]" for k in range(len(R))) + f"concat=n={len(R)}:v=0:a=1[am]")
    voice = "highpass=f=80,afftdn=nf=-25," if clean else ""
    base = f"[am]aresample=48000,aformat=channel_layouts=stereo,{voice}"
    edge = f"afade=t=in:st=0:d=0.015,afade=t=out:st={max(0, dur - 0.03):.3f}:d=0.03"
    if bed_idx is None:
        fl.append(f"{base}loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,{edge}[a]")
    else:
        fl.append(f"{base}loudnorm=I=-13.5:TP=-2:LRA=9,aresample=48000[vo];[{bed_idx}:a]aformat=sample_rates=48000:channel_layouts=stereo[bd];"
                  f"[vo][bd]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.94,{edge}[a]")
    if wave:
        fl[-1] = fl[-1][:-3] + "[a0]"
        fl.append("[a0]asplit=2[a][aw];[aw]volume=6dB,showwaves=s=1080x150:mode=cline:rate=30:scale=sqrt:colors=0xFFE500,format=rgba,colorkey=0x000000:0.25:0.1[wv]")
    return ";".join(fl)


def render_clip(src, clip, out_dir, words, info, draft=False, force=False, cuts=(), spk=None, opts=None):
    from . import render as R
    opts = opts or {}
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    ed = {**(opts.get("edit_opts") or {}), **(clip.get("edit") or {})}
    want = ed.get("style") or opts.get("edit")
    name, st = D.style_for(want, opts.get("profile"))
    cap = clip.get("caption") or {}
    explicit_caps = cap.get("style") or (opts.get("style") if opts.get("style") not in (None, "auto") else None)
    sfile = opts.get("style_file")
    mdir = opts.get("music_dir")
    sty = explicit_caps or st["caps"]
    spec = {k: clip.get(k) for k in ("final_start", "final_end", "layout", "focus_x", "id", "audio", "music", "facecam", "overlays")}
    spec.update(v=VERSION, edit=ed, style=name, caps=sty, scale=cap.get("scale", 1.0), cy=cap.get("y", 0), style_file=sha256_file(sfile) if sfile and Path(sfile).is_file() else None,
                draft=draft, src=opts.get("src_fp"), quality=opts.get("quality"), logo=opts.get("logo"), mdir=sorted(os.listdir(mdir)) if mdir and Path(mdir).is_dir() else None,
                reliable_spk=bool((spk or {}).get("reliable")), profile=opts.get("profile"), nomusic=opts.get("no_music"), nosfx=opts.get("no_sfx"), nocuts=opts.get("no_cuts"), nocold=opts.get("no_coldopen"), peaks=len(opts.get("peaks") or []))
    tag = "_draft" if draft else ""
    out = out_dir / f"clip_{clip['id']:02d}{tag}_{digest(spec)}.mp4"
    side = out.with_suffix(".json")  # what the render learned about the clip (length, warnings, captions): a cache hit must restore it
    if out.exists() and not force and side.exists():
        clip.update(json.loads(side.read_text()))
        return out
    for old in list(out_dir.glob(f"clip_{clip['id']:02d}{tag}_*.mp4")) + list(out_dir.glob(f"clip_{clip['id']:02d}{tag}_*.json")):
        old.unlink()
    s, e = clip["final_start"], clip["final_end"]
    cr = R.shot_cuts(s, e, cuts)
    lay = clip.get("layout", "fill")
    geom = None
    wide_src = info["width"] / max(1, info["height"]) > 9 / 16 + 0.01
    if wide_src and lay in ("fill", "fit", "game") and clip.get("focus_x") is None:  # gameplay/stream: a small face parked in a corner = facecam, whatever the profile says
        fc = clip.get("facecam") or clip.get("facecam_auto")
        if fc is None:
            fc = auto_facecam(src, info, s, e) or False
            clip["facecam_auto"] = fc
        if fc:
            lay, geom = "game", fc
        elif lay == "game" or opts.get("profile") == "gaming" or name == "gamer":
            lay = "fit"
    if lay not in ("game", "fit") and clip.get("focus_x") is None:
        R.plan_framing(src, clip, cr, info, spk)
    if lay == "split" or (lay == "fill" and clip.get("split_auto") and wide_src and clip.get("focus_x") is None):
        lay, geom = "split", tuple(clip.get("split_auto") or (0.28, 0.72))
    pairs = clip.get("pair_auto") or []
    if want in (None, "auto") and lay == "game":
        name, st = "gamer", D.STYLES["gamer"]
        sty = explicit_caps or st["caps"]
    elif want in (None, "auto") and any(pairs) and opts.get("profile") not in ("gaming", "sports", "comedy"):
        name, st = "podcast", D.STYLES["podcast"]  # two people on screen: the podcast edit (stack, waveform, calmer cuts)
        sty = explicit_caps or st["caps"]
    edit_on = not ed.get("no_cuts") and not opts.get("no_cuts")
    p = D.plan(clip, words, info, st, opts.get("profile"), cr, cuts_on=edit_on, layout=lay, music=not (ed.get("no_music") or opts.get("no_music")),
               sfx_on=not (ed.get("no_sfx") or opts.get("no_sfx")), coldopen=not (ed.get("no_coldopen") or opts.get("no_coldopen")), peaks=opts.get("peaks") or (),
               user_hook=("" if ed.get("hook") == "off" else ed.get("hook")))
    dur = p["dur"]
    ycache = {}
    for sg in p["segs"]:  # a two-shot with an unknown speaker is stacked; a close-up (or a followed speaker) stays a single framed picture
        pr = pairs[min(sg["shot"], len(pairs) - 1)] if pairs else None
        if lay == "split":
            sg["lay"], sg["geom"], sg["z"] = "split", geom, 1.0
        elif lay == "fill" and pr and wide_src and clip.get("focus_x") is None:
            sg["lay"], sg["geom"], sg["z"] = "split", tuple(pr), 1.0
        if sg.get("lay") == "split":
            k = (sg["shot"], tuple(sg["geom"]))
            if k not in ycache:
                ycache[k] = face_ys(src, info, s + sg["a"], s + sg["b"], sg["geom"])
            sg["ys"] = ycache[k]
    ass = []
    wave = bool(st.get("wave")) and info["audio"] and lay in ("fill", "split")
    cw = p["words"]
    seam = (game_geom(info, geom)["y0"] + game_geom(info, geom)["game_h"] + 6) if lay == "game" else (H // 2 if sum(x["b"] - x["a"] for x in p["segs"] if x.get("lay") == "split") > dur / 2 else None)  # captions/waveform sit on the seam between two pictures
    wave = wave and seam is not None  # the waveform lives on a seam between two pictures; across one face it covers the mouth
    if sty != "none" and cw:
        stc = captions.style(sty, sfile)
        sg = p["segs"]
        inv = lambda t: next((s + x["a"] + (t - x["o"]) for x in reversed(sg) if t >= x["o"]), s)
        look = R._speaker_lookup(spk)
        (out_dir / f"clip_{clip['id']:02d}.ass").write_text(captions.build(cw, 0.0, stc, cap.get("scale", 1.0), y_offset=(H - seam - captions.eff(stc, cap.get("scale", 1.0)) // 2 - stc["mv"] if seam else 0) + int(cap.get("y", 0)), speaker_at=(lambda t: look(inv(t))) if look else None), encoding="utf-8")
        ass.append(f"clip_{clip['id']:02d}.ass")
        clip["captions_n"] = (out_dir / ass[-1]).read_text(encoding="utf-8").count("\nDialogue:")
        clip["captions_overflow"] = captions.overflow(cw, stc, cap.get("scale", 1.0))
    else:
        clip["captions_n"], clip["captions_overflow"] = 0, 0
    if p["hook"] or p["callouts"] or st["progress"]:
        (out_dir / f"clip_{clip['id']:02d}_fx.ass").write_text(overlay_ass(p, st, dur), encoding="utf-8")
        ass.append(f"clip_{clip['id']:02d}_fx.ass")
    if ass:
        captions.install_fonts(out_dir)
    # audio bed
    bed_path, mfile = None, None
    if info["audio"] and (p["sfx"] or p["mood"]):
        try:
            mus = clip.get("music")
            mfile = mus["file"] if mus and os.path.exists(mus["file"]) else _pick_music(mdir, p["mood"], clip["id"])
            bed_path = sfxsynth.bed(out_dir / f"clip_{clip['id']:02d}_bed.wav", dur, cw, p["mood"], (mus or {}).get("db", st["music_db"]) + ed.get("music_gain", 0), [{**e_, "db": e_.get("db", 0) + ed.get("sfx_gain", 0)} for e_ in p["sfx"]], mfile)
        except ImportError as e:
            note_skipped("music and sound effects", f"numpy missing: {e}")
        except Exception as e:  # an optional layer must never fail the render
            note_skipped("music and sound effects", f"{type(e).__name__}: {e}")
    # source quality: how many source lines feed the 1920 output lines
    zs = [x["z"] for x in p["segs"]]
    fills = [x["z"] for x in p["segs"] if x.get("lay") != "split"]
    up = H / (_box(info, max(fills), 9 / 16)[1] if lay == "fill" and fills else info["height"] * (0.5 if lay == "split" or not fills else 1.0))
    clip["warn"] = ["low_res_source"] if up >= 2.0 else []
    clip["caps_used"] = sty
    clip["out_dur"], clip["studio"] = dur, {"style": name, "layout": lay, "segments": len(p["segs"]), "removed_s": p["removed_s"], "hook": p["hook"], "mood": p["mood"] if bed_path else None,
                                          "sfx": [e_["kind"] for e_ in p["sfx"]] if bed_path else [], "callouts": [c["text"] for c in p["callouts"]], "zoom_max": max(zs) if zs else 1.0,
                                          "music_file": Path(mfile).name if mfile else None, "emphasis": p["emphasis"], "teaser": (p["teaser"] or {}).get("text"), "shakes": p["shakes"], "facecam": geom if lay == "game" else None, "wave": wave}
    # inputs
    cmd = [ffmpeg(), "-hide_banner", "-y"]
    for sg in p["segs"]:
        cmd += ["-ss", f"{s + sg['a']:.4f}", "-t", f"{sg['b'] - sg['a']:.4f}", "-i", os.path.abspath(src)]
    N = len(p["segs"])
    cmd += ["-ss", f"{s:.4f}", "-t", f"{(e - s):.4f}", "-i", os.path.abspath(src)]
    aud = N
    bed_idx = None
    if bed_path:
        cmd += ["-i", os.path.abspath(bed_path)]
        bed_idx = N + 1
    ovl = []
    for o in (clip.get("overlays") or ed.get("overlays") or []):
        if os.path.exists(o["file"]):
            pre = ["-c:v", "libvpx-vp9"] if o["file"].endswith(".webm") else (["-loop", "1"] if o["file"].lower().endswith((".png", ".jpg", ".webp")) else [])
            cmd += pre + ["-i", os.path.abspath(o["file"])]
            ovl.append((N + 1 + (1 if bed_path else 0) + len(ovl), o))
    vg = build_graph(p, lay, info, geom, st, up >= 1.5, None, {"ovl": ovl, "ass": ass, "wave": ((seam or 1290) - 75) if wave else None})
    if draft:
        vg = vg.replace("[v]", "[vz];[vz]scale=540:960[v]")
    ag = audio_graph(p, aud, bed_idx, clip.get("audio") == "clean", dur, wave) if info["audio"] else None
    qual = {"preset": "veryfast", "crf": 28} if draft else (opts.get("quality") or {"preset": "faster", "crf": 19})
    enc0 = R.encoder()

    def go(codec):
        c = cmd + ["-filter_complex", vg + (";" + ag if ag else ""), "-map", "[v]", *(["-map", "[a]"] if ag else []), "-t", f"{dur:.4f}", "-r", "30",
                   "-c:v", codec, *R.ENC_ARGS[codec](qual), "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out.name]
        return run(c, cwd=out_dir, timeout=7200)
    r = go(enc0)
    if r.returncode and enc0 != "libx264":
        note_skipped(f"hardware encoder {enc0}", "failed during render; used libx264")
        r = go("libx264")
    if r.returncode:
        out.unlink(missing_ok=True)
        raise RuntimeError(f"ffmpeg failed for clip {clip['id']}: {r.stderr[-700:]}")
    if opts.get("intro") or opts.get("outro"):
        R._wrap(out, opts.get("intro"), opts.get("outro"), out_dir, qual)
    side.write_text(json.dumps({k: clip.get(k) for k in ("out_dur", "studio", "warn", "caps_used", "captions_n", "captions_overflow", "facecam_auto")}))
    return out
