"""Bridge to earshot (MIT, vendored in third_party/earshot, https://github.com/Leonxlnx/earshot): ears for the edit.
Model-free parts (always on when numpy+scipy+librosa+soundfile+soxr+pyloudnorm are installed):
  take()     a sound effect from earshot's 252-sound bank, aimed at a moment (onset/peak known to the ms) and audited
  measure()  spectrum balance, noise floor, dynamic range, clipped samples of a rendered file
Model parts (need torch + transformers, ~350 MB for AST; optional, reported in features_skipped when absent):
  tag_windows()  AudioSet labels (laughter, cheering, applause, screams...) per window: replaces the missing PANNs signal
Everything degrades to the built-in synthesis (sfxsynth) or to no measurement; nothing here may fail a render."""
import sys
from functools import lru_cache
from pathlib import Path

VENDOR = Path(__file__).resolve().parent.parent / "third_party" / "earshot"

# our sound-effect role -> (bank id, knobs, which point of the take lands on the planned time)
#   peak: loudest 5 ms on t (hits, pops, dings)   onset: first sound on t (taps)   end: the take's end on t (risers)
ROLES = {  # every id here passes earshot's model-free audit (tests/test_ears.py re-checks it)
    "whoosh": ("whoosh_fast/crisp", {"dur": 0.6}, "peak"),
    "swipe":  ("swipe/glide", {"dur": 0.3}, "peak"),
    "pop":    ("ui_pop/blip", {}, "onset"),
    "thud":   ("cut_hit/punch", {}, "peak"),
    "riser":  ("riser/dark", {"dur": 1.1}, "end"),
    "ding":   ("pro_notify/ding_1930", {}, "onset"),
    "tick":   ("tap/soft", {}, "onset"),
}


@lru_cache(maxsize=1)
def _load():
    """-> (bank, features) or None when earshot's dependencies are missing."""
    try:
        if VENDOR.exists() and str(VENDOR) not in sys.path:
            sys.path.append(str(VENDOR))  # appended: a pip-installed earshot wins
        from earshot import features
        from earshot.forge import bank
        return bank, features
    except Exception:  # ImportError, or a missing optional wheel inside earshot
        return None


def available():
    return _load() is not None


@lru_cache(maxsize=64)
def take(kind, sr=48000):
    """-> dict(y mono float32 peak 0.9, sr, align_s (seconds from the take's start to its sync point), id, ok, warnings) or None -> use sfxsynth.
    The take is audited by earshot's model-free sfx check (clicks, DC, truncation, silence, clipping)."""
    L = _load()
    if not L or kind not in ROLES:
        return None
    sid, knobs, point = ROLES[kind]
    try:
        y, m = L[0].render(sid, sr=sr, **knobs)
        import numpy as np
        y = np.asarray(y, dtype="float32")
        y = y.mean(axis=1) if y.ndim == 2 else y
        y = 0.9 * y / (float(np.abs(y).max()) + 1e-9)
        align = {"peak": float(m["peak_s"]), "onset": float(m["onset_s"]), "end": float(m["end_s"])}[point]
        chk = m.get("checks") or {}
        return {"y": y, "sr": sr, "align_s": align, "id": sid, "point": point, "ok": bool(chk.get("ok", True)), "warnings": list(chk.get("warnings") or [])}
    except Exception:
        return None


def measure(path):
    """Objective numbers of a rendered audio file (earshot.features.measure, no models) + derived verdict inputs. {} when unavailable."""
    L = _load()
    if not L:
        return {}
    import subprocess, tempfile, os
    from .util import ffmpeg
    fd, tmp = tempfile.mkstemp(suffix=".wav")
    os.close(fd)
    try:
        subprocess.run([ffmpeg(), "-v", "error", "-y", "-i", str(path), "-vn", "-ac", "1", "-ar", "22050", tmp], check=True)
        m = L[1].measure(tmp, music=False, light=True)
    except Exception:
        return {}
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass
    b = m.get("bands_db") or {}
    return {"noise_floor_dbfs": m.get("noise_floor_dbfs"), "rms_dbfs": m.get("rms_dbfs"), "dynamic_range_db": m.get("dynamic_range_db"),
            "clipped_samples": m.get("clipped_samples"), "digital_silence_frac": m.get("digital_silence_frac"), "bands_db": b,
            "snr_db": (m["rms_dbfs"] - m["noise_floor_dbfs"]) if m.get("rms_dbfs") is not None and m.get("noise_floor_dbfs") is not None else None,
            "presence_vs_lowmid_db": (b["presence"] - b["lowmid"]) if "presence" in b and "lowmid" in b else None}


@lru_cache(maxsize=1)
def _ast():
    try:
        import torch
        from transformers import ASTFeatureExtractor, ASTForAudioClassification
    except ImportError:
        return None
    name, rev = "MIT/ast-finetuned-audioset-10-10-0.4593", "f826b80d28226b62986cc218e5cec390b1096902"
    try:
        fe = ASTFeatureExtractor.from_pretrained(name, revision=rev)
        md = ASTForAudioClassification.from_pretrained(name, revision=rev).eval()
    except Exception:
        return None
    return torch, fe, md


def tag_windows(samples, sr=16000, win=5.0, wanted=None, batch=8):
    """AudioSet tagging (AST) of mono float samples in `win`-second windows -> [{label: p}, ...] for the labels in `wanted` (None = top-3). None when torch/transformers/model are missing."""
    A = _ast()
    if not A:
        return None
    torch, fe, md = A
    n = int(win * sr)
    wins = [samples[i:i + n] for i in range(0, max(len(samples) - n // 2, 1), n)]
    out = []
    id2 = md.config.id2label
    with torch.no_grad():
        for i in range(0, len(wins), batch):
            inp = fe(wins[i:i + batch], sampling_rate=sr, return_tensors="pt")
            pr = torch.sigmoid(md(**inp).logits)
            for row in pr:
                d = {id2[j]: float(row[j]) for j in (range(len(row)) if wanted else row.topk(3).indices.tolist()) if not wanted or id2[j] in wanted}
                out.append(d)
    return out
