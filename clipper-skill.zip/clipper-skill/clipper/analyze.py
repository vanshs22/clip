"""`clipper analyze JOB`: the evidence behind every chosen moment, in one readable report (analysis.md + analysis.json in the job folder).
For each clip: which signals peaked in it (percentile against the WHOLE video, so 'audio 97%' means louder than 97% of all seconds), the emotion the
words and sounds point to, what the chat did, and whether the start and end are complete thoughts. An agent reads this before it trusts a selection."""
import re
from . import boundaries as B, director as D
from .util import hms, jload, jsave

SIGNALS = ("speech", "audio", "visual", "chat", "heat", "events", "ocr")
FLOOR = {"events": 0.15, "ocr": 0.5, "chat": 3.0}  # probability / count signals: a peak below this is noise, whatever its percentile


def _pct(series, a, b, floor=0.0):
    """-> (percentile of the window's peak among all seconds, peak value). None if the series is empty/flat."""
    if not series or max(series) <= 0:
        return None
    w = series[max(0, int(a)):int(b) + 1]
    if not w:
        return None
    pk = max(w)
    if pk < floor:
        return None
    return round(100.0 * sum(1 for v in series if v <= pk) / len(series)), round(pk, 3)


def _emotion(text, ev_peak):
    tags = [m for m, rx in D.MOOD_WORDS.items() if re.search(rx, text, re.I)]
    if re.search(r"[!]", text) or re.search(r"\b(oh my god|omg|no way|insane|crazy|unbelievable|holy)\b", text, re.I):
        tags.append("excited")
    if ev_peak and ev_peak > 0.25:
        tags.append("laughter/cheering heard")
    return sorted(set(tags))


def analyze(j):
    plan, sig, src = jload(j.p("plan.json")), jload(j.p("signals.json")) or {}, jload(j.p("source.json")) or {}
    words = jload(j.p("transcript.json"))["words"]
    sents = B.sentences(words)
    rep = {"source": {"duration_s": src.get("info", {}).get("duration"), "size": f"{src.get('info', {}).get('width')}x{src.get('info', {}).get('height')}"},
           "signals_available": {k: bool(sig.get(k)) and max(sig.get(k) or [0]) > 0 for k in SIGNALS}, "clips": []}
    rep["signals_missing"] = [k for k, v in rep["signals_available"].items() if not v]
    for c in plan["clips"]:
        a, b = c["final_start"], c["final_end"]
        ca, cb = c.get("core_start", a), c.get("core_end", b)
        ev = {k: _pct(sig.get(k), ca, cb, FLOOR.get(k, 0.0)) for k in SIGNALS if sig.get(k)}
        ev = {k: v for k, v in ev.items() if v}
        why = [f"{k} {v[0]}th percentile" for k, v in sorted(ev.items(), key=lambda kv: -kv[1][0]) if v[0] >= 80][:4]
        fw = c.get("final_words") or [0, 0]
        first = next((s for s in sents if s[0] <= fw[0] <= s[1]), None)
        last = next((s for s in sents if s[0] <= fw[1] <= s[1]), None)
        starts_clean = bool(first) and B._first(words, fw[0]) not in B.DEPENDENT
        ends_clean = bool(last) and fw[1] >= last[1] - 1 and D._ends(words, fw[1])
        win = B._text(words, *fw)
        chat = sig.get("chat_info") or {}
        rep["clips"].append({
            "id": c["id"], "time": f"{hms(a)}-{hms(b)}", "length_s": round(b - a, 1), "score": c.get("final_score"), "kind": c.get("kind", "speech"),
            "why_chosen": why or ["no single signal stands out: chosen on speech content"], "evidence": {k: {"percentile": v[0], "peak": v[1]} for k, v in ev.items()},
            "emotion": _emotion(win, (ev.get("events") or (0, 0))[1]), "hook_score": c.get("hook"), "first_line": B._text(words, *first)[:140] if first else "",
            "last_line": B._text(words, *last)[:140] if last else "", "starts_complete_thought": starts_clean, "ends_complete_thought": bool(ends_clean), "boundary_issues": c.get("issues") or [],
            "chat": chat.get(str(int(ca))) if isinstance(chat, dict) else None})
    jsave(j.p("analysis.json"), rep)
    L = [f"# Analysis of job {j.id}", f"Source {rep['source']['size']}, {rep['source']['duration_s']} s. Signals used: {[k for k, v in rep['signals_available'].items() if v]}. Missing: {rep['signals_missing'] or 'none'}.", ""]
    for r in rep["clips"]:
        L += [f"## Clip {r['id']}  {r['time']}  ({r['length_s']} s, score {r['score']})", "- Why: " + "; ".join(r["why_chosen"]), "- Emotion: " + (", ".join(r["emotion"]) or "neutral / informational"),
              f"- Opens: \"{r['first_line']}\"  ({'complete' if r['starts_complete_thought'] else 'check: may need setup'})", f"- Ends: \"{r['last_line']}\"  ({'complete' if r['ends_complete_thought'] else 'CHECK: may stop mid-thought'})",
              "- Boundary issues: " + (", ".join(r["boundary_issues"]) or "none"), ""]
    (j.p("analysis.md")).write_text("\n".join(L), encoding="utf-8")
    return rep
