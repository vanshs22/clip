"""Multi-region 9:16 layouts (webcam + game/content, circles, UI panels, filler). Data-driven: LAYOUTS names the source regions each needs and the
destination rects (fractions of the 1080x1920 frame). Regions are fractions [x, y, w, h] of the SOURCE frame, set per clip with `clipper edit`.
`fill` and `fit` stay in render.vfilter. Shortcut: every slot is zoomed to fill its rect (no letterboxing), when you need "whole game" use `fit`."""
REGIONS = ("cam", "cam2", "game", "ui")
SQ = "sq"  # circle (square source crop, round mask)

# name: (default band share, needs, one-line description). band = height share of the top strip (cam/ui row); 0 = none
LAYOUTS = {
    "split":         (.38, ("cam",), "webcam band on top, game below"),
    "basecam":       (.38, ("cam",), "game on top, webcam band at the bottom"),
    "half":          (.50, ("cam",), "webcam and game 50/50"),
    "fullscreen":    (0, (), "the game region cropped to fill the frame, no webcam"),
    "small_facecam": (0, ("cam",), "game fills the frame, small rectangular webcam top-right"),
    "circle_facecam": (0, ("cam",), "game fills the frame, round webcam top-right"),
    "game_ui":       (.30, ("cam", "ui"), "webcam on top, game below, a UI panel (score/map) over the game"),
    "mosaic":        (.30, ("cam", "ui"), "webcam and UI panel side by side on top, game below"),
    "dual_facecam":  (0, ("cam", "cam2"), "game fills the frame, two round webcams on top (duo streams)"),
    "duo_split":     (.30, ("cam", "cam2"), "two webcams side by side on top, game below"),
    "filler":        (.50, (), "content on top, looping filler video (parkour/satisfying) below"),
    "story_card":    (.30, (), "text card on top (headline/title/--card TEXT), the content below"),
    "story_filler":  (.30, ("filler",), "text card on top, looping filler video below (story-time format)"),
    "speaker_pip":   (0, (), "follows whoever speaks full-frame, a small round window shows the other person (needs both visible: the speaker map decides)"),
}
SWAPPABLE = {"split", "basecam", "half", "game_ui", "mosaic", "duo_split", "filler"}  # --swap puts the game on top
CARD = ("story_card", "story_filler")  # their top strip is a text card drawn in the caption file (captions.build card=...)
NO_REGION_NEEDS = {"story_filler": ()}


def parse_box(s):
    """'x,y,w,h' (fractions of the source frame) -> [x, y, w, h]; rejects anything outside the frame."""
    v = [float(x) for x in str(s).split(",")]
    if len(v) != 4 or min(v) < 0 or v[2] <= 0 or v[3] <= 0 or v[0] + v[2] > 1.0001 or v[1] + v[3] > 1.0001:
        raise ValueError(f"region must be x,y,w,h as fractions inside 0..1 (got {s!r})")
    return v


def missing(layout, regions, filler=None):
    """Names of what the layout still needs (regions, or 'filler'); empty = renderable."""
    need = [r for r in LAYOUTS[layout][1] if r not in (regions or {}) and r != "filler"]
    if layout in ("filler", "story_filler") and not filler:
        need.append("filler")
    return need


def recommend(profile, aspect, speakers=None):
    """Local starting point only (the model looks at the frame and decides; the user approves). -> [{"layout", "why", "needs"}]"""
    if aspect <= 9 / 16 + 0.01:
        return [{"layout": "fill", "why": "the source is already vertical", "needs": []}]
    if profile in ("gaming", "sports"):
        return [{"layout": "split", "why": "gameplay with a streamer webcam: webcam strip on top, game below", "needs": ["cam"]},
                {"layout": "circle_facecam", "why": "keep the whole game visible with a small round webcam", "needs": ["cam"]},
                {"layout": "fit", "why": "no webcam: whole frame over a blurred backdrop", "needs": []}]
    if speakers and speakers >= 2:
        return [{"layout": "split", "why": "two people on screen: stack them", "needs": []}, {"layout": "fill", "why": "follow whoever speaks", "needs": []}]
    return [{"layout": "fill", "why": "one subject: 9:16 crop that follows them", "needs": []}, {"layout": "fit", "why": "wide scene or graphics that must stay visible", "needs": []}]


def band(layout, pct=None):
    return LAYOUTS[layout][0] if pct is None else min(max(float(pct), .15), .6)


def slots(layout, pct=None, swap=False):
    """-> [(region, (x, y, w, h), shape)] back to front. Rect w/h of 0 for h means 'derive from the region aspect' (overlays)."""
    b = band(layout, pct)
    if layout in ("small_facecam", "circle_facecam"):
        shape = SQ if layout == "circle_facecam" else "rect"
        return [("game", (0, 0, 1, 1), "rect"), ("cam", (.60, .06, .34, 0), shape)]
    if layout == "dual_facecam":
        return [("game", (0, 0, 1, 1), "rect"), ("cam", (.10, .06, .30, 0), SQ), ("cam2", (.60, .06, .30, 0), SQ)]
    if layout == "fullscreen":
        return [("game", (0, 0, 1, 1), "rect")]
    if layout in CARD:  # top strip = card (drawn by captions), main area = content or filler
        return [("filler" if layout == "story_filler" else "game", (0, b, 1, 1 - b), "rect"), ("card", (0, 0, 1, b), "rect")]
    if layout == "basecam":
        layout, swap = "split", True
    top = {"split": [("cam", (0, 0, 1, b), "rect")], "half": [("cam", (0, 0, 1, b), "rect")],
           "game_ui": [("cam", (0, 0, 1, b), "rect")], "mosaic": [("cam", (0, 0, .5, b), "rect"), ("ui", (.5, 0, .5, b), "rect")],
           "duo_split": [("cam", (0, 0, .5, b), "rect"), ("cam2", (.5, 0, .5, b), "rect")], "filler": [("game", (0, 0, 1, b), "rect")]}[layout]
    my, shift = (0, 1 - b) if swap else (b, 0)  # swap: the main area goes on top, the strip to the bottom
    out = [("filler" if layout == "filler" else "game", (0, my, 1, 1 - b), "rect")] + [(r, (x, y + shift, w, h), sh) for r, (x, y, w, h), sh in top]
    if layout == "game_ui":
        out.append(("ui", (.03, my + .02, .40, 0), "rect"))
    return out


def graph(layout, regions, w, h, fps, pct=None, swap=False, filler_idx=None, sc="flags=lanczos"):
    """filter_complex fragment: [0:v] (+ [filler_idx:v]) -> [base]."""
    even = lambda v: max(2, int(round(v / 2)) * 2)
    sl = slots(layout, pct, swap and layout in SWAPPABLE)
    src = [r for r, _, _ in sl if r not in ("filler", "card")]
    n = len(src)
    g = [f"[0:v]split={n}" + "".join(f"[r{i}]" for i in range(n))] if n > 1 else (["[0:v]null[r0]"] if n == 1 else [])
    g.append(f"color=c=black:s={w}x{h}:r={fps:.3f}[c0]")
    cur, k = "c0", 0
    for j, (r, (x, y, ww, hh), shape) in enumerate(sl):
        lab = f"s{j}"
        if r == "card":  # nothing to composite: the black canvas is the card's backdrop, the card itself is an ASS drawing
            if j == len(sl) - 1:
                g.append(f"[{cur}]null[base]")
            continue
        if r == "filler":
            g.append(f"[{filler_idx}:v]scale={even(ww * w)}:{even(hh * h)}:force_original_aspect_ratio=increase:{sc},crop={even(ww * w)}:{even(hh * h)},setsar=1,fps={fps:.3f}[{lab}]")
        else:
            box = (regions or {}).get(r) or [0, 0, 1, 1]
            cr = f"crop=iw*{box[2]:.4f}:ih*{box[3]:.4f}:iw*{box[0]:.4f}:ih*{box[1]:.4f}"
            if hh:  # fixed rect: zoom to fill
                g.append(f"[r{k}]{cr},scale={even(ww * w)}:{even(hh * h)}:force_original_aspect_ratio=increase:{sc},crop={even(ww * w)}:{even(hh * h)},setsar=1[{lab}]")
            elif shape == SQ:  # round cut-out, diameter = ww of the frame
                d = even(ww * w)
                g.append(f"[r{k}]{cr},crop='min(iw,ih)':'min(iw,ih)',scale={d}:{d}:{sc},setsar=1,format=yuva420p,"
                         f"geq=lum='p(X,Y)':cb='p(X,Y)':cr='p(X,Y)':a='if(lte(hypot(X-{d / 2},Y-{d / 2}),{d / 2}),255,0)'[{lab}]")
            else:  # overlay keeps the region's aspect
                g.append(f"[r{k}]{cr},scale={even(ww * w)}:-2:{sc},setsar=1[{lab}]")
            k += 1
        nxt = "base" if j == len(sl) - 1 else f"c{j + 1}"
        g.append(f"[{cur}][{lab}]overlay={int(x * w)}:{int(y * h)}:format=auto[{nxt}]")
        cur = nxt
    return ";".join(g)
