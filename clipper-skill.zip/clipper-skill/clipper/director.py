"""Edit director: decides WHAT the edit does (tight cuts, zoom rhythm, overlays, sound effects, music) from the words. Pure functions, no ffmpeg:
everything here is unit-testable. studio.py turns the returned plan into one ffmpeg call.

Rules are the ones short-form editors converge on: hook in the first 3 s, a pattern interrupt every few seconds (here: a jump cut + a wide/tight
zoom change), emphasis on the payoff word, sound effects sparse and tied to a visible event, music 20+ dB under speech and ducked while talking."""
import re
from . import boundaries as B

FPS = 30
FILLER = {"um", "uh", "umm", "uhh", "erm", "er", "ah", "hmm", "mm"}
POWER = re.compile(r"\b(never|always|worst|best|biggest|secret|truth|lie[ds]?|fake|scam|shocking|insane|crazy|unbelievable|nobody|everyone|mistake|dangerous|"
                   r"illegal|banned|free|million|billion|dead|died|fired|destroy\w*|exposed|wrong|actually|honestly|literally|stop|warning|impossible|proof)\b", re.I)
CONTRAST = re.compile(r"\b(but|however|except|instead|turns out|until|the problem is|here'?s the thing|the reality|the truth)\b", re.I)
STORY = re.compile(r"\b(i (was|had|got|went|thought|realized|found|lost|made)|when i|one day|and then)\b", re.I)
NUMBER = re.compile(r"(?:[$₹€£]|rs\.?\s?)?\d[\d,]*(?:\.\d+)?\s?(?:%|percent|million|billion|thousand|crore|lakh|k\b|x\b|times)?", re.I)
FLUFF = re.compile(r"\b(subscribe|welcome back|sponsor(ed)?|link in (the )?description|hit the bell|before we (start|begin)|thanks for watching|use code|promo code)\b", re.I)
WEAK_OPEN = re.compile(r"^\W*(yeah|yes|okay|ok|so|um|uh|well|right|and|but|like|you know|i mean|anyway|alright|hmm|hey|hi|hello|welcome)\b", re.I)
DANGLING = {"but", "and", "so", "then", "to", "the", "a", "of", "that", "because", "or", "with", "in", "on", "for", "is", "was", "if", "when", "we", "i", "you", "they", "it"}
MOOD_WORDS = {
    "funny": r"\b(lol|haha+|funny|joke|hilarious|laugh\w*|ridiculous|meme)\b",
    "tense": r"\b(scam|fraud|danger\w*|kill\w*|dead|died|warning|secret|expose\w*|lie[ds]?|fake|illegal|toxic|poison|antibiotics?|unsafe|risk\w*)\b",
    "inspire": r"\b(success|dream\w*|believe|grow\w*|journey|mindset|hustle|goal|passion|never give up|build|win)\b",
    "epic": r"\b(history|war|empire|legend\w*|ancient|battle|king|revolution|champion)\b",
}

# one dict per viral style. gap: pauses longer than this are cut (None = keep every pause). zoom: wide/tight levels alternated at every cut.
# emph: snap-zoom on the payoff word. sfx: density. music_db: level of the bed under speech (relative to normalised voice).
STYLES = {
    "viral":     dict(gap=0.40, zoom=(1.0, 1.10), emph=1.18, hook=True, callouts=True, progress=True, sfx=3.5, music_db=-21, mood="upbeat", flash=False,
                      caps="bold_pop", grade="eq=contrast=1.06:saturation=1.12"),
    "podcast":   dict(gap=0.55, zoom=(1.0, 1.06), emph=1.10, hook=True, callouts=True, progress=False, sfx=5.0, music_db=-24, mood="chill", flash=False,
                      caps="highlight_words", grade="eq=contrast=1.03:saturation=1.05"),
    "hype":      dict(gap=0.28, zoom=(1.0, 1.14), emph=1.22, hook=True, callouts=True, progress=True, sfx=2.4, music_db=-19, mood="upbeat", flash=True,
                      caps="gaming_bold", grade="eq=contrast=1.08:saturation=1.2"),
    "cinematic": dict(gap=None, zoom=(1.0,), emph=1.0, hook=True, callouts=False, progress=False, sfx=6.0, music_db=-22, mood="epic", flash=False,
                      caps="cinematic", grade="eq=contrast=1.08:saturation=0.92,colorbalance=rs=.05:bs=-.05:rh=.05:bh=-.04,vignette=PI/7"),
    "edu":       dict(gap=0.50, zoom=(1.0, 1.06), emph=1.10, hook=True, callouts=True, progress=True, sfx=5.0, music_db=-24, mood="chill", flash=False,
                      caps="boxed", grade="eq=contrast=1.03:saturation=1.05"),
    "gamer":     dict(gap=None, zoom=(1.0,), emph=1.0, hook=True, callouts=False, progress=True, sfx=2.4, music_db=-20, mood="upbeat", flash=True,
                      caps="gaming_bold", grade="eq=contrast=1.08:saturation=1.2"),
}


def style_for(name, profile):
    """'auto' -> by content profile; unknown -> ValueError. 'classic' is handled by the caller (old renderer)."""
    if name in (None, "auto"):
        name = {"gaming": "gamer", "sports": "hype", "comedy": "viral", "podcast": "viral", "interview": "viral"}.get(profile, "viral")
    if name not in STYLES:
        raise ValueError(f"unknown edit style {name!r}; choose from {sorted(STYLES)}, auto or classic")
    return name, STYLES[name]


# ---------------------------------------------------------------- virality (local, free)
def text_score(text):
    """0..1 'would this make someone stop' from the words alone. Cheap and explainable; the LLM (if any) refines it."""
    t = text.strip()
    if not t:
        return 0.0
    first = re.split(r"(?<=[.?!])\s", t, maxsplit=1)[0]
    s = 0.1 * min(3, len(POWER.findall(t))) + 0.1 * bool(CONTRAST.search(t)) + 0.1 * bool(STORY.search(t))
    s += 0.1 * bool(re.search(r"\d", t)) + 0.1 * (("?" in t) or ("!" in t)) + 0.1 * bool(re.search(r"\b(you|your|we|i)\b", t, re.I))
    s += 0.15 * bool(re.search(r"^\W*(why|how|what|nobody|never|everyone|stop|don'?t|you|the (best|worst|biggest|only|real)|this|i )", first, re.I))
    s += 0.1 * (4 <= len(first.split()) <= 18)
    return round(max(0.0, min(1.0, s - (0.5 if FLUFF.search(t) else 0.0))), 3)


def tighten(clip, words, sents=None, keep_s=18.0, max_trim_s=9.0):
    """Start on the strongest opening: drop weak lead-in sentences ('So yeah, um...') when a later sentence in the first seconds is a better hook,
    the result stays a complete thought (next sentence is not a dependent clause) and the clip keeps >= keep_s. Mutates and returns clip."""
    if clip.get("kind") == "event" or not clip.get("final_words") or not words:
        return clip
    sents = sents or B.sentences(words)
    a, b = clip["final_words"]
    for _ in range(2):
        k = B._sent_of(sents, a)
        if k + 1 >= len(sents) or sents[k][1] >= b:
            break
        s0, s1 = sents[k], sents[k + 1]
        first, nxt = B._text(words, *s0), B._text(words, *s1)
        weak = bool(WEAK_OPEN.search(first)) or len(first.split()) <= 4 or text_score(first) + 0.12 <= text_score(nxt)
        dep = B._first(words, s1[0]) in B.DEPENDENT
        ok = (words[s1[0]]["s"] - clip["final_start"] <= max_trim_s and clip["final_end"] - words[s1[0]]["s"] >= keep_s and not dep
              and text_score(nxt) >= text_score(first))
        if not (weak and ok):
            break
        a = s1[0]
        clip["final_words"] = [a, b]
        clip["final_start"] = round(max(clip["final_start"], words[a]["s"] - B.PAD_IN, (words[a - 1]["e"] + words[a]["s"]) / 2), 3)
        clip["text"] = B._text(words, a, b)
        clip["tightened"] = True
    return clip


def hook_text(clip, words, limit=8):
    """On-screen headline for the first seconds: the LLM title if there is one, else the strongest sentence of the clip, shortened."""
    t = (clip.get("title") or "").strip()
    if not t:
        sents = B.sentences(words) if words else []
        best = max((B._text(words, a, b) for a, b in sents), key=text_score, default="")
        t = best
    t = re.sub(r"\s+", " ", re.sub(r"^\W*(so|and|but|yeah|well|okay|um|uh)\b[ ,]*", "", t, flags=re.I)).strip()
    ws = t.split()
    if len(ws) > limit:  # cut at a comma inside the limit if there is one, else at the limit; never end on a dangling connector
        cut = next((k for k in range(limit, 3, -1) if ws[k - 1].endswith((",", ";", ":"))), limit)
        ws = ws[:cut]
        while len(ws) > 3 and ws[-1].strip(",;:").lower() in DANGLING:
            ws.pop()
    t = " ".join(ws).rstrip(",;:-")
    return t[:1].upper() + t[1:] if t else ""


def mood_for(text, profile, default):
    hits = {m: len(re.findall(p, text, re.I)) for m, p in MOOD_WORDS.items()}
    m, n = max(hits.items(), key=lambda kv: kv[1])
    return m if n >= 2 else ("upbeat" if profile in ("gaming", "sports") else default)


def callouts(words, t0, dur, gap=6.0, first=3.4, max_n=3):
    """Numbers/money/percentages shown big for ~1.4 s as they are spoken. Times relative to the clip."""
    out = []
    for w in words:
        tok = w["w"].strip(".,!?\"'")
        rel = w["s"] - t0
        if rel < first or rel > dur - 2.0 or not NUMBER.fullmatch(tok):
            continue
        txt = tok
        nxt = next((x for x in words if x["s"] > w["s"]), None)  # attach a spoken unit ("10 million", "50 percent")
        if nxt and re.fullmatch(r"(?i)(million|billion|thousand|percent|crore|lakh|times|dollars|rupees|k|x)\W*", nxt["w"]):
            txt += " " + nxt["w"].strip(".,!?\"'")
        if len(re.sub(r"\D", "", tok)) >= 2 or txt != tok:  # skip lone 'one'-like digits
            if not out or rel - out[-1]["t"] >= gap:
                out.append({"t": round(rel, 2), "dur": 1.4, "text": txt.upper()})
    return out[:max_n]


def emphasis_points(words, t0, dur, gap=6.0, first=3.6, max_n=None):
    """Clip-relative times of payoff words: power words / numbers at the end of a sentence or right after a pause. One snap-zoom each."""
    out = []
    for i, w in enumerate(words):
        rel = w["s"] - t0
        if rel < first or rel > dur - 3.0:
            continue
        tok = w["w"].strip(".,!?\"'")
        strong = bool(POWER.fullmatch(tok)) or bool(NUMBER.fullmatch(tok) and len(tok) > 1)
        after_pause = i > 0 and w["s"] - words[i - 1]["e"] >= 0.35
        ends = bool(B.END.search(w["w"]))
        if strong and (after_pause or ends or i + 1 < len(words) and words[i + 1]["s"] - w["e"] >= 0.35):
            if not out or rel - out[-1] >= gap:
                out.append(round(rel, 2))
    return out[:max_n if max_n is not None else max(1, int(dur // 12))]


def max_zoom(src_h):
    """Zoom is a crop of the SOURCE then one resample, so the limit is source pixels: never ask for a crop below ~720 source lines."""
    return 1.25 if src_h >= 1080 else 1.16 if src_h >= 720 else 1.06


# ---------------------------------------------------------------- cuts
def keep_ranges(words, s, e, gap, pad_in=0.10, pad_out=0.14, max_cut=0.30):
    """Absolute (a, b) ranges to KEEP: silence longer than `gap` and filler words are cut, with a little air left around speech.
    No cuts for sparse speech (gameplay, music). Never removes more than max_cut of the clip: if it would, the threshold is relaxed once."""
    cw = [w for w in words if s - 0.01 <= w["s"] < e - 0.05]
    if not gap or len(cw) < 8 or len(cw) / max(e - s, 1) < 0.9:
        return [(s, e)]
    for g in (gap, gap * 1.8):
        rs, cur_a, prev, fill = [], s, None, False
        for w in cw:
            if w["w"].lower().strip(".,!?") in FILLER:
                fill = True
                continue
            if prev is not None:
                end, new_a = prev["e"] + pad_out, w["s"] - pad_in
                if (w["s"] - prev["e"] > g or fill) and new_a - end >= 0.12:  # a real gap, with room for the air we leave on both sides
                    rs.append((cur_a, end))
                    cur_a = new_a
            fill, prev = False, w
        rs.append((cur_a, e))
        rs = [(max(s, a), min(e, b)) for a, b in rs if b - a >= 0.25]
        if rs and sum(b - a for a, b in rs) >= (1 - max_cut) * (e - s):
            return rs
    return [(s, e)]


def snap(ranges, s):
    """Quantise to the 30 fps grid RELATIVE to the clip start so audio and picture segments have identical lengths (no drift). -> [(a, b)] clip-relative."""
    out, t = [], 0.0
    for a, b in ranges:
        ra = round((a - s) * FPS) / FPS
        rb = max(round((b - s) * FPS) / FPS, ra + 2 / FPS)
        ra = max(ra, out[-1][1] if out else 0.0)  # keep strictly forward
        if rb - ra >= 2 / FPS:
            out.append((round(ra, 4), round(rb, 4)))
    return out


def tmap(segs, t):
    """clip-relative source time -> output time (None if it falls in a removed gap: snapped to the next kept moment)."""
    o = 0.0
    for a, b in segs:
        if t < a:
            return o
        if t <= b:
            return o + (t - a)
        o += b - a
    return o


def focus_at(clip, cr, t):
    """x position (0..1) the planned framing has at clip-relative time t (same keyframes the classic renderer uses)."""
    shots = clip.get("focus_auto") or [[[0.0, 0.5]]]
    kf = shots[min(sum(1 for c in cr if c <= t), len(shots) - 1)]
    if clip.get("focus_x") is not None:
        return float(clip["focus_x"])
    if t <= kf[0][0]:
        return kf[0][1]
    for (t0, x0), (t1, x1) in zip(kf, kf[1:]):
        if t0 <= t < t1:
            return x0 + (x1 - x0) * (t - t0) / max(t1 - t0, 0.01)
    return kf[-1][1]


def plan(clip, words, info, style, profile, cr, cuts_on=True, layout="fill", music=True, sfx_on=True, user_hook=None):
    """-> dict: segs [{a,b,o,z,x,cut}] (a,b clip-relative source; o output start), dur, hook, callouts, flashes, sfx [{t,kind}], mood, words (output timeline),
    removed_s. Zoom/x only matter for the fill layout; other layouts get z=1."""
    s, e = clip["final_start"], clip["final_end"]
    cw = [w for w in words if s - 0.01 <= w["s"] < e - 0.05]
    rng = keep_ranges(words, s, e, style["gap"] if cuts_on else None)
    rel = snap(rng, s) or [(0.0, round((e - s) * FPS) / FPS)]
    # hard splits that are not removals: scene cuts (the subject moves) and emphasis snap-zooms
    zmax = max_zoom(info["height"]) if layout == "fill" else 1.0
    wide, tight = style["zoom"][0], min(style["zoom"][-1], zmax)
    q = lambda t: round(round(t * FPS) / FPS, 4)  # every split lands on the frame grid, or audio and picture drift apart
    emph = [q(t) for t in (emphasis_points(cw, s, e - s) if style["emph"] > 1 else []) if layout == "fill"]
    cr = [q(c) for c in cr]
    segs, o = [], 0.0
    for k, (a, b) in enumerate(rel):
        pts = sorted({round(c, 4) for c in cr if a + 0.4 < c < b - 0.4})
        pts += [t for t in emph if a + 0.6 < t < b - 0.3]
        edges = [a] + sorted(set(pts)) + [b]
        base = wide if k == 0 else (style["zoom"][k % len(style["zoom"])] if len(style["zoom"]) > 1 else wide)
        base = min(base, zmax)
        for i, (x0, x1) in enumerate(zip(edges, edges[1:])):
            if x1 - x0 < 2 / FPS:
                continue
            z = base
            if any(abs(x0 - t) < 0.02 for t in emph):  # snap-zoom on the payoff word, back to the base level at the next cut
                z = min(max(base + 0.08, style["emph"]), zmax)
            mid = (x0 + x1) / 2
            segs.append({"a": x0, "b": x1, "o": round(o, 4), "z": round(z, 3), "x": round(focus_at(clip, cr, mid), 3), "cut": i == 0 and k > 0, "shot": sum(1 for c in cr if c <= mid),
                         "gap_before": round(rel[k][0] - rel[k - 1][1], 2) if i == 0 and k > 0 else 0.0})
            o += x1 - x0
    dur = round(o, 4)
    ow = []  # words on the output timeline
    for w in cw:
        if w["w"].lower().strip(".,!?") in FILLER:
            continue
        ws, we = w["s"] - s, w["e"] - s
        if any(a - 0.02 <= ws < b for a, b in rel):
            ow.append({**w, "s": tmap(rel, ws), "e": min(tmap(rel, we), tmap(rel, ws) + (we - ws))})
    co = [{**c, "t": round(tmap(rel, c["t"]), 2)} for c in (callouts(cw, s, e - s) if style["callouts"] else [])]
    hook = None
    if style["hook"] and dur >= 8:
        hook = user_hook if user_hook is not None else hook_text(clip, cw)
        hook = hook or None
    # sound effects: each tied to something visible; spacing by style density; never over the first word
    ev = []
    def add(t, kind, db=0):
        if sfx_on and 0.05 <= t <= dur - 0.4 and all(abs(t - u["t"]) >= style["sfx"] * (0.5 if kind in ("pop", "ding") else 1) for u in ev):
            ev.append({"t": round(t, 2), "kind": kind, "db": db})
    if hook:
        add(0.12, "pop")
    for sg in segs:
        if sg["gap_before"] >= 0.9 or (style["flash"] and sg["cut"]):
            add(sg["o"] - 0.12, "swipe")
        elif any(abs(sg["a"] - t) < 0.02 for t in emph):
            add(sg["o"] - 0.05, "thud", -2)
    for c in co:
        add(c["t"], "ding")
    flashes = [round(sg["o"], 2) for sg in segs if style["flash"] and (sg["cut"] or sg["z"] > tight)][:12]
    mood = (mood_for(" ".join(w["w"] for w in cw), profile, style["mood"]) if music else None)
    return {"segs": segs, "dur": dur, "hook": hook, "callouts": co, "flashes": flashes, "sfx": sorted(ev, key=lambda u: u["t"]), "mood": mood,
            "words": ow, "ranges": rel, "removed_s": round((e - s) - dur, 2), "emphasis": emph}
