"""ASS caption generator (deterministic, libass-rendered). Word timing comes straight from the transcript.
Fonts are bundled (SIL OFL, clipper/fonts) and passed to libass via fontsdir, so rendering never depends on system fonts (Arial is not on Linux)."""
import json, re, shutil, textwrap
from pathlib import Path
from .boundaries import END

W, H = 1080, 1920
FONTS = Path(__file__).parent / "fonts"
WHITE, YELLOW, BLACK, GREEN, CYAN, ORANGE, PINK, GREY = "&H00FFFFFF", "&H0000E5FF", "&H00000000", "&H0055FF55", "&H00FFE600", "&H000080FF", "&H00B469FF", "&H00C8C8C8"  # &HAABBGGRR
FONT_FAMILIES = {"Poppins ExtraBold", "Poppins", "Poppins Medium", "Anton", "Bebas Neue"}  # families present in clipper/fonts
# mode: pop = whole chunk, active word recoloured | karaoke = \kf fill | plain = no highlight | speaker = plain, colour by who speaks | type = words appear one by one
# border: 1 = outline+shadow, 3 = opaque box.  pos: bottom margin (px of 1920); anim: none | pop (scale-in) | fade
BASE = dict(font="Poppins ExtraBold", size=80, primary=WHITE, hi=YELLOW, outline_color=BLACK, outline=6, shadow=0, border=1, box_color="&H80000000",
            mv=430, words=3, max_chars=0, mode="pop", upper=False, anim="none", bold=0, spacing=0, align=2,
            hi_outline=None, hi_bord=0, glow=0, glow_color=CYAN, emph=None, emph_scale=112, emoji=0)  # hi_outline+hi_bord = thick coloured outline on the active word = "pill"; glow = blurred copy underneath
PRESETS = {
    "bold_pop":        dict(size=86, outline=7, words=3, upper=True, anim="pop", emph=ORANGE, emoji=1),
    "karaoke":         dict(font="Poppins Bold", size=78, hi=GREEN, outline=6, words=4, mode="karaoke"),
    "clean_lower":     dict(font="Poppins Medium", size=54, outline=3, shadow=1, mv=300, words=7, mode="plain"),
    "boxed":           dict(font="Poppins Bold", size=62, outline=14, border=3, mv=380, words=5, mode="pop"),
    "minimal_white":   dict(font="Poppins Medium", size=50, outline=2, shadow=2, mv=280, words=8, mode="plain", anim="fade"),
    "highlight_words": dict(font="Poppins Bold", size=70, hi=ORANGE, outline=5, words=4, mode="pop", emph=YELLOW),
    "podcast_speaker": dict(font="Poppins Bold", size=60, outline=5, words=6, mode="speaker", mv=360),
    "gaming_bold":     dict(font="Anton", size=96, hi=CYAN, outline=8, shadow=3, words=3, upper=True, anim="pop", mv=470, emph=YELLOW, emoji=1),
    "cinematic":       dict(font="Bebas Neue", size=84, primary=GREY, hi=WHITE, outline=2, shadow=2, words=6, mode="pop", mv=250, spacing=3, upper=True, anim="fade"),
    # --- styles seen in SupoClip / Chopify / OpenShorts / AutoShorts / Clips Kitty, plus our own viral additions
    "hormozi":         dict(size=84, hi=WHITE, hi_outline="&H0049BF00", hi_bord=14, outline=6, words=3, upper=True, anim="pop", mv=520, emph=YELLOW, emoji=1),
    "mrbeast":         dict(font="Anton", size=108, primary=YELLOW, hi="&H002D2DFF", outline=12, shadow=3, words=3, upper=True, anim="pop", mv=500, emph=WHITE, emoji=1),
    "tiktok":          dict(size=80, hi=PINK, outline=8, words=4, anim="pop", emph=CYAN, emoji=1),
    "neon":            dict(size=74, primary=CYAN, hi="&H00FF00FF", outline=2, outline_color=CYAN, words=3, upper=True, glow=1, glow_color="&H00FF00FF", emph=WHITE),
    "typewriter":      dict(font="Poppins Medium", size=60, outline=4, words=6, mode="type", spacing=2, mv=380),
    "retro":           dict(font="Bebas Neue", size=96, primary="&H00B4E6FF", hi="&H004B8CFF", outline=4, outline_color="&H00204080", shadow=8, words=4, upper=True, spacing=2, anim="fade"),
    "bold":            dict(size=90, outline=8, words=3, upper=True, mode="plain"),
    "single_word":     dict(font="Anton", size=120, outline=14, words=1, upper=True, mode="plain", anim="pop", align=5, mv=0),
    "marker":          dict(size=66, primary=BLACK, hi=BLACK, border=3, box_color="&H0000E5FF", outline=14, words=3, upper=True, mode="plain", mv=480),
    "hook_alert":      dict(font="Anton", size=100, border=3, box_color="&H002D2DFF", outline=16, words=3, upper=True, mode="plain", align=8, mv=260),
    "fire":            dict(font="Anton", size=104, primary=YELLOW, hi=ORANGE, outline=10, outline_color="&H00001A80", shadow=4, words=3, upper=True, anim="pop", glow=1, glow_color=ORANGE, emph=WHITE, emoji=1),
}
# names used by other clippers -> our closest preset
ALIASES = {"default": "bold_pop", "pop": "bold_pop", "clean": "clean_lower", "minimal": "minimal_white", "podcast": "podcast_speaker"}
SPEAKER_COLORS = [YELLOW, CYAN, PINK, GREEN]


def style(name_or_dict, style_file=None):
    """-> full style dict. `custom` takes overrides from a JSON file (style_file) or a dict; unknown keys are rejected, fonts must be bundled
    or you accept system lookup (a warning key `font_is_system` is set)."""
    if isinstance(name_or_dict, dict) or name_or_dict == "custom":
        over = name_or_dict if isinstance(name_or_dict, dict) else json.loads(Path(style_file).read_text())
        bad = set(over) - set(BASE)
        if bad:
            raise ValueError(f"unknown caption style keys: {sorted(bad)}")
        st = {**BASE, **PRESETS["bold_pop"], **over}
    else:
        name_or_dict = ALIASES.get(name_or_dict, name_or_dict)
        if name_or_dict not in PRESETS:
            raise ValueError(f"unknown caption style {name_or_dict!r}; choose from {sorted(PRESETS)} or custom")
        st = {**BASE, **PRESETS[name_or_dict]}
    st["font_is_system"] = st["font"] not in FONT_FAMILIES
    return st


def _t(x):
    x = max(0.0, x)
    return f"{int(x // 3600)}:{int(x % 3600 // 60):02d}:{x % 60:05.2f}"


def _clean(w):
    return re.sub(r"[{}\\]", "", w)


def chunks(words, p, scale=1.0):
    """Group words into short lines; break on punctuation, pauses, word count, character limit, or estimated overflow (never overflows the frame)."""
    maxw = int((W - 160) / (p["size"] * scale * 0.58))
    if p.get("max_chars"):
        maxw = min(maxw, int(p["max_chars"]))
    out, cur = [], []
    for k, w in enumerate(words):
        cur.append(w)
        nxt = words[k + 1] if k + 1 < len(words) else None
        n = sum(len(x["w"]) + 1 for x in cur) + (len(nxt["w"]) + 1 if nxt else 0)
        if nxt is None or len(cur) >= p["words"] or END.search(w["w"]) or nxt["s"] - w["e"] > 0.6 or n > maxw:
            out.append(cur)
            cur = []
    return out


def overflow(words, p, scale=1.0):
    """Number of caption groups whose estimated width exceeds the safe width (should always be 0 given chunks())."""
    return sum(1 for ch in chunks(words, p, scale) if sum(len(x["w"]) + 1 for x in ch) * p["size"] * scale * 0.58 > W - 100)


def _fx(p, dur):
    if p["anim"] == "pop":
        return r"{\fscx70\fscy70\t(0,120,\fscx100\fscy100)}"
    if p["anim"] == "fade":
        return r"{\fad(120,80)}"
    return ""


# ---------------------------------------------------------------------------------------------- per-moment style
def auto_style(profile, clip=None, speakers_reliable=False):
    """`--style auto`: choose the caption preset for THIS clip from what it is. Heuristic table, not a measured optimum: change it in one place.
    Inputs: the content profile, the judge's hook_type/emotion (when the model judged it), whether the speaker map is reliable, and whether it is an event clip."""
    clip = clip or {}
    j = clip.get("judge") or {}
    ht, emo = j.get("hook_type"), j.get("emotion", 0)
    if clip.get("kind") == "event" or profile in ("gaming", "sports"):
        return "fire" if (emo >= 8 or profile == "sports") else "gaming_bold"
    if ht in ("reaction", "action") or (profile == "comedy" and emo >= 7):
        return "mrbeast"
    if ht == "story":
        return "cinematic"
    if ht in ("statistic", "bold_claim", "contrast"):
        return "hormozi"
    if ht in ("question", "cliffhanger") or profile in ("irl", "comedy"):
        return "tiktok"
    if profile in ("podcast", "interview"):
        return "podcast_speaker" if speakers_reliable else "hormozi"
    return "bold_pop"


def effective_style(name, profile="", clip=None, speakers_reliable=False):
    """Preset name the renderer will use: `auto` is resolved per clip, everything else is returned as is. Use this anywhere a style NAME is turned into a preset."""
    return auto_style(profile, clip, speakers_reliable) if (name or "auto") == "auto" else name


# ---------------------------------------------------------------------------------------------- emphasis + emoji
POWER = re.compile(r"^(\$?\d[\d,.]*[kmbx%]?|never|always|nobody|everyone|every|best|worst|biggest|million|billion|thousand|free|secret|crazy|insane|stop|huge|only|first|last|"
                   r"impossible|illegal|dead|die|died|love|hate|wrong|mistake|truth|lie|lied|fired|banned|won|lost|zero|nothing|everything)$", re.I)
EMOJI = {"money": "1f4b0", "cash": "1f4b5", "spend": "1f4b8", "fire": "1f525", "laugh": "1f602", "lol": "1f923", "shock": "1f631", "wow": "1f62e", "mindblown": "1f92f", "skull": "1f480",
         "heart": "2764", "brain": "1f9e0", "rocket": "1f680", "trophy": "1f3c6", "target": "1f3af", "warning": "26a0", "check": "2705", "cross": "274c", "eyes": "1f440", "clap": "1f44f",
         "hundred": "1f4af", "star": "2b50", "crown": "1f451", "up": "1f4c8", "down": "1f4c9", "phone": "1f4f1", "game": "1f3ae", "car": "1f697", "time": "23f0", "lock": "1f512",
         "idea": "1f4a1", "yes": "1f44d", "no": "1f44e", "sad": "1f622", "angry": "1f621", "cool": "1f60e", "think": "1f914", "sleep": "1f634", "love": "1f60d", "gift": "1f381",
         "bomb": "1f4a3", "party": "1f389", "strong": "1f4aa", "pray": "1f64f", "sparkle": "2728", "world": "1f30d", "food": "1f355", "stop": "1f6d1", "dollar": "1f4b5", "hmm": "1f9d0",
         "shrug": "1f937"}
EMOJI_DIR = Path(__file__).parent / "emoji"
KEYWORDS = [(re.compile(rx, re.I), name) for rx, name in (
    (r"^(money|dollars?|cash|rich|salary|million|billion|paid|profit)$", "money"), (r"^(fire|insane|crazy|lit|hot)$", "fire"), (r"^(funny|hilarious|lol|laugh|laughing|haha+|joke)$", "laugh"),
    (r"^(wow|omg|shocking|unbelievable|shocked)$", "shock"), (r"^(dead|died|dies|kill|killed|death)$", "skull"), (r"^(love|loved|favorite|heart)$", "heart"),
    (r"^(brain|smart|genius|mind)$", "brain"), (r"^(win|won|winner|champion|trophy)$", "trophy"), (r"^(goal|target|aim|focus)$", "target"),
    (r"^(warning|careful|danger|dangerous|never)$", "warning"), (r"^(secret|hidden|watch|look)$", "eyes"), (r"^(rocket|launch|grow|growth|fast)$", "rocket"),
    (r"^(idea|trick|hack|tip|tips)$", "idea"), (r"^(game|gaming|clutch|gamer)$", "game"), (r"^(car|drive|driving)$", "car"), (r"^(lock|private|password)$", "lock"),
    (r"^(gift|free)$", "gift"), (r"^(party|celebrate|birthday)$", "party"), (r"^(strong|gym|workout|muscle)$", "strong"), (r"^(phone|iphone|app)$", "phone"),
    (r"^(increase|rise|rising|up|profit)$", "up"), (r"^(loss|lose|lost|crash|drop|down)$", "down"), (r"^(sad|cry|crying)$", "sad"), (r"^(angry|mad|furious)$", "angry"),
    (r"^(stop)$", "stop"), (r"^(bomb|explode|exploded|boom)$", "bomb"), (r"^(king|queen|crown)$", "crown"), (r"^(pizza|food|eat|burger)$", "food"))]
EMOJI_MIN_GAP, EMOJI_MAX = 4.0, 6


def _plain(w):
    return re.sub(r"[^\w$%']", "", w).lower()


def emoji_file(e):
    """name ('fire'), codepoint ('1f525') or the emoji character -> bundled PNG path, or None (unknown/unbundled)."""
    cp = EMOJI.get(e) or (e if re.fullmatch(r"[0-9a-f-]{2,12}", str(e)) else None) or ("%x" % ord(e[0]) if e and len(e) <= 2 and not e.isascii() else None)
    f = EMOJI_DIR / f"{cp}.png" if cp else None
    return f if f and f.is_file() else None


def resolve(cap, p):
    """Effective per-clip caption options: {"emphasis": bool, "emoji": bool, "edits": dict}. clip override > preset default."""
    cap = cap or {}
    return {"emphasis": cap.get("emphasis", p["emph"] is not None), "emoji": cap.get("emoji", bool(p["emoji"])), "edits": cap.get("edits") or {}}


def validate_edits(edits, lo, hi):
    """Edits the model may make to a clip's captions. Word indices are TRANSCRIPT indices (the ones in the judging packet) and must lie in [lo, hi].
    -> (clean, errors). {"text": {idx: "fix"}, "emphasis": [idx], "unemphasis": [idx], "emoji": [{"word": idx, "emoji": name|codepoint|char, "dur": s}], "no_emoji": [idx]}"""
    ok, errs = {}, []
    if not isinstance(edits, dict):
        return {}, ["edits must be an object"]
    inr = lambda i: isinstance(i, int) and not isinstance(i, bool) and lo <= i <= hi
    for k in ("text",):
        if isinstance(edits.get(k), dict):
            t = {}
            for i, v in edits[k].items():
                try:
                    i = int(i)
                except (TypeError, ValueError):
                    errs.append(f"text: bad index {i!r}")
                    continue
                if inr(i) and isinstance(v, str) and 0 < len(v) <= 40:
                    t[str(i)] = re.sub(r"[\x00-\x1f{}\\]", "", v)
                else:
                    errs.append(f"text[{i}]: index outside the clip [{lo},{hi}] or text empty/too long")
            ok["text"] = t
    for k in ("emphasis", "unemphasis", "no_emoji"):
        if isinstance(edits.get(k), list):
            good = [i for i in edits[k] if inr(i)]
            if len(good) != len(edits[k]):
                errs.append(f"{k}: indices outside the clip [{lo},{hi}] dropped")
            ok[k] = good
    if isinstance(edits.get("emoji"), list):
        ev = []
        for e in edits["emoji"]:
            if isinstance(e, dict) and inr(e.get("word")) and emoji_file(e.get("emoji")):
                ev.append({"word": e["word"], "emoji": e["emoji"], "dur": min(3.0, max(0.5, float(e.get("dur", 1.4))))})
            else:
                errs.append(f"emoji: {e!r} needs a word index inside the clip and a bundled emoji ({', '.join(sorted(EMOJI))})")
        ok["emoji"] = ev
    for k in edits:
        if k not in ("text", "emphasis", "unemphasis", "no_emoji", "emoji"):
            errs.append(f"unknown edit key {k!r}")
    return ok, errs


def prepare(words, p, cap):
    """Clip words -> words with display text (`_t`, edits applied, case applied) and emphasis flag (`_em`). `words` carry their transcript index in w["i"] when known."""
    o = resolve(cap, p)
    ed = o["edits"]
    fix, em_on, em_off = ed.get("text", {}), set(ed.get("emphasis", [])), set(ed.get("unemphasis", []))
    f = (lambda s: s.upper()) if p["upper"] else (lambda s: s)
    out = []
    auto = {id(w) for w in words if _plain(w["w"]) and (POWER.match(_plain(w["w"])) or (len(w["w"]) >= 3 and w["w"].isupper() and w["w"].isalpha()))}
    if len(auto) > max(3, len(words) * 0.4):  # everything emphasised = nothing emphasised
        auto = set()
    for w in words:
        i = w.get("i")
        w2 = dict(w)
        w2["_t"] = f(_clean(fix.get(str(i), w["w"])))
        w2["_em"] = bool(o["emphasis"]) and i not in em_off and (id(w) in auto or i in em_on)
        out.append(w2)
    return out


def emoji_events(words, start, p, cap, dur):
    """-> [{"t": clip-relative s, "dur": s, "file": path}] : explicit (model) emoji, plus automatic keyword emoji when enabled (spaced, capped, never in the first 0.4 s)."""
    o = resolve(cap, p)
    ed, ev = o["edits"], []
    byi = {w.get("i"): w for w in words if w.get("i") is not None}
    for e in ed.get("emoji", []):
        w, f = byi.get(e["word"]), emoji_file(e["emoji"])
        if w and f:
            ev.append({"t": max(0.0, w["s"] - start), "dur": e["dur"], "file": str(f)})
    if o["emoji"]:
        skip = set(ed.get("no_emoji", []))
        last, prev = -99.0, None
        cap_n = min(EMOJI_MAX, max(2, int(dur // 6)))
        for w in words:
            t = w["s"] - start
            if len(ev) >= cap_n:
                break
            if t < 0.4 or t - last < EMOJI_MIN_GAP or w.get("i") in skip or any(abs(t - x["t"]) < EMOJI_MIN_GAP for x in ev):
                continue
            name = next((n for rx, n in KEYWORDS if rx.match(_plain(w["w"]))), None)
            f = emoji_file(name) if name and name != prev else None
            if f:
                ev.append({"t": round(t, 2), "dur": 1.4, "file": str(f)})
                last, prev = t, name
    ev.sort(key=lambda x: x["t"])
    for k, x in enumerate(ev):  # never overlap the next emoji
        if k + 1 < len(ev):
            x["dur"] = round(max(0.5, min(x["dur"], ev[k + 1]["t"] - x["t"] - 0.05)), 2)
        x["dur"] = round(min(x["dur"], max(0.3, dur - x["t"])), 2)
    return [x for x in ev if x["t"] < dur - 0.2][:EMOJI_MAX * 2]


def emoji_y(p, scale=1.0, size_px=140):
    """Top y (px of 1920) of an emoji sitting just above (or below, for top-aligned captions) the caption block."""
    size, mv = int(p["size"] * scale), p["mv"]
    if p["align"] == 8:
        return min(H - size_px - 40, mv + int(size * 1.9))
    if p["align"] == 5:
        return max(40, H // 2 - int(size * 1.1) - size_px)
    return max(40, H - mv - int(size * 1.35) - size_px - 20)


def _rrect(x0, y0, x1, y1, r):
    """ASS drawing path of a rounded rectangle."""
    return (f"m {x0 + r} {y0} l {x1 - r} {y0} b {x1 - r} {y0} {x1} {y0} {x1} {y0 + r} l {x1} {y1 - r} b {x1} {y1 - r} {x1} {y1} {x1 - r} {y1} l {x0 + r} {y1} "
            f"b {x0 + r} {y1} {x0} {y1} {x0} {y1 - r} l {x0} {y0 + r} b {x0} {y0 + r} {x0} {y0} {x0 + r} {y0}")


def card_lines(text, height):
    """Wrap a card text to what fits a card of `height` px: -> (lines, font size)."""
    text = _clean(str(text)).strip()
    for size, width in ((64, 22), (54, 26), (46, 30), (40, 35)):
        lines = textwrap.wrap(text, width, break_long_words=True)
        if len(lines) * size * 1.3 <= height:
            return lines, size
    lines = textwrap.wrap(text, 35, break_long_words=True)[:max(1, int(height // (40 * 1.3)))]
    lines[-1] = lines[-1][:-1] + "…" if lines and not lines[-1].endswith("…") else lines[-1]
    return lines, 40


def build(words, start, preset="bold_pop", scale=1.0, y_offset=0, style_file=None, speaker_at=None, hook=None, progress=None, cap=None, card=None):
    """words: only the clip's words (absolute times; "i" = transcript index if known). start: clip start in source time. speaker_at(t) -> speaker index or None.
    hook: headline text shown in a box at the top for the first 3 s. progress: clip duration in s -> a thin bar along the bottom that fills over the clip.
    cap: the clip's caption dict (emphasis/emoji flags and the model's edits)."""
    p = style(preset, style_file) if not isinstance(preset, dict) or "font_is_system" not in preset else preset
    size, mv = int(p["size"] * scale), p["mv"] + y_offset
    base = p["hi"] if p["mode"] == "karaoke" else p["primary"]
    ocol = p["box_color"] if p["border"] == 3 else p["outline_color"]
    lines = [
        "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}", "WrapStyle: 2", "ScaledBorderAndShadow: yes", "",
        "[V4+ Styles]",
        "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
        f"Style: Default,{p['font']},{size},{base},{p['primary']},{ocol},&H80000000,{p['bold']},0,0,0,100,100,{p['spacing']},0,{p['border']},{p['outline']},{p['shadow']},{p['align']},80,80,{mv},1",
        f"Style: Hook,Anton,84,{WHITE},{WHITE},&H002D2DFF,&H80000000,0,0,0,0,100,100,0,0,3,18,0,8,60,60,260,1",
        "Style: Card,Poppins ExtraBold,60,&H00141414,&H00141414,&H00141414,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,96,96,0,1",
        "", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text",
    ]
    ec = p["emph"] or (p["hi"] if p["hi"] != p["primary"] else YELLOW)
    reset = f"{{\\c{p['primary']}&\\3c{ocol}&\\bord{p['outline']}\\fscx100\\fscy100}}"

    def ev(a, b, body):
        if p["glow"]:  # blurred, thicker copy underneath the crisp text
            lines.append(f"Dialogue: 0,{_t(a)},{_t(b)},Default,,0,0,0,,{{\\blur9\\bord{p['outline'] + 10}\\3c{p['glow_color']}&}}{body}")
        lines.append(f"Dialogue: 1,{_t(a)},{_t(b)},Default,,0,0,0,,{body}")

    def piece(w, active=False):
        """One word as ASS text: the active word (pop mode) gets the highlight, an emphasised word the emphasis colour and a small zoom; both = highlight + zoom."""
        t = w["_t"]
        if not (active or w["_em"]):
            return t
        col = p["hi"] if active else ec
        extra = (f"\\3c{p['hi_outline']}&\\bord{p['hi_bord']}" if active and p["hi_outline"] else "") + (f"\\fscx{p['emph_scale']}\\fscy{p['emph_scale']}" if w["_em"] else "")
        return f"{{\\c{col}&{extra}}}{t}{reset}"

    cw = prepare(words, p, cap)
    for ch in chunks(cw, p, scale):
        t0, t1 = ch[0]["s"] - start, ch[-1]["e"] - start
        fx = _fx(p, t1 - t0)
        if p["mode"] in ("plain", "speaker"):
            col = ""
            if p["mode"] == "speaker" and speaker_at:
                k = speaker_at(ch[0]["s"])
                col = f"{{\\c{SPEAKER_COLORS[k % len(SPEAKER_COLORS)]}&}}" if k is not None else ""
            ev(t0, t1, f"{fx}{col}" + " ".join(piece(w) if p["mode"] == "plain" else w["_t"] for w in ch))
        elif p["mode"] == "karaoke":
            ev(t0, t1, fx + " ".join(f"{{\\kf{max(1, round((w['e'] - w['s']) * 100))}}}{w['_t']}" for w in ch))
        else:  # pop: active word recoloured (and boxed if hi_outline); type: words accumulate
            for k, w in enumerate(ch):
                a = w["s"] - start
                b = (ch[k + 1]["s"] - start) if k + 1 < len(ch) else t1
                body = " ".join(x["_t"] for x in ch[:k + 1]) if p["mode"] == "type" else " ".join(piece(x, j == k) for j, x in enumerate(ch))
                ev(a, max(b, a + 0.05), (fx if k == 0 else "") + body)
    if card:  # story-card layout: a white rounded card in the top strip, the text in it (whole clip, under the captions)
        text, y1, dur_c = card
        cl, csz = card_lines(text, y1 - 150)
        top = max(70, (y1 - len(cl) * int(csz * 1.3)) // 2)
        lines.append(f"Dialogue: 0,{_t(0)},{_t(dur_c)},Card,,0,0,0,,{{\\an7\\pos(0,0)\\1c&H00FFFFFF&\\bord0\\shad0\\p1}}{_rrect(40, 60, W - 40, y1 - 40, 36)}")
        lines.append(f"Dialogue: 1,{_t(0)},{_t(dur_c)},Card,,0,0,{top},,{{\\fs{csz}}}" + "\\N".join(cl))
    if hook:
        h = "\\N".join(textwrap.wrap(_clean(str(hook)).upper(), 16, break_long_words=False)[:3])
        lines.append(f"Dialogue: 2,{_t(0)},{_t(3)},Hook,,0,0,0,,{{\\fad(120,200)}}{h}")
    if progress:
        lines.append(f"Dialogue: 2,{_t(0)},{_t(progress)},Default,,0,0,0,,{{\\an7\\pos(0,{H - 22})\\1c&H00FFFFFF&\\bord0\\shad0\\fscx0\\t(0,{int(progress * 1000)},\\fscx100)\\p1}}m 0 0 l {W} 0 {W} 14 0 14")
    return "\n".join(lines) + "\n"


def install_fonts(dst):
    """Copy bundled fonts next to the ASS file so `fontsdir=fonts` is a short RELATIVE path (no Windows drive-letter escaping problems)."""
    d = Path(dst) / "fonts"
    if not d.exists():
        try:
            shutil.copytree(FONTS, d, ignore=shutil.ignore_patterns("OFL*"))
        except FileExistsError:  # another clip's render thread got there first
            pass
    return "fonts"
