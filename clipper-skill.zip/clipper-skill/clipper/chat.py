"""Chat as a moment signal for Twitch and Kick, recorded VODs and live. Rows are {"t": seconds from VIDEO start, "u": user, "m": text}.

VOD chat (no account, no API key, public endpoints the sites' own players use):
  * Twitch: gql.twitch.tv persisted query VideoCommentsByOffsetOrCursor, paged BY OFFSET (cursor paging needs a Twitch integrity token, so it is not used).
  * Kick:   kick.com/api/v2/channels/{channel_id}/messages?start_time=ISO, which returns a ~5 s slice of chat per request.
A 5-hour stream can hold 500k messages, so a bounded two-pass fetch is used: pass 1 samples one slice every `step` s to estimate the chat rate; pass 2 fetches the
hottest windows completely, until the request/time budget is spent. `coverage` lists the intervals that were really read; the signal between them is interpolated
(see signals.chat_series_covered), never treated as silence. These are unofficial endpoints: they can change or be rate-limited, in which case the job
continues without chat and says so. Kick VOD chat is aligned by wall clock (message time - stream start): expect a few seconds of skew.
Live: Twitch IRC (live.py) and a Kick poller (kick_chat below)."""
import concurrent.futures as cf, datetime as dt, json, re, threading, time, urllib.error, urllib.parse, urllib.request
from pathlib import Path

TWITCH_GQL = "https://gql.twitch.tv/gql"
TWITCH_CLIENT = "kimne78kx3ncx6brgo4mv6wki5h1ko"  # the public Client-ID of twitch.tv's own web player
TWITCH_HASH = "b70a3591ff0f4e0313d126c6a1502d79a1c02baebb288227c582044aa76adf6a"
UA = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) clipper-chat/1", "Accept": "application/json"}
KICK_SLICE = 5.0


def twitch_video_id(src):
    m = re.search(r"twitch\.tv/(?:videos/|[\w]+/v/)(\d+)", src or "")
    return m[1] if m else None


def kick_video_uuid(src):
    m = re.search(r"kick\.com/(?:[\w-]+/)?(?:video|videos)/([0-9a-f-]{36})", src or "", re.I)
    return m[1].lower() if m else None


_RATE = {"kick.com": 0.4}  # min seconds between requests per host: Kick answers HTTP 429 to bursts (measured: 8 parallel workers -> 120/121 failures)
_next, _lock = {}, threading.Lock()


def _throttle(url):
    host = urllib.parse.urlparse(url).hostname or ""
    gap = _RATE.get(host)
    if not gap:
        return
    with _lock:
        wait = _next.get(host, 0) - time.time()
        _next[host] = max(time.time(), _next.get(host, 0)) + gap
    if wait > 0:
        time.sleep(wait)


def _http(url, body=None, headers=None, timeout=25):
    _throttle(url)
    req = urllib.request.Request(url, body, {**UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def _retry(fn, tries=3, base=0.6):
    for k in range(tries):
        try:
            return fn()
        except Exception as e:  # network, 429, 5xx, bad JSON: back off, then give up on this slice only
            if k == tries - 1:
                raise
            ra = e.headers.get("Retry-After") if isinstance(e, urllib.error.HTTPError) and e.code == 429 else None
            time.sleep(min(30.0, float(ra)) if ra and ra.replace(".", "", 1).isdigit() else base * 2 ** k * (4 if isinstance(e, urllib.error.HTTPError) and e.code == 429 else 1))


# ------------------------------------------------------------------------------------------------ Twitch
def _tw_page(vid, offset):
    body = json.dumps([{"operationName": "VideoCommentsByOffsetOrCursor", "variables": {"videoID": str(vid), "contentOffsetSeconds": int(offset)},
                        "extensions": {"persistedQuery": {"version": 1, "sha256Hash": TWITCH_HASH}}}]).encode()
    r = _http(TWITCH_GQL, body, {"Client-ID": TWITCH_CLIENT, "Content-Type": "text/plain"})[0]
    v = (r.get("data") or {}).get("video")
    if v is None:
        raise RuntimeError("video not found / chat unavailable")
    c = v.get("comments")
    if c is None:
        raise RuntimeError("; ".join(e.get("message", "?") for e in r.get("errors", [])) or "chat unavailable")
    rows = []
    for e in c.get("edges") or []:
        n = e["node"]
        text = "".join(f.get("text") or "" for f in (n.get("message") or {}).get("fragments", []))
        rows.append({"id": n["id"], "t": float(n["contentOffsetSeconds"]), "u": (n.get("commenter") or {}).get("login"), "m": text})
    return rows


def _tw_window(vid, a, b, limit_pages=400):
    """All messages with a <= t < b, hopping the offset forward by the last message's time. Messages beyond a page within ONE second are lost (dense
    chat): the series only needs the rate, which stays ordered correctly."""
    rows, seen, off, pages = [], set(), float(a), 0
    while off < b and pages < limit_pages:
        pg = _retry(lambda: _tw_page(vid, off))
        pages += 1
        new = [r for r in pg if r["id"] not in seen]
        for r in new:
            seen.add(r["id"])
            if a <= r["t"] < b:
                rows.append(r)
        last = max((r["t"] for r in pg), default=off)
        off = last + 1 if last >= off else off + 30  # page entirely before the offset (sparse chat) -> step on
        if not pg:
            break
    return rows, pages


# ------------------------------------------------------------------------------------------------ Kick
def _kick_text(s):
    return re.sub(r"\[emote:\d+:([^\]]+)\]", r"\1", s or "")


def _iso(epoch):
    return dt.datetime.fromtimestamp(epoch, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def _parse_iso(s):
    return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def kick_video_info(uuid):
    """-> (channel_id, stream_start_epoch). Raises RuntimeError with a readable reason."""
    d = _retry(lambda: _http(f"https://kick.com/api/v1/video/{uuid}"))
    ls = d.get("livestream") or {}
    cid, st = ls.get("channel_id"), ls.get("start_time") or ls.get("created_at") or d.get("created_at")
    if not cid or not st:
        raise RuntimeError("Kick did not return channel/start time for this video")
    st = st.replace(" ", "T") + ("+00:00" if "T" not in st or not re.search(r"(Z|[+-]\d\d:\d\d)$", st.replace(" ", "T")) else "")
    return cid, _parse_iso(st)


def _kick_slice(cid, epoch):
    j = _http(f"https://kick.com/api/v2/channels/{cid}/messages?start_time={urllib.parse.quote(_iso(epoch))}")
    return (j.get("data") or {}).get("messages") or []


def _kick_rows(msgs, t0, a, b):
    out = []
    for m in msgs:
        try:
            t = _parse_iso(m["created_at"]) - t0
        except (KeyError, ValueError):
            continue
        if a <= t < b:
            out.append({"id": m.get("id"), "t": round(t, 2), "u": (m.get("sender") or {}).get("slug"), "m": _kick_text(m.get("content"))})
    return out


# ------------------------------------------------------------------------------------------------ two-pass engine
def sampled_fetch(duration, probe, full, budget_calls=2500, workers=8, deadline=420.0, step=None, now=time.time):
    """probe(t) -> (rows, (a, b) interval really read, calls). full(a, b) -> (rows, calls). -> (rows, coverage [(a,b)], stats).
    Pass 1 samples every `step` s; pass 2 fully reads the hottest windows (by sampled rate) until budget_calls/deadline run out."""
    t_end = now() + deadline
    step = step or max(30.0, duration / 200.0)
    ts = [k * step for k in range(int(duration // step) + 1)]
    rows, cov, calls, errors = [], [], 0, 0
    rate = {}
    with cf.ThreadPoolExecutor(workers) as ex:
        futs = {ex.submit(probe, t): t for t in ts}
        for f in cf.as_completed(futs):
            t = futs[f]
            try:
                r, (a, b), c = f.result()
            except Exception:
                errors += 1
                continue
            calls += c
            rows += r
            cov.append((a, b))
            rate[t] = len(r) / max(1.0, b - a)
        todo = sorted((t for t in ts if rate.get(t, 0) > 0), key=lambda t: -rate[t])  # hottest first; all of them if the budget allows
        pending, nxt = {}, 0
        while (pending or nxt < len(todo)) and now() < t_end and calls < budget_calls:
            while len(pending) < workers and nxt < len(todo):
                pending[ex.submit(full, todo[nxt], min(duration, todo[nxt] + step))] = todo[nxt]
                nxt += 1
            if not pending:
                break
            fin, _ = cf.wait(list(pending), return_when=cf.FIRST_COMPLETED, timeout=5)
            for f in fin:
                t = pending.pop(f)
                try:
                    r, c = f.result()
                except Exception:
                    errors += 1
                    continue
                calls += c
                rows += r
                cov.append((t, min(duration, t + step)))
        for f in pending:
            f.cancel()
    seen, uniq = set(), []
    for r in sorted(rows, key=lambda r: r["t"]):  # same message read by probe and full pass
        k = r.get("id") or (r["t"], r.get("u"), r.get("m"))
        if k not in seen:
            seen.add(k)
            uniq.append({"t": r["t"], "u": r.get("u"), "m": r.get("m", "")})
    merged = []
    for a, b in sorted(cov):
        if merged and a <= merged[-1][1] + 0.5:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    merged = [[a, min(b, duration)] for a, b in merged if a < duration]
    return uniq, [tuple(m) for m in merged], {"calls": calls, "errors": errors, "samples": len(ts), "covered_s": round(sum(b - a for a, b in merged)), "messages": len(uniq),
                                                "complete": sum(b - a for a, b in merged) >= duration * 0.98}


def twitch_vod_chat(vid, duration, **kw):
    def probe(t):
        pg = _retry(lambda: _tw_page(vid, t))
        a, b = (min(r["t"] for r in pg), max(r["t"] for r in pg) + 1) if pg else (t, t + 1)
        a = max(a, t)
        return [r for r in pg if r["t"] >= a], (a, max(b, a + 1)), 1
    return sampled_fetch(duration, probe, lambda a, b: _tw_window(vid, a, b), **kw)


def kick_vod_chat(uuid, duration, **kw):
    cid, t0 = kick_video_info(uuid)
    kw = {"workers": 3, "budget_calls": 900, "deadline": 300.0, "step": max(60.0, duration / 150.0), **kw}  # gentle: see _RATE

    def probe(t):
        return _kick_rows(_retry(lambda: _kick_slice(cid, t0 + t)), t0, t, t + KICK_SLICE), (t, t + KICK_SLICE), 1

    def full(a, b):
        rows, k, t = [], 0, a
        while t < b:
            rows += _kick_rows(_retry(lambda: _kick_slice(cid, t0 + t)), t0, t, t + KICK_SLICE)
            t += KICK_SLICE
            k += 1
        return rows, k
    return sampled_fetch(duration, probe, full, **kw)


FULL = {"budget_calls": 30000, "deadline": 1800.0, "step": 30.0}  # --chat-full: read (nearly) every message of a long VOD, minutes instead of seconds


def _chat_downloader(src, duration):
    """Fallback when the direct endpoints fail: the `chat-downloader` package (pip install chat-downloader), which tracks Twitch's own changes.
    -> (rows, coverage, stats) or raises."""
    from chat_downloader import ChatDownloader  # ImportError -> caller reports "not installed"
    rows = []
    for m in ChatDownloader().get_chat(src, start_time=0, end_time=int(duration), message_types=["text_message"]):
        t = m.get("time_in_seconds")
        if isinstance(t, (int, float)) and 0 <= t <= duration:
            rows.append({"t": float(t), "u": (m.get("author") or {}).get("name"), "m": str(m.get("message", ""))})
    return rows, [(0.0, float(duration))], {"calls": 0, "errors": 0, "samples": 0, "covered_s": int(duration), "messages": len(rows), "complete": True, "via": "chat-downloader"}


def fetch_vod_chat(src, duration, dest, log=print, full=False, **kw):
    """Twitch/Kick VOD URL -> writes dest/chat.jsonl + dest/chat.coverage.json. -> path or None (never raises: chat is optional).
    Order: the direct endpoints (fast, sampled), then the chat-downloader package if installed. Kick rows are flagged `align`: their clock is wall time, so signals
    estimate the skew against the audio (estimate_shift) instead of trusting it."""
    from .util import note_skipped, redact
    vid, uuid = twitch_video_id(src), kick_video_uuid(src)
    if not (vid or uuid):
        return None
    kw = {**(FULL if full else {}), **kw}
    rows, cov, stats, why = [], [], {}, None
    try:
        rows, cov, stats = (twitch_vod_chat(vid, duration, **kw) if vid else kick_vod_chat(uuid, duration, **kw))
    except Exception as e:
        why = f"{type(e).__name__}: {redact(str(e))[:150]}"
    if not rows:
        try:
            rows, cov, stats = _chat_downloader(src, duration)
            why = None
        except ImportError:
            why = (why or "no chat messages returned (chat disabled/removed, or the endpoint changed)") + "; fallback `pip install chat-downloader` not installed"
        except Exception as e:
            why = (why or "no chat messages") + f"; chat-downloader: {type(e).__name__}: {redact(str(e))[:100]}"
    if not rows:
        note_skipped("vod chat", f"{why} (continuing without chat; `clipper doctor --chat` checks the endpoints)")
        return None
    d = Path(dest)
    d.mkdir(parents=True, exist_ok=True)
    (d / "chat.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
    (d / "chat.coverage.json").write_text(json.dumps({"coverage": cov, "stats": stats, "align": bool(uuid)}))
    log(f"chat: {stats.get('messages', len(rows))} messages, {stats.get('covered_s', '?')}s of {int(duration)}s read in {stats.get('calls', '?')} requests" + ("" if stats.get("complete") else " (sampled + hottest windows)"))
    return str(d / "chat.jsonl")


def estimate_shift(chat, audio, max_shift=20, min_gain=0.05, min_corr=0.1):
    """Seconds to ADD to chat times so chat bursts line up with loudness bursts in the video (Kick VOD chat is stamped with wall-clock time; viewers also
    react late). Normalised cross-correlation of per-second chat rate and audio level over +-max_shift s; a shift is only returned if it beats 0 s clearly
    (otherwise 0.0: unaligned chat is better than wrongly aligned chat). -> (shift_seconds, correlation_at_shift)."""
    n = min(len(audio), int(max((c["t"] for c in chat), default=0)) + 1 + max_shift)
    if n < 120 or len(chat) < 30:
        return 0.0, 0.0
    rate = [0.0] * n
    for c in chat:
        i = int(c["t"])
        if 0 <= i < n:
            rate[i] += 1
    sm = lambda s: [sum(s[max(0, i - 2):i + 3]) / len(s[max(0, i - 2):i + 3]) for i in range(len(s))]
    a, r = sm([float(x) for x in audio[:n]]), sm(rate)

    def corr(sh):  # chat sample i + sh pairs with audio sample i
        xs = [(a[i], r[i + sh]) for i in range(n) if 0 <= i + sh < n]
        if len(xs) < 60:
            return -1.0
        ma, mr = sum(x for x, _ in xs) / len(xs), sum(y for _, y in xs) / len(xs)
        va, vr = sum((x - ma) ** 2 for x, _ in xs), sum((y - mr) ** 2 for _, y in xs)
        return sum((x - ma) * (y - mr) for x, y in xs) / ((va * vr) ** 0.5) if va > 0 and vr > 0 else -1.0
    base = corr(0)
    best, bs = max(((corr(s), s) for s in range(-max_shift, max_shift + 1)), key=lambda x: x[0])
    return (float(-bs), best) if bs != 0 and best >= min_corr and best - base >= min_gain else (0.0, base)


def load_align(chat_path):
    f = Path(chat_path).with_name("chat.coverage.json") if chat_path else None
    try:
        return bool(f and f.is_file() and Path(chat_path).name == "chat.jsonl" and json.loads(f.read_text()).get("align"))
    except (ValueError, TypeError):
        return False


def selfcheck(get=None):
    """Probe the unofficial endpoints with a real, current example each (no download). -> {"twitch_vod_chat": (ok, detail), "kick_vod_chat": ..., "kick_live_chat": ...}.
    Run it when chat stops arriving: it says which endpoint changed."""
    get = get or _http
    out = {}
    try:
        vid = None
        for login in ("gaules", "xqc", "riotgames", "esl_csgo", "twitch"):  # any channel that currently has a past broadcast will do
            g = get(TWITCH_GQL, json.dumps({"query": '{ user(login:"%s"){ videos(first:1, type: ARCHIVE){ edges{ node{ id } } } } }' % login}).encode(), {"Client-ID": TWITCH_CLIENT, "Content-Type": "text/plain"})
            edges = (((g.get("data") or {}).get("user") or {}).get("videos") or {}).get("edges") or []
            if edges:
                vid = edges[0]["node"]["id"]
                break
        if not vid:
            raise RuntimeError("no past broadcast found on the probe channels (not necessarily a breakage)")
        rows = _tw_page(vid, 600) if get is _http else []
        out["twitch_vod_chat"] = (True, f"video {vid}: {len(rows)} messages on the first page")
    except Exception as e:
        out["twitch_vod_chat"] = (False, f"{type(e).__name__}: {str(e)[:120]}")
    try:
        v = get("https://kick.com/api/v2/channels/xqc/videos")[0]
        uuid = v["video"]["uuid"]
        cid, t0 = kick_video_info(uuid)
        msgs = _kick_slice(cid, t0 + 600)
        out["kick_vod_chat"] = (True, f"video {uuid}: {len(msgs)} messages in a 5 s slice")
        m = (get(f"https://kick.com/api/v2/channels/{cid}/messages").get("data") or {}).get("messages")
        out["kick_live_chat"] = (m is not None, f"{len(m or [])} latest messages")
    except Exception as e:
        out.setdefault("kick_vod_chat", (False, f"{type(e).__name__}: {str(e)[:120]}"))
        out.setdefault("kick_live_chat", (False, "not checked (channel lookup failed)"))
    return out


def load_coverage(chat_path):
    """-> [(a, b)] or None (None = the file is complete, e.g. a recorded live chat or a user-supplied export)."""
    f = Path(chat_path).with_name("chat.coverage.json") if chat_path else None
    if f and f.is_file() and Path(chat_path).name == "chat.jsonl":
        try:
            return [tuple(x) for x in json.loads(f.read_text())["coverage"]]
        except (ValueError, KeyError, TypeError):
            return None
    return None


# ------------------------------------------------------------------------------------------------ Kick live
def kick_channel_id(slug):
    return _retry(lambda: _http(f"https://kick.com/api/v2/channels/{urllib.parse.quote(slug)}"))["id"]


def kick_chat(slug, sink, stop, poll=2.0, get=None):
    """Poll the latest messages of a live Kick channel (the public chat read endpoint; no login). sink(wall_time, user, text), same as Twitch IRC.
    The endpoint returns only the newest ~50 messages, so a very busy chat loses some between polls: fine for a rate signal, not a transcript."""
    get = get or (lambda cid: _http(f"https://kick.com/api/v2/channels/{cid}/messages"))
    seen, order, fails, cid = set(), [], 0, None
    while cid is None and not stop.is_set():  # the channel lookup is rate-limited too: back off instead of dying
        try:
            cid = kick_channel_id(slug)
        except Exception:
            fails += 1
            if fails > 8:
                return
            stop.wait(min(60.0, 3.0 * 2 ** fails))
    fails = 0
    while not stop.is_set():
        try:
            msgs = (get(cid).get("data") or {}).get("messages") or []
            fails = 0
        except Exception:
            fails += 1
            if fails > 20:
                return
            stop.wait(min(30, poll * fails))
            continue
        for m in sorted(msgs, key=lambda m: m.get("created_at", "")):
            if m.get("id") in seen:
                continue
            seen.add(m.get("id"))
            order.append(m.get("id"))
            try:
                ts = _parse_iso(m["created_at"])
            except (KeyError, ValueError):
                ts = time.time()
            sink(ts, (m.get("sender") or {}).get("slug"), _kick_text(m.get("content")))
        while len(order) > 2000:
            seen.discard(order.pop(0))
        stop.wait(poll)


def kick_slug(src):
    m = re.search(r"kick\.com/([\w-]+)/?(?:\?|$|videos)", src or "")
    return m[1] if m and m[1] not in ("video", "videos", "categories") else None
