"""Where do the captions and the hook really land? Measured on pixels, not guessed.
The caption/hook ASS is rendered alone on black (exact font metrics and wrapping), its bounding box is taken per sample frame, and it is
compared with (a) faces detected in the REAL rendered clip and (b) the platform safe zone (Shorts/Reels/TikTok put their own UI at the
bottom, the top and the right edge). The fix is a vertical shift (`caption_y`, px, + = up) that clears faces and stays inside the zone."""
import re
from pathlib import Path
from .util import ffmpeg, run
import subprocess

W, H = 1080, 1920
SAFE = dict(top=170, bottom=420, side=60)  # px of a 1080x1920 frame kept clear of platform UI (bottom: caption/description/buttons)
SC = 2  # measure at 1/2 resolution
FPS = 2


def text_boxes(ass, dur, cwd, fps=FPS):
    """-> [(t, (x0, y0, x1, y1) in 1080x1920 px | None)] bounding box of the visible text in each sample frame."""
    import numpy as np
    w, h = W // SC, H // SC
    cmd = [ffmpeg(), "-v", "error", "-f", "lavfi", "-i", f"color=c=black:s={w}x{h}:r={fps}:d={dur:.2f}", "-vf", f"subtitles={ass}:fontsdir=fonts", "-pix_fmt", "gray", "-f", "rawvideo", "-"]
    out = []
    for k, f in enumerate(_gray_frames(cmd, w, h, cwd)):
        m = f > 60
        if m.sum() < 40:
            out.append((k / fps, None))
            continue
        ys, xs = np.where(m)
        out.append((k / fps, (int(xs.min()) * SC, int(ys.min()) * SC, int(xs.max()) * SC, int(ys.max()) * SC)))
    return out


def _gray_frames(cmd, w, h, cwd):
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, cwd=cwd)
    import numpy as np
    n = w * h
    while True:
        b = p.stdout.read(n)
        if len(b) < n:
            break
        yield np.frombuffer(b, dtype=np.uint8).reshape(h, w)
    p.wait()


def face_boxes(video, dur, fps=FPS):
    """-> [[(x0, y0, x1, y1), ...] per sample frame] eyes-to-mouth zone of each face in the rendered clip, 1080x1920 px. [] per frame when the detector is unavailable."""
    import numpy as np
    from . import speaker
    w, h = W // SC, H // SC
    cmd = [ffmpeg(), "-v", "error", "-i", str(video), "-an", "-vf", f"fps={fps},scale={w}:{h},format=bgr24", "-f", "rawvideo", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    n, out = w * h * 3, []
    while True:
        b = p.stdout.read(n)
        if len(b) < n:
            break
        fr = np.frombuffer(b, dtype=np.uint8).reshape(h, w, 3).copy()
        fs = []
        for f in speaker.detect_faces(fr, 0.6):
            lm = f["lm"]  # r-eye, l-eye, nose, r-mouth, l-mouth in frame px: the expression zone is eyes to mouth (not hair or chin)
            xs, ys = [p[0] for p in lm], [p[1] for p in lm]
            d = max(max(ys) - min(ys), 6)
            fs.append(((min(xs) - 0.35 * d) * SC, (min(ys) - 0.3 * d) * SC, (max(xs) + 0.35 * d) * SC, (max(ys) + 0.3 * d) * SC))
        out.append(fs)
    p.wait()
    return out


def _hit(a, b):
    return a[0] < b[2] and a[2] > b[0] and a[1] < b[3] and a[3] > b[1]


def evaluate(boxes, faces, shift=0):
    """boxes: text_boxes() result; faces: face_boxes(). shift px (+ = up). -> dict(face_hits, unsafe, frames)."""
    hits = unsafe = shown = 0
    for k, (t, b) in enumerate(boxes):
        if b is None:
            continue
        shown += 1
        bb = (b[0], b[1] - shift, b[2], b[3] - shift)
        if k < len(faces) and any(_hit(bb, f) for f in faces[k]):
            hits += 1
        if bb[3] > H - SAFE["bottom"] or bb[1] < SAFE["top"] or bb[0] < SAFE["side"] or bb[2] > W - SAFE["side"]:
            unsafe += 1
    return {"face_hits": hits, "unsafe": unsafe, "frames": shown}


def best_shift(boxes, faces, step=40, reach=1100):
    """Smallest vertical shift (px, + = up) with the fewest face overlaps and no safe-zone violations. -> (shift, evaluation)."""
    cands = [0] + sorted((s for s in range(-reach, reach + 1, step) if s), key=lambda s: (abs(s), s))  # 0 first: never move text that is already fine
    best = None
    for s in cands:
        e = evaluate(boxes, faces, s)
        key = (e["unsafe"] > 0, e["face_hits"], abs(s))
        if best is None or key < best[0]:
            best = (key, s, e)
        if key[:2] == (False, 0):
            break
    return best[1], best[2]


def analyse(out_dir, clip_id, video, dur):
    """Everything the critic needs for one clip, or None when it has no caption file. -> dict(cap, hook, faces, shift, before, after)."""
    out_dir = Path(out_dir)
    ass = out_dir / f"clip_{clip_id:02d}.ass"
    if not ass.exists() or not Path(video).exists():
        return None
    cap = text_boxes(ass.name, dur, out_dir)
    faces = face_boxes(video, dur)
    fx = out_dir / f"clip_{clip_id:02d}_fx.ass"
    hook = text_boxes(fx.name, min(dur, 3.4), out_dir) if fx.exists() else []
    shift, after = best_shift(cap, faces)
    return {"cap": cap, "hook": hook, "faces": faces, "shift": shift, "before": evaluate(cap, faces), "after": after,
            "hook_hits": evaluate(hook, faces)["face_hits"] if hook else 0, "line_h": _line_h(cap)}


def _line_h(boxes):
    hs = sorted(b[3] - b[1] for _, b in boxes if b)
    return hs[int(len(hs) * 0.9)] if hs else 0  # p90: a line of lowercase letters with no ascenders is short without being small
