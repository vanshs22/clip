"""Source classification, download (yt-dlp), chat loading. No DRM circumvention; auth is the user's own cookies."""
import json, re, shutil
from pathlib import Path
from .util import run, probe, jload, validate_source, safe_path, ffmpeg

HOSTS = [("youtube", r"(youtube\.com|youtu\.be)"), ("twitch_clip", r"clips\.twitch\.tv"), ("twitch", r"twitch\.tv"), ("kick", r"kick\.com"), ("facebook", r"(facebook\.com|fb\.watch)"), ("tiktok", r"tiktok\.com"),
         ("instagram", r"instagram\.com"), ("x", r"(twitter\.com|x\.com)"), ("reddit", r"(reddit\.com|redd\.it)"), ("vimeo", r"vimeo\.com"), ("rumble", r"rumble\.com"),
         ("dailymotion", r"dailymotion\.com|dai\.ly"), ("bilibili", r"bilibili\.com|b23\.tv")]
# one video only (a watch URL with &list= must not pull a whole playlist), retries for flaky CDNs, a socket timeout so a stalled download fails instead of hanging
def _js_runtime():
    """YouTube now needs a JavaScript runtime (node, deno or bun) to solve its signature challenge; without one yt-dlp reports 'Requested format is not available'
    even with valid cookies (checked against real YouTube). Returns the yt-dlp flags for the first runtime on PATH, else []."""
    for rt in ("deno", "node", "bun"):
        if shutil.which(rt):
            return ["--js-runtimes", rt]
    return []


YT = ["--no-playlist", "--retries", "5", "--fragment-retries", "5", "--socket-timeout", "30", "--no-warnings", *_js_runtime()]
HINTS = [(r"sign in|log ?in|private|members|\\bage\\b|confirm you.re not a bot|cookies", "auth_required", "Use your own session: --cookies cookies.txt  or  --cookies browser:chrome"),
         (r"429|too many requests|rate.?limit", "unavailable", "The site is rate-limiting this IP: wait a few minutes, or pass --cookies"),
         (r"\\bgeo|not available in your (country|region)|blocked", "unavailable", "Blocked in this region"),
         (r"requested format|no video formats", "unavailable", "YouTube needs a JavaScript runtime and yt-dlp-ejs: install Node.js (or deno/bun) and `pip install -U \"yt-dlp[default]\"`, then retry; also try updating yt-dlp"),
         (r"unsupported url", "unavailable", "yt-dlp cannot read this page: update it (pip install -U yt-dlp) or download the file and pass the path")]


def _merged(dest):
    """The finished source file in `dest`: not a .part, not a subtitle/chat json, and NOT a single-format fragment like source.f399.mp4 (video only)."""
    return next((p for p in sorted(Path(dest).glob("source.*")) if p.suffix in LOCAL and not re.search(r"\.f[\w-]+\.\w+$", p.name)), None)


def ytdlp():
    """-> the command that runs yt-dlp: the `yt-dlp` executable if it is on PATH, else `python -m yt_dlp` when the package is importable (a pip --target or
    virtualenv install without its scripts on PATH), else None."""
    if shutil.which("yt-dlp"):
        return ["yt-dlp"]
    import importlib.util, sys
    return [sys.executable, "-m", "yt_dlp"] if importlib.util.find_spec("yt_dlp") else None


def _cookies(c):
    """--cookies FILE, or `browser:NAME` -> --cookies-from-browser NAME (your own logged-in browser; nothing leaves the machine)."""
    if not c:
        return []
    return ["--cookies-from-browser", c.split(":", 1)[1]] if str(c).startswith("browser:") and re.fullmatch(r"browser:[a-z]+", str(c)) else ["--cookies", str(c)]
LOCAL = (".mp4", ".mov", ".mkv", ".webm", ".ts", ".m4v", ".flv")


def classify(src):
    validate_source(src)
    if Path(src).exists():
        return {"kind": "file", "platform": "local"}
    if re.match(r"rtmps?://", src):
        return {"kind": "live", "platform": "rtmp"}
    if re.search(r"\.m3u8(\?|$)", src):
        return {"kind": "live", "platform": "hls"}
    for name, rx in HOSTS:
        if re.search(rx, src):
            return {"kind": "url", "platform": name}
    if src.lower().split("?")[0].endswith(LOCAL):
        return {"kind": "url", "platform": "direct"}
    return {"kind": "unknown", "platform": "?"}


def inspect(src, cookies=None):
    """-> {"kind": file|vod|live|unavailable|auth_required, ...}. Never downloads."""
    c = classify(src)
    if c["kind"] == "file":
        return {**c, "state": "vod", "title": Path(src).stem, "duration": probe(src)["duration"]}
    if c["kind"] == "live":
        return {**c, "state": "live"}
    yd = ytdlp()
    if not yd:
        return {**c, "state": "unavailable", "error": "yt-dlp not installed (pip install \"yt-dlp[default]\")"}
    r = run([*yd, "--dump-single-json", "--skip-download", *YT, *_cookies(cookies), "--", src], timeout=300)
    if r.returncode:
        err = r.stderr.strip().splitlines()[-1] if r.stderr.strip() else "unknown error"
        state, hint = next(((s, h) for rx, s, h in HINTS if re.search(rx, err, re.I)), ("unavailable", ""))
        return {**c, "state": state, "error": err, "hint": hint}
    j = json.loads(r.stdout)
    return {**c, "state": "live" if j.get("is_live") else "vod", "title": j.get("title"), "duration": j.get("duration") or 0,
            "heatmap": j.get("heatmap")}  # YouTube "most replayed" segments, when the video has them


def download(src, dest, cookies=None):
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    have = _merged(dest)
    if have:
        return have  # resume: never download twice
    r = run([*(ytdlp() or ["yt-dlp"]), "-f", "bv*[height<=1080]+ba/b[height<=1080]/b", "--merge-output-format", "mp4", "-N", "4", "--ffmpeg-location", ffmpeg(), *YT,
             "--write-subs", "--sub-langs", "live_chat", "-o", str(dest / "source.%(ext)s"),
             *_cookies(cookies), "--", src], timeout=7200)
    out = _merged(dest)
    if r.returncode and not out:
        raise RuntimeError(r.stderr[-500:])
    if not out and list(dest.glob("source.f*")):  # video and audio arrived as separate files: the merge did not happen (yt-dlp could not run ffmpeg)
        raise RuntimeError("download left unmerged video/audio streams: yt-dlp could not run ffmpeg (set CLIPPER_FFMPEG or install ffmpeg), then re-run to merge")
    return out


def load_chat(path):
    """Accepts our chat.jsonl ({t,u,m}), a yt-dlp YouTube live_chat.json, or TwitchDownloader JSON."""
    path = Path(path)
    if not path.exists():
        return []
    txt = path.read_text(errors="ignore").strip()
    out = []
    try:
        j = json.loads(txt)
        if isinstance(j, dict) and "comments" in j:  # TwitchDownloader
            return [{"t": c["content_offset_seconds"], "u": (c.get("commenter") or {}).get("name"), "m": (c.get("message") or {}).get("body", "")} for c in j["comments"]]
    except json.JSONDecodeError:
        pass
    for line in txt.splitlines():
        try:
            j = json.loads(line)
        except json.JSONDecodeError:
            continue
        if "t" in j:
            out.append(j)
        elif "replayChatItemAction" in j:  # YouTube replay: one JSON per line
            a = j["replayChatItemAction"]
            n = len([x for x in a.get("actions", []) if "addChatItemAction" in x])
            out += [{"t": int(a.get("videoOffsetTimeMsec", 0)) / 1000, "u": None, "m": ""}] * n
    return out


def fetch_chat(src, dest, duration=None, full=False):
    """Chat for a Twitch or Kick VOD (clipper/chat.py: public endpoints, sampled + hottest windows). Falls back to the free TwitchDownloaderCLI if it is on
    PATH. -> path or None; a failure never stops the pipeline."""
    from . import chat
    if duration and (chat.twitch_video_id(src) or chat.kick_video_uuid(src)):
        p = chat.fetch_vod_chat(src, duration, dest, full=full)
        if p:
            return p
    m = re.search(r"twitch\.tv/videos/(\d+)", src)
    exe = shutil.which("TwitchDownloaderCLI")
    if not (m and exe):
        return None
    out = Path(dest) / "twitch_chat.json"
    r = run([exe, "chatdownload", "--id", m[1], "-o", str(out)], timeout=900)
    return str(out) if r.returncode == 0 and out.exists() else None
