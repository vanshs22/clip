"""Find the streamer's webcam box in stream footage (the `cam` region of the multi-region layouts).

Method (needs OpenCV + the YuNet face model, same as speaker following; returns None when either is missing):
 1. grab `n` frames spread over the video, run the face detector on each;
 2. keep SMALL faces (a webcam face is a small part of a game frame) and cluster them by position; the webcam is the cluster that shows up in most frames
    at about the same place (a person moving around a room moves a little; a game character moves a lot more and is rarely a "face");
 3. grow the face box to a webcam rectangle (typical framing: face ~40% of the width, ~38% of the height), then snap each side to the strongest straight
    edge nearby (webcam overlays have a border or at least a hard edge) and to the frame edge when it is within 12% of it.
The result is a PROPOSAL: the layouts still go through the user's approval, and the preview image shows exactly what was found."""
import subprocess
from .util import ffmpeg, note_skipped

MAX_FACE_SHARE = 0.10   # a face bigger than 10% of the frame is the main subject, not a corner webcam
MIN_FRAMES = 0.4        # the cluster must appear in at least 40% of the sampled frames


def _grab(src, t, width, height):
    import numpy as np
    p = subprocess.run([ffmpeg(), "-v", "error", "-ss", f"{t:.2f}", "-i", str(src), "-frames:v", "1", "-vf", f"scale={width}:{height}", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"],
                       capture_output=True, timeout=60)
    if len(p.stdout) < width * height * 3:
        return None
    return np.frombuffer(p.stdout, np.uint8).reshape(height, width, 3)


def _snap(profile, lo, hi, span):
    """Move an edge coordinate (fraction) to the strongest gradient peak in [lo, hi] if it clearly stands out, else keep the middle."""
    n = len(profile)
    a, b = max(0, int(lo * n)), min(n, int(hi * n) + 1)
    if b - a < 3:
        return (lo + hi) / 2
    seg = profile[a:b]
    k = max(range(len(seg)), key=lambda i: seg[i])
    mean = sum(profile) / n
    return (a + k) / n if seg[k] > 2.0 * mean and span else (lo + hi) / 2


def detect(src, info, n=10, width=640, detect_fn=None, grab=_grab):
    """-> {"box": [x, y, w, h] (fractions of the source), "confidence": 0..1, "hits": k, "frames": n, "faces": [...]} or None.
    detect_fn(frame) -> [{"cx","cy","size", "box": (x,y,w,h)}] normalised; default = speaker.detect_faces. grab(src, t, w, h) -> BGR array (testable without video)."""
    try:
        import numpy as np
        from . import speaker
        detect_fn = detect_fn or speaker.detect_faces
    except ImportError as e:
        note_skipped("webcam detection", f"opencv/numpy not installed: {e}")
        return None
    W0, H0, dur = info["width"], info["height"], info["duration"]
    if not W0 or not H0 or dur <= 0:
        return None
    h = int(width * H0 / W0) // 2 * 2
    ts = [dur * (0.05 + 0.9 * k / max(1, n - 1)) for k in range(n)]
    frames, hits = [], []
    for t in ts:
        fr = grab(src, t, width, h)
        if fr is None:
            continue
        frames.append(fr)
        try:
            faces = detect_fn(fr)
        except ImportError as e:  # opencv is imported lazily inside the face detector: report it, never crash `clipper layout`
            note_skipped("webcam detection", f"opencv not installed: {e}")
            return None
        for f in faces:
            if f["size"] <= MAX_FACE_SHARE and f.get("box"):
                hits.append((len(frames) - 1, f))
    if not frames or not hits:
        return None
    clusters = []
    for k, f in hits:  # greedy clustering by centre
        for c in clusters:
            if abs(c["cx"] - f["cx"]) < 0.06 and abs(c["cy"] - f["cy"]) < 0.08:
                c["m"].append((k, f))
                c["cx"], c["cy"] = sum(x["cx"] for _, x in c["m"]) / len(c["m"]), sum(x["cy"] for _, x in c["m"]) / len(c["m"])
                break
        else:
            clusters.append({"cx": f["cx"], "cy": f["cy"], "m": [(k, f)]})
    best = max(clusters, key=lambda c: len({k for k, _ in c["m"]}))
    nf = len({k for k, _ in best["m"]})
    if nf < max(2, MIN_FRAMES * len(frames)):
        return None
    med = lambda v: sorted(v)[len(v) // 2]
    bx = [float(med([f["box"][i] for _, f in best["m"]])) for i in range(4)]  # median face box (x, y, w, h)
    fx, fy, fw, fh = bx
    cx, cy = fx + fw / 2, fy + fh / 2
    x0, x1 = cx - fw * 1.3, cx + fw * 1.3
    y0, y1 = cy - fh * 1.25, cy + fh * 1.45
    # snap to straight edges (mean gradient magnitude of the sampled frames) around each side, then to the frame border
    import cv2
    g = sum(np.abs(cv2.Sobel(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), cv2.CV_32F, 1, 0, ksize=3)) for f in frames) / len(frames)
    gy = sum(np.abs(cv2.Sobel(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), cv2.CV_32F, 0, 1, ksize=3)) for f in frames) / len(frames)
    r0, r1 = max(0, int(max(0, y0) * h)), min(h, int(min(1, y1) * h) + 1)
    c0, c1 = max(0, int(max(0, x0) * width)), min(width, int(min(1, x1) * width) + 1)
    colp = [float(v) for v in g[r0:r1, :].mean(axis=0)] if r1 > r0 else []
    rowp = [float(v) for v in gy[:, c0:c1].mean(axis=1)] if c1 > c0 else []
    s = 0.09
    if colp:
        x0, x1 = _snap(colp, max(0, x0 - s), x0 + s, True), _snap(colp, x1 - s, min(1, x1 + s), True)
    if rowp:
        y0, y1 = _snap(rowp, max(0, y0 - s), y0 + s, True), _snap(rowp, y1 - s, min(1, y1 + s), True)
    x0, y0, x1, y1 = (float(v) for v in (max(0.0, x0), max(0.0, y0), min(1.0, x1), min(1.0, y1)))  # plain floats: numpy scalars are not JSON-serialisable
    # corner webcams sit flush against the frame edges: a side within 12% of the border is the border
    x0, x1 = (0.0 if x0 < 0.12 else x0), (1.0 if x1 > 0.88 else x1)
    y0, y1 = (0.0 if y0 < 0.12 else y0), (1.0 if y1 > 0.88 else y1)
    if x1 - x0 < 0.05 or y1 - y0 < 0.05:
        return None
    return {"box": [round(x0, 4), round(y0, 4), round(x1 - x0, 4), round(y1 - y0, 4)], "confidence": round(min(1.0, nf / len(frames)), 2), "hits": nf, "frames": len(frames),
            "face": [round(v, 4) for v in bx], "note": "a proposal: check the preview image before approving"}
