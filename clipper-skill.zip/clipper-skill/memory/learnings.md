# Lessons (agent reads first, appends after each job)
Format: `- [area] what went wrong or right -> what to do`.

- [boundaries] Clips that start on "and/but/so" lack setup -> the boundary engine pulls the prior sentence; do not shorten these by hand.
- [captions] Captions sit at ~75% height to clear platform UI; move the layout, not the captions, if they hide a face.
- [live] Chat runs 5-15 s behind video -> calibrate `--latency` on the first real stream.
- [critic] Trimming a filler opening can expose a dependent sentence ("And then..."): fixes can fight. The tool never pulls filler back in; if a clip still fails after 3 rounds, re-select the moment.
- [fixes] One structural edit per clip per round, then re-measure; never stack shifts.
- [speaker] A confidence gate tuned on 8 cases passed a false positive once tested on 12: always re-check thresholds on a different event before trusting them. Voice model quality (ECAPA vs d-vector) mattered more than any threshold.
- [validation] Never compare results against a clock I assumed: put an independent marker (a beep) in the stream. `-c copy` slices misalign video and transcript: re-encode.
- [upscale] Benchmark against the original (downscale then restore); always look at a face crop. Models can be 'better' on a number and worse on a face.
- [edit] Zoom blur comes from resampling twice (crop->scale 1080x1920->scale again). Crop the SOURCE at the zoom level and scale once; cap zoom by source lines (>=1080: 1.25, >=720: 1.16, else 1.06).
- [edit] Segment lengths must be multiples of 1/30 s or audio and picture drift apart over 20+ cuts. Trim/split from ONE input buffers the whole clip in RAM: use one seek-limited input per segment.
- [edit] Two people side by side with an unknown speaker: decide PER SHOT (two-shot = stacked, close-up = follow the face). A centred crop between two people cuts both faces.
- [edit] A hook headline cut at a connector ("...but") reads as a bug: cut at a comma, drop dangling words.
- [env] YouTube from a datacenter IP answers "confirm you're not a bot": needs the user's cookies or their own machine. Test with a direct-file source (archive.org) instead.
- [edit] A static crop x per segment loses a speaker who leans or moves: sample the tracker and pass a per-frame crop x expression. Keep the tracker dead zone below half the zoomed crop's slack (0.05).
- [edit] Pause-less ASR (no punctuation, no gap >= 0.3 s) defeats sentence-based length caps: fall back to the widest gap near the cap.
- [edit] Facecam detection must be strict (only faces < 1.2% of the frame in a corner): podcasts have large faces and any looser rule hits them.
- [edit] Cached renders hide planner changes: delete the clip's renders/ files (or bump studio.VERSION) after changing how a clip is planned.
