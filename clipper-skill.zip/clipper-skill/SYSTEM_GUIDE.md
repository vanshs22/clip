# clipper system guide (for any AI agent)

Goal: turn a YouTube link, an ended livestream/VOD, a live stream or a local file into finished, edited 1080x1920 Shorts/Reels/TikToks, and be able to say exactly what is good, what was checked and what was not.
Read `RUNBOOK.md` (one page) first, then `SKILL.md` (decision table). This guide explains the whole system and the judgement calls. Setup and cookies: `SETUP.md`.

## 0. The loop you run
1. **Source** -> `clipper run "<src>" --clips N --export out/` (recorded, YouTube, ended livestream) or `clipper watch "<src>" --clips N --out live/` (live). Do not stop to ask between stages.
2. **Understand why** -> `clipper analyze JOB`. Read it. A clip with no signal above the 80th percentile, no complete opening or no complete ending is a candidate for `clipper edit`.
3. **Judge** -> the automatic critics already ran in `run` (`polish`). Open the pictures: `clipper critique JOB --packet`, view every sheet, then `--submit`. If you cannot see images, run `--unavailable "<why>"` and tell the user emotion was not assessed.
4. **Fix** with `clipper edit` (never edit JSON or code), `clipper render JOB`, `clipper export JOB --out out/`.
5. **Report**: files, what each clip was chosen for (from `analyze`), `features_skipped`, what you did NOT verify.

## 1. Finding the moments (what is measured, and how much to trust it)
| Signal | Tool | Notes |
|---|---|---|
| Words, exact timing | faster-whisper (`--model balanced|quality`), or `--transcript words.json` | Re-transcribe with `--model quality` when the critic reports `captions_unreliable`. Output is often unpunctuated: boundaries use pauses, not only punctuation. |
| Speech excitement | `signals.text_series` | exclamations, laughter words, rate. |
| Loudness jumps | ffmpeg astats | evidence, never proof. |
| Picture activity | ffmpeg motion + scene cuts, OpenCV faces | `visual` series; dark/flat/frozen stretches are penalised by the critics. |
| Laughter, cheering, applause, screams | AST AudioSet tagger via earshot's stack (`requirements-ai.txt`), or PANNs | needs torch+transformers (~350 MB). Without it the `events` series is empty and `features_skipped` says so. A peak under 0.15 probability is noise and ignored. |
| On-screen text (VICTORY, scores, kill feeds) | RapidOCR (`pip install rapidocr-onnxruntime --no-deps`) | optional. |
| Chat spikes | YouTube replay chat (downloaded by yt-dlp with the video), Twitch VOD chat (TwitchDownloaderCLI), your `--chat file` (jsonl `{t,u,m}`, yt-dlp live_chat, TwitchDownloader json) | Spam, bot commands, links and one user repeating are removed; many different users saying the same thing is kept (that is the signal). |
| YouTube "most replayed" heatmap | yt-dlp | present only on some videos. |
| LLM judge (optional) | OpenAI (cap `--max-usd`, default 0.10) or local Ollama | only compact transcript text is sent, never media. |
Selection: `candidates` fuses these per profile (auto-detected: podcast/interview/gaming/irl/comedy/sports), ranks, dedupes, and `select` snaps each to a complete thought.
**Ended livestream with chat**: give the URL. The chat replay comes with the download; if it does not (members-only, disabled), pass `--chat`. If chat exists, a burst in it pulls a moment into the selection (verified: a synthetic burst of 70 different chatters moved a clip into the top 3).

## 2. Start and end (never half a thought)
- Boundaries snap to sentences/pauses, pull in setup for a dependent opening ("And then he..."), finish a cut-off thought, keep the answer to a question, keep a laughter tail. The cold open (strongest phrase first) is added later by the editor.
- Checked on the plan: `starts_mid_sentence`, `ends_mid_sentence` (a clip ending with a pause after the last word is a finished utterance; one ending on "and/the/a/..." or with the next word <0.35 s away is not), `unanswered_question`, `missing_setup`, `dead_air`, `too_long` (cap 75 s).
- Checked on the RENDER (`edges` critic): soft first frame (the thumbnail), soft last frame, silent first 0.25 s, a clip that ends while the sound is still loud.
- Fix: `clipper edit JOB N --start-shift -2.5 | --end-shift 1.2`.

## 3. The edit
Styles: built-in `viral podcast hype cinematic edu gamer classic` plus verified packs `comedy storytime motivation news reaction` and any pack you make (`skills/style-forge/SKILL.md`). `clipper style list`.
What the studio does per clip (one ffmpeg call): pauses and filler removed on a 30 fps grid, wide/tight zoom (each zoom is ONE resample of a source crop, never a crop-then-scale-then-zoom: that is what blurs), face-following close-ups (crop position follows the tracked face per frame), two people stacked top/bottom with the captions on the seam, gameplay over a detected facecam, a cold open, sound effects and a music bed ducked under the real word timeline, grade, progress bar.
Quality: lanczos scaling with sharpening, zoom capped by source height (1080p 1.25, 720p 1.16, below 1.06) and a `low_res_source` warning. Never use `--upscale ai` without looking at a frame (it redraws faces).
**Typography and placement (measured, not assumed)**
- A caption preset's `size` is the em size; ASS wants a line box, so `captions.eff()` converts. Captions are 3-4% of the frame height (50-80 px of 1920).
- Every caption sits at least 420 px above the bottom (platform UI zone), at least 170 px below the top and 60 px from the sides.
- The `placement` critic renders the caption file alone on black to get the exact text box, finds faces in the real render, and checks the text against the eyes-to-mouth zone and the safe zone. A fix is `clipper edit JOB N --caption-y <px>` (+ up). If no clean position exists it asks for `--layout fit`.
**Sound**
- Effects come from earshot's bank (252 sounds), each role (`pop swipe whoosh thud ding tick riser`) mapped to a take that passes earshot's audit (no clicks, DC, truncation, rising synth glides). Each take is placed by its measured sync point: hits and dings with the peak on the cue, taps with the onset on the cue, whooshes 40 ms after the cut they announce, risers ending on the cue. `renders/clip_NN_bed.wav.sfx.json` records every placement.
- Rules: effects only where something visible happens; no more than one per `style.sfx` seconds (>= 1.5); music 16-32 dB under speech and ducked; loudness -14 LUFS (-13.5 with a bed), true peak <= -1 dB.
- `sound` critic: voice-to-noise (>= 14 dB), muddy voice (presence vs low-mid, fix `--audio clean`), clipping, any effect more than 6 dB over the voice (fix `--sfx-gain -3`), music less than 14 dB under speech (fix `--music-gain`), effect sync, effects that fail earshot's audit.
- Real tracks beat the synthesised bed: `--music-dir folder` (file names containing a mood: `chill_01.mp3`). Never download or ship music you do not have the right to use.

## 4. The critics (what each looks at)
`cut` opening/ending/length/dead air - `story` completeness - `pace` - `captions` reading speed, confidence, presence - `placement` faces/safe zone/size/hook - `edges` first/last frame, audio start/tail - `framing` zoom discipline, crop moves, resolution - `frames` exposure, flat/black/frozen - `audio` loudness, true peak - `sound` the mix (above) - `vision` YOUR eyes (emotion 51% of the Murch weighting, story, eye-trace, plane, space, quality).
`clipper polish JOB` = critique -> mechanical fixes -> re-render, 3 rounds max. Findings that remain after that go to the user. The automatic critics never say "emotion fine": only you can, after looking.

## 5. Make your own style, or copy one
- By hand or by AI: `clipper style new NAME --extends viral`, edit the JSON (only ranges the schema allows), `clipper style verify NAME`.
- From a reference video: `clipper style from-reference REF.mp4 NAME`. It measures cuts per minute, median shot length, pauses, loudness, the level of whatever sits under the speech, colour (saturation, contrast, warmth, vignette), where the captions are and their highlight colour, and whether the layout is stacked, facecam or single, then writes a pack with the evidence inside it. It imitates pacing, grade, captions, music level, not content.
- A pack is unusable until `verify` passes (schema, grade runs, real render through the studio, QC clean, captions in the safe zone and readable, loudness, peak, no clipping, effects not spammy). Editing it afterwards invalidates the verification (hash). After `verify`, open `style_verify/NAME.png`, look, then `clipper style approve NAME --note "what you saw"`.

## 6. Failure handling
| Symptom | Cause | Do |
|---|---|---|
| "Sign in to confirm you're not a bot" | YouTube blocks the IP/session | `--cookies-from-browser chrome` on the user's machine, or `--cookies cookies.txt` (SETUP.md). Never bypass a login. |
| `features_skipped: studio edit` | the studio render failed for one clip; the classic renderer was used | read the message (it keeps the ffmpeg error), fix or pass `--edit classic` knowingly. |
| `events`/`ocr` series empty | optional model missing | install `requirements-ai.txt` / rapidocr, or accept and say so. |
| clips too long | transcript without pauses | `CLIPPER_MAX_CLIP_S`, or `edit --end-shift`. |
| a stage looks stale | cache is by input hash | `clipper process SRC ... --force-from <stage>`; to re-plan framing delete that clip's files in `renders/`. |
| `round limit reached` | polish already ran 3 rounds | show the remaining findings to the user. |

## 7. Honesty checklist (put the answers in your report)
Did you look at frames? Listen? (You cannot listen: measurements only.) Which optional signals were missing? Which YouTube/chat/livestream paths were exercised on real platform data and which only on files? Which styles were rendered on real footage versus a synthetic clip?
