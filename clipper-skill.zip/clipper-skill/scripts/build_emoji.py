"""Regenerate clipper/emoji/*.png (256x256) from the Twemoji SVGs (CC-BY 4.0, jdecked/twemoji). Needs network and `pip install resvg-py`.
Run from the repo root:  python scripts/build_emoji.py   (the PNGs are committed; this only documents how they were made)."""
import pathlib, sys, urllib.request
import resvg_py

D = pathlib.Path(__file__).resolve().parents[1] / "clipper" / "emoji"
for p in sorted(D.glob("*.png")):
    svg = urllib.request.urlopen(f"https://cdn.jsdelivr.net/gh/jdecked/twemoji@latest/assets/svg/{p.stem}.svg", timeout=30).read().decode()
    p.write_bytes(bytes(resvg_py.svg_to_bytes(svg_string=svg, width=256, height=256)))
    print("ok", p.name, file=sys.stderr)
