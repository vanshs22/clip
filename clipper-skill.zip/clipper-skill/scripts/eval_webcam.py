"""Measure webcam detection on YOUR face image: composites it into each corner (with/without a border) of a moving 1920x1080 frame and prints the IoU of the
box clipper finds against the truth.   python scripts/eval_webcam.py face.jpg      (needs opencv-python-headless, numpy and ffmpeg)
Measured with the standard 512x512 'Lena' test image: 8 cases, mean IoU 0.96, min 0.88 (see CHANGELOG). Real stream layouts vary: always check the preview image."""
import os, subprocess, sys, tempfile
import cv2, numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from clipper import webcam
from clipper.util import ffmpeg, probe


def make(face, path, border, corner, W=1920, H=1080, cw=480, ch=360, secs=10):
    vw = cv2.VideoWriter(path + ".avi", cv2.VideoWriter_fourcc(*"MJPG"), 10, (W, H))
    cam = cv2.resize(face, (cw, ch))
    for k in range(secs * 10):
        g = np.zeros((H, W, 3), np.uint8)
        g[:] = (40 + (k * 3) % 120, 90, 160 - (k * 2) % 100)
        for j in range(30):
            cv2.rectangle(g, ((j * 97 + k * 23) % W, (j * 53 + k * 11) % H), ((j * 97 + k * 23) % W + 120, (j * 53 + k * 11) % H + 90), (255 - j * 6, (j * 40 + k) % 255, j * 8), -1)
        x0, y0 = (0 if "l" in corner else W - cw), (H - ch if "b" in corner else 0)
        c = cv2.warpAffine(cam, np.float32([[1, 0, (k % 5) - 2], [0, 1, (k % 3) - 1]]), (cw, ch))
        if border:
            cv2.rectangle(c, (0, 0), (cw - 1, ch - 1), (255, 255, 255), 6)
        g[y0:y0 + ch, x0:x0 + cw] = c
        vw.write(g)
    vw.release()
    subprocess.run([ffmpeg(), "-y", "-v", "error", "-i", path + ".avi", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", path], check=True)
    return x0 / W, y0 / H, cw / W, ch / H


def iou(a, b):
    ix, iy = max(0, min(a[0] + a[2], b[0] + b[2]) - max(a[0], b[0])), max(0, min(a[1] + a[3], b[1] + b[3]) - max(a[1], b[1]))
    return ix * iy / (a[2] * a[3] + b[2] * b[3] - ix * iy)


if __name__ == "__main__":
    face, res = cv2.imread(sys.argv[1]), []
    for corner in ("bl", "br", "tl", "tr"):
        for border in (True, False):
            p = os.path.join(tempfile.mkdtemp(), "v.mp4")
            truth = make(face, p, border, corner)
            r = webcam.detect(p, probe(p))
            res.append(iou(truth, r["box"]) if r else 0.0)
            print(corner, "border" if border else "plain", "IoU", round(res[-1], 2))
    print("mean", round(sum(res) / len(res), 2), "min", round(min(res), 2))
