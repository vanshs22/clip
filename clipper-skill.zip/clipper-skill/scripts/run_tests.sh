#!/usr/bin/env bash
# Run the whole suite with LIVE progress, safe for sandboxes/CI that cut off long single commands.
#   scripts/run_tests.sh            unit + integration + agents (about 6 minutes; ffmpeg required)
#   scripts/run_tests.sh --live     also the RTMP livestream tests (about 4 more minutes; needs yt-dlp + MediaMTX download)
# Progress goes to the terminal AND to test-run.log, one line per test, flushed immediately. If the shell you use kills commands after ~1 minute,
# start it in the background (`scripts/run_tests.sh > /dev/null &`) and `tail -f test-run.log`.
set -u
cd "$(dirname "$0")/.."
files="tests/test_unit.py tests/test_integration.py tests/test_agents.py"
[ "${1:-}" = "--live" ] && files="$files tests/test_live.py"
PYTHONUNBUFFERED=1 python3 -u -m pytest $files -v -p no:cacheprovider 2>&1 | tee test-run.log
exit "${PIPESTATUS[0]}"
