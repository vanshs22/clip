# Changelog

## Unreleased
### Changed (breaking)
- **No API key, no provider calls.** `llm.py`, `--mode`, `--max-usd/--max-calls/--max-tokens`, `OPENAI_API_KEY`, Ollama are gone. The model in your IDE is the judge: `clipper run` pauses at `awaiting_judge`; `clipper judge JOB` writes `judge/packet.json`; the model scores each candidate (hook, payoff, emotion, value, shareability, standalone, hook type, title, headline, reason, flags, optional start/end words) and submits with `clipper judge JOB --submit FILE` (strict validation, rejected items come back with reasons). `clipper continue JOB --export DIR` finishes. `--no-judge` runs unattended with local scores. MCP: `get_judging_packet`, `submit_judgments`, `continue_job`.
- The plan key `cost` is now `judging`; the report's `openai` is now `judging`.
### Added
- **Chat for Twitch and Kick in moment detection** (`clipper/chat.py`): Twitch VOD chat (public GraphQL, offset paging; cursor paging needs an integrity token), Kick VOD chat (public messages endpoint, rate-limited), Kick live chat (poller, also used by `watch`), Twitch live IRC as before. Long VODs: one sampled pass to find the busy minutes, then the hottest windows are read completely (bounded by requests/time); unread time is interpolated, never treated as silence. Hype emotes (KEKW, LUL, POG, W, ...) and "clip it/that" requests weigh more than plain messages.
- **Opening review**: clips no longer open on throat-clearing ("Okay.", "Yeah.", "So, um"); stronger local hook score (question/claim/number/curiosity gap, penalty for filler or dangling conjunction).
- **Captions**: emphasis words (numbers, never/always/free/...; colour + small zoom), keyword **emoji** (50 bundled Twemoji PNGs, pop-in overlay above the captions, spaced and capped), and model edits (`clipper captions JOB N [--set FILE|--emoji on|off|--emphasis on|off|--clear]`: fix words, force/remove emphasis, place emoji; validated all-or-nothing against the clip's word range).
- **Layouts need your approval**: `clipper layout JOB N` (grid frame + options + local recommendation), `--propose NAME --cam ... --reason` (preview image, nothing applied), `--approve` / `--reject`. `edit --layout split` is refused on purpose. Edits and approved layouts survive re-judging (matched by candidate key).
- **Speed**: batched Whisper (about 7x faster on the same weights: 230 s of speech in 9.6 s vs 69.5 s, `small` int8 on 8 CPU cores), language detected once, cuts+motion in ONE video decode (2.4 s vs 4.7 s for 10 min of 720p, identical results), signal passes in parallel, parallel clip rendering where it helps (GPU encoder or 16+ cores; `CLIPPER_RENDER_WORKERS`), `--fast` (transcribe only the windows loudness/chat/motion point at, sources over 15 min), yt-dlp `-N 4`.
- **Links from socials**: TikTok, Instagram, X, Reddit, Vimeo, Rumble, Dailymotion, Bilibili, Twitch clips classified; one video only (`--no-playlist`), retries and socket timeout, `--cookies browser:chrome`, error hints (login, rate limit, region, update yt-dlp).
- 20 caption presets (was 9) and 11 multi-region layouts (see earlier notes), `--hook`, `--progress`.
### Fixed
- `edit --hook` stored its text in the clip's numeric local hook score and crashed the critics (found by running the real CLI); the headline now lives in `headline`.
- ffmpeg failures now report the error lines (full log in `clip_NN.ffmpeg.log`) instead of the last progress lines.
### Closed in the follow-up pass (each was a listed limit; how it was checked)
- **Emoji sharpness**: 256x256 PNGs rendered from the Twemoji SVGs (was 72 px); `scripts/build_emoji.py`; test asserts every file is 256 px.
- **Automatic webcam detection** (`clipper/webcam.py`, `clipper layout JOB N --auto-cam`, `webcam_detected` in the layout output): small persistent face -> webcam rectangle snapped to edges/borders. Measured with a real face (the standard 512x512 Lena test image, not bundled) composited into every corner, with and without a border, on a moving 1920x1080 frame: **mean IoU 0.96, min 0.88** over 8 cases (`scripts/eval_webcam.py FACE.jpg` repeats it). Real stream layouts vary: it is a proposal, the user approves from the preview.
- **New layouts**: `story_card` / `story_filler` (white rounded text card on top, drawn in the caption file; text = `--card`, else the judge's hook_text/title) and `speaker_pip` (follows the speaker full-frame, small round window of the other person; falls back to `fill` when two people were not seen).
- **Per-moment caption style**: `--style auto` is now the default; `captions.auto_style` picks the preset per clip from the profile and the judge's hook_type/emotion (heuristic table, one function).
- **Kick VOD skew**: chat offset is estimated against the loudness bursts (cross-correlation, +-20 s, only applied when it clearly beats 0 s) and corrected; tests recover offsets from -12 s to +15 s.
- **Chat endpoint fragility**: `chat-downloader` fallback when the direct endpoints fail, `clipper doctor --chat` probes all three endpoints and names the broken one (checked live against Twitch and Kick), `--chat-full` reads nearly every message. Real-scale check: a 7.8 h Twitch VOD (27,936 s), 1,212 requests, 43 s, 42,165 messages, 0 errors, 67% of the stream read inside the default time budget.
- **Languages**: hook openers/curiosity words, throat-clearing openers, dependent-sentence openers and laughter/hype words for Spanish, Portuguese, French, German and Italian (language is not detected: any lexical match counts). Other languages: digits/?/! cues + the judge's hook score.
- **Hardware encoders**: every option we pass to NVENC/QSV/AMF is accepted by the ffmpeg build here (it only fails at device open: no GPU); the VideoToolbox `-allow_sw` option was removed because this ffmpeg rejects it. **A real GPU run is still untested.**
- **Long sources**: a 2-hour local file (178 MB) went through the whole pipeline in 26 s (signals 6 s, peak 552 MB); a 7.8 h real chat was fetched (above). A multi-hour *download and render* of a real VOD was not run.
- **Test runs that looked frozen**: not a hang. Output redirected to a file is block-buffered, and a sandbox that gives each command its own process namespace hides background jobs from `ps`. Fixed with line-buffered test output (`tests/conftest.py`) and `scripts/run_tests.sh` (live progress, `test-run.log`). The full suite passes in ONE run: 181 passed, 1 skipped, 342 s.
### Bugs found while closing those (all fixed, all have tests)
- `--style auto` (the new default) crashed the editor-critic step (found by the 2-hour run).
- Webcam result held numpy floats and crashed `clipper layout` on real footage (found by running the CLI).
### Found by recording REAL livestreams (Twitch x2, Kick x1)
- **Twitch ad breaks were exported as "highlights".** Joining a Twitch stream anonymously gets the ad slate ("Commercial break in progress", a blurred gradient) for most of a short recording; the old pipeline ranked it by motion/audio, rendered it and QC passed it. New: a per-second picture-detail signal (`signals.detail_series`, computed inside the single `visual_pass` decode) measured on the real recordings (ad slate 1.7-2.1, real gameplay/talk 8-12); candidates whose window is >=70% flat are dropped (listed in `candidates.json` as `dropped_flat`) and QC fails a clip with `flat_picture` using the SOURCE detail of its window (never the finished render: a blurred-background layout alone scores ~1.8, which a first version of this check got wrong and the e2e tests caught). On the real Twitch recording the two clips that used to export are now rejected. Not validated on animation/minimal art styles: `CLIPPER_FLAT_T=0` turns it off.
- Limit that remains: if most of a short recording is an ad slate there is nothing real to clip (that is what the filter now says by producing 0 clips); a logged-in/Turbo recording or a later window avoids it.
- Kick live: 83 s of real 1080p GTA footage recorded, 197 live chat messages read through the poller, 2 clips exported (sample in `livestream-test/`).

### Found by running a REAL YouTube video with cookies (all fixed, all with tests)
- YouTube now needs a JavaScript runtime (node/deno/bun + `yt-dlp-ejs`) even WITH valid cookies: without one every download says "Requested format is not available". clipper now passes `--js-runtimes` for the first runtime on PATH, `yt-dlp[default]` is the pinned dependency, the error hint says what to install, and `clipper doctor` lists node/deno/bun.
- yt-dlp could not find ffmpeg to merge video and audio, left `source.f399.mp4` (video only) + `source.f258.m4a`, and clipper took the video-only fragment as THE source (transcription then crashed). Downloads now pass `--ffmpeg-location`, fragments are never accepted as a source, and an unmerged download stops with a clear message.
- `yt-dlp` not on PATH but importable (pip --target, venvs): clipper now runs `python -m yt_dlp`; the live-stream URL lookup uses the same command and flags.
- `clipper layout JOB N` crashed on machines without OpenCV (the face detector imports it lazily); webcam detection now reports "opencv not installed" and returns nothing.
- **A judging mistake with a product cause**: frame strips carry no name, and when several were opened in one batch they came back in a different order than requested, so two candidates were scored from each other's pictures (the render exposed it: clip 1's headline was about a squirrel, the picture was a bunny). Strips now have `KEY <key> <times>` burned into the picture and `judge --frames` writes labelled contact sheets (5 rows per image, rank order) in `frame_sheets`; SKILL.md says to judge by the key on the picture.
- Re-selection carries per-clip edits (including `--drop`) across sessions by design; that silently dropped a clip in a later session. `clipper judge JOB --reset` now clears scores and carried-over edits.
- Real data check: YouTube's "most replayed" heatmap arrived through yt-dlp and fed the `heat` signal (e.g. 0.94 on the credits, which the local score then over-ranked: the credits scored top locally and were rejected by the judge from the frames, which is the judge's job).
### Still not done
- A 10-minute 1080p YouTube video (Big Buck Bunny, CC-BY) went through download, signals, judging, headlines, render and export with cookies. Still not run: a real GPU encoder, a real multi-hour VOD download+render, no real two-person footage for `speaker_pip` (it is tested with a preset pair; who-is-where comes from the existing speaker module).
- Chat endpoints are unofficial and can change (detected by `doctor --chat`, fallback needs `pip install chat-downloader`). Kick chat alignment also removes the viewers' reaction lag by design.
- Webcam detection needs a visible face; a faceless/vtuber/camera-off overlay needs `--cam`.
- Languages beyond ES/PT/FR/DE/IT/EN rely on the judge for hook quality.

## 0.4.0 — production hardening (this release)
Backup of the previous state: git tag `pre-hardening` (also `backup/clipper-skill-pre-hardening.zip` at release time). Baseline: `validation/baseline-before-hardening.txt` (14/14 old selftest checks).

### Added
- **One-shot workflows**: `clipper run URL --export out/` and `clipper watch LIVE --out dir/` (record, detect, auto-finalize, process, polish, export; no second command). MCP `clip_video` / `monitor_livestream` do the same.
- **Live engine**: persistent session state machine (`session.json`), `watch --resume`, reconnect with recorded gaps, frame-accurate re-encoded extraction, bounded memory, live LLM judging sharing the cache and budget with the final pass, CANCEL marker, graceful SIGINT/SIGTERM.
- **Model manager** (`clipper/models.py`, `models_manifest.json`): SHA-256 pinned, resumable, atomic, offline mode; optional-model failure degrades features and is reported.
- **Job identity**: source content fingerprints, per-stage input hashes chained through dependencies, per-clip render keys incl. source + options, job lock.
- **LLM safety**: indices validated against each candidate's own window, strict typed validation, retries with backoff, hard token/USD/call budget with reservation, persistent budget file, provider fallback (OpenAI -> Ollama -> local).
- **Detection**: event-only candidates for speech-free highlights, chat spam/giveaway filtering, YouTube heatmap signal, auto profile, live-candidate merge, optional bounded dense core (off by default).
- **Boundaries**: delayed-answer and laughter-tail handling, unpunctuated-run splitting, bounded setup chains, boundary-quality score, trim-back when the source ends mid-sentence.
- **Editing**: 9 caption presets + custom style file, bundled OFL fonts, speaker colours, logo, fades, intro/outro, per-encoder quality args with real test encodes, frozen-picture and caption-overflow QC, previews (`clipper styles --preview`).
- **Agents**: 12 MCP tools, non-blocking calls, progress notifications, cancel, schema validation, queue recovery by pid.
- **Packaging**: dependency groups, tested lockfile, Windows/Linux/macOS installers incl. the OpenCV repair, CI matrix, THIRD_PARTY, SECURITY.

### Fixed (found by the new tests / real footage)
- **`audio_rms` returned 6 values per second** (resampled after counting samples): every audio-based pick was misplaced. Regression-tested.
- Resumable model download never resumed (short reads were treated as complete).
- `candidates()` crashed when signal series differed in length by one sample.
- A non-video file passed ingest and produced "0 clips, exit 0".
- Setup-sentence chain walked back through a whole transcript of "And ..." lines.
- Critic proposed extending a clip past the end of the media.
- Chat-to-video clock offset, OpenCV 5 Haar removal, numpy values in JSON, captions selecting words by end time, clip planned beyond media end (earlier releases).

### Known limits: see docs/SPEC.md and the final report.
