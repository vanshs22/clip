# Changelog

## 0.5.0 — the edit
### Added
- **Studio renderer** (`studio.py`, planner `director.py`): one ffmpeg call per clip. Jump cuts and filler removal on a 30 fps grid (picture and sound cannot drift), alternating wide/tight zoom, snap-zoom on payoff words, per-shot layout (close-up follows the face, two-shot stacked with a divider, `fit`, `game` + facecam), hook headline, number callouts, progress bar, flashes, colour grade. Zooms crop the source once, no double resampling.
- **Audio** (`sfxsynth.py`): synthesised sound effects (whoosh, swipe, pop, thud, riser, ding, tick) and six music moods, ducked by the real word timeline; own tracks via `--music-dir`. No licensed assets.
- **Edit styles** `viral podcast hype cinematic edu gamer` (`--edit`, per clip `--edit-style`), `classic` keeps the old renderer. Failures fall back to classic and are reported in `features_skipped`.
- **Virality** (local, free): `director.text_score` (power words, contrast, story, numbers, direct address, sponsor-read penalty) joins the clip score; `tighten` starts a clip on its strongest sentence; the LLM prompt now scores scroll-stopping openings, payoff and a headline title (cache key bumped).
- **Remotion** template (`remotion/`: StatCallout, LowerThird, Explainer, BarChart, transparent VP9) + `--overlay FILE@t:dur:y`; skill `skills/remotion-graphics`.
- Speed: clips render 2-3 at a time, QC is one decode pass instead of three, default x264 preset `faster` crf 19 (`high` = medium crf 17).
### Fixed
- Face detector (OpenCV YuNet) is not thread-safe: guarded. yt-dlp is pointed at `node` when deno is absent.

## 0.4.0 — production hardening (this release)
Backup of the previous state: git tag `pre-hardening` (also `backup/clipper-skill-pre-hardening.zip` at release time). Baseline: `validation/baseline-before-hardening.txt` (14/14 old selftest checks).

### Added
- **One-shot workflows**: `clipper run URL --export out/` and `clipper watch LIVE --out dir/` (record, detect, auto-finalize, process, polish, export; no second command). MCP `clip_video` / `monitor_livestream` do the same.
- **Live engine**: persistent session state machine (`session.json`), `watch --resume`, reconnect with recorded gaps, frame-accurate re-encoded extraction, bounded memory, live LLM judging sharing the cache and budget with the final pass, CANCEL marker, graceful SIGINT/SIGTERM.
- **Model manager** (`clipper/models.py`, `models_manifest.json`): SHA-256 pinned, resumable, atomic, offline mode; optional-model failure degrades features and is reported.
- **Job identity**: source content fingerprints, per-stage input hashes chained through dependencies, per-clip render keys incl. source + options, job lock.
- **LLM safety**: indices validated against each candidate's own window, strict typed validation, retries with backoff, hard token/USD/call budget with reservation, persistent budget file, provider fallback (OpenAI -> Ollama -> local).
- **Detection**: event-only candidates for speech-free highlights, chat spam/giveaway filtering, YouTube heatmap signal, auto profile, live-candidate merge, optional bounded dense core (off by default).
- **Boundaries**: delayed-answer and laughter-tail handling, unpunctuated-run splitting, bounded setup chains, boundary-quality score, trim-back when the source ends mid-sentence.
- **Editing**: 9 caption presets + custom style file, bundled OFL fonts, speaker colours, logo, fades, intro/outro, per-encoder quality args with real test encodes, frozen-picture and caption-overflow QC, previews (`clipper styles --preview`).
- **Agents**: 12 MCP tools, non-blocking calls, progress notifications, cancel, schema validation, queue recovery by pid.
- **Packaging**: dependency groups, tested lockfile, Windows/Linux/macOS installers incl. the OpenCV repair, CI matrix, THIRD_PARTY, SECURITY.

### Fixed (found by the new tests / real footage)
- **`audio_rms` returned 6 values per second** (resampled after counting samples): every audio-based pick was misplaced. Regression-tested.
- Resumable model download never resumed (short reads were treated as complete).
- `candidates()` crashed when signal series differed in length by one sample.
- A non-video file passed ingest and produced "0 clips, exit 0".
- Setup-sentence chain walked back through a whole transcript of "And ..." lines.
- Critic proposed extending a clip past the end of the media.
- Chat-to-video clock offset, OpenCV 5 Haar removal, numpy values in JSON, captions selecting words by end time, clip planned beyond media end (earlier releases).

### Known limits: see docs/SPEC.md and the final report.
