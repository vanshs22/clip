"""0.7: caption placement, earshot sound bank + sync, style packs (verification gate), reference analysis, pause-aware boundaries."""
import json
import subprocess
import pytest
from clipper import boundaries as B, captions, placement as PL, stylepack as SP, director as D
from clipper.util import ffmpeg

np = pytest.importorskip("numpy")


def test_every_caption_preset_stays_out_of_the_platform_ui_zone():
    for n in captions.PRESETS:
        assert captions.style(n)["mv"] >= captions.SAFE_MV, n
    assert captions.eff(captions.style("bold_pop")) > captions.style("bold_pop")["size"]  # ASS Fontsize is a line box, not an em


def test_best_shift_clears_a_face_and_stays_safe():
    box = (200, 1380, 880, 1460)  # captions near the bottom
    boxes = [(0.0, box), (0.5, box)]
    faces = [[(300, 1300, 700, 1500)], [(300, 1300, 700, 1500)]]  # the mouth sits under them
    s, e = PL.best_shift(boxes, faces)
    assert s > 0 and e["face_hits"] == 0 and e["unsafe"] == 0
    assert PL.best_shift(boxes, [[], []])[0] == 0  # nothing in the way: do not move


def test_text_boxes_measures_rendered_caption_position(tmp_path):
    ws = [{"w": "hello", "s": 0.0, "e": 0.4}, {"w": "world", "s": 0.4, "e": 0.9}]
    captions.install_fonts(tmp_path)
    (tmp_path / "c.ass").write_text(captions.build(ws, 0.0, "bold_pop", y_offset=300), encoding="utf-8")
    bx = [b for _, b in PL.text_boxes("c.ass", 0.9, tmp_path, fps=4) if b]
    assert bx and PL.H - captions.SAFE_MV - 300 - 120 < bx[0][3] < PL.H - captions.SAFE_MV - 300 + 40  # the bottom edge is where the margin says it is


def test_sound_bank_takes_are_audited_and_aligned():
    from clipper import ears, sfxsynth as S
    if not ears.available():
        pytest.skip("earshot dependencies not installed")
    for k in S.SFX_LEN:
        tk = ears.take(k)
        assert tk and tk["ok"] and not tk["warnings"], (k, tk and tk["warnings"])  # every role passes earshot's model-free audit
        assert 0 <= tk["align_s"] <= len(tk["y"]) / tk["sr"]


def test_bed_places_the_sync_point_on_the_cue(tmp_path):
    from clipper import ears, sfxsynth as S
    if not ears.available():
        pytest.skip("earshot dependencies not installed")
    ev = [{"t": 1.0 + 1.5 * i, "kind": k} for i, k in enumerate(["pop", "thud", "ding", "swipe", "riser"])]
    S.bed(tmp_path / "b.wav", 10.0, [{"w": "a", "s": 1, "e": 2}], None, -22, ev)
    placed = json.loads((tmp_path / "b.wav.sfx.json").read_text())
    assert len(placed) == 5 and all(abs(p["at"] - p["target_t"]) < 0.002 for p in placed)


def test_style_pack_schema_and_gate(tmp_path):
    good = {"name": "mystyle", "description": "d", "when": "w", "extends": "viral", "edit": {"gap": 0.4, "zoom": [1.0, 1.1], "mood": "upbeat"}}
    assert SP.validate(good) == []
    for bad in ({"gap": 0.05}, {"zoom": [1.0, 2.0]}, {"music_db": -5}, {"sfx": 0.5}, {"mood": "angry"}, {"grade": "eq=1;rm -rf /"}, {"typo_key": 1}):
        assert SP.validate({**good, "edit": bad}), bad
    assert SP.validate({**good, "name": "viral"})  # collides with a built-in
    assert not SP.usable(good)  # never verified
    v = {**good, "verified": {"hash": SP.canon(good), "automatic": True}}
    assert SP.usable(v)
    assert not SP.usable({**v, "edit": {**v["edit"], "gap": 0.3}})  # edited after verification: unusable until re-verified


def test_shipped_packs_are_verified_and_current():
    st = SP.load_all()
    assert {"comedy", "storytime", "motivation", "news", "reaction"} <= set(st) and all(v in ("verified", "approved") for v in st.values())
    for n in ("comedy", "news"):
        assert n in D.STYLES and D.style_for(n, None)[0] == n


def test_ends_mid_sentence_is_pause_aware():
    ws = [{"w": w, "s": i * 0.4, "e": i * 0.4 + 0.3} for i, w in enumerate("we went to the store and bought milk then we left".split())]
    ws[8]["e"] -= 0.0
    clip = {"final_words": [0, 7], "final_start": 0.0, "final_end": ws[7]["e"] + 0.2}
    assert "ends_mid_sentence" in B.validate(ws, clip)  # next word follows within 0.1 s: cut mid-flow
    ws2 = [dict(w, s=w["s"] + (1.2 if i >= 8 else 0), e=w["e"] + (1.2 if i >= 8 else 0)) for i, w in enumerate(ws)]
    assert "ends_mid_sentence" not in B.validate(ws2, {"final_words": [0, 7], "final_start": 0.0, "final_end": ws2[7]["e"] + 0.2})  # a real pause follows: a finished utterance
    ws2[7]["w"] = "and"
    assert "ends_mid_sentence" in B.validate(ws2, {"final_words": [0, 7], "final_start": 0.0, "final_end": ws2[7]["e"] + 0.2})  # but "and" is a dangling word


def test_reference_finds_caption_band_and_cuts(tmp_path):
    from clipper import reference
    ws = [{"w": w, "s": round(i * 0.5, 2), "e": round(i * 0.5 + 0.45, 2)} for i, w in enumerate("this is the thing that everybody keeps asking about every single day now".split() * 2)]
    captions.install_fonts(tmp_path)
    (tmp_path / "c.ass").write_text(captions.build(ws, 0.0, {**captions.style("bold_pop"), "mv": 700, "hi": "&H0000E5FF"}), encoding="utf-8")
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-f", "lavfi", "-i", "color=c=0x303840:s=540x960:r=10:d=12", "-vf", "subtitles=c.ass:fontsdir=fonts,format=yuv420p", "-c:v", "libx264", "c.mp4"], cwd=tmp_path, check=True)
    fr, _ = reference._frames(tmp_path / "c.mp4", 2, 24, w=270)
    cb = reference.caption_band(fr)
    assert cb and abs(cb["y_centre_frac"] - (1 - (700 + 60) / 1920)) < 0.05  # captions sit ~760 px from the bottom
