"""Studio edit: cuts stay on the frame grid, text scoring ranks sensibly, and a synthetic clip renders to the planned length with sound."""
import subprocess
import pytest
from clipper import director as D, render as R
from clipper.util import ffmpeg, probe

np = pytest.importorskip("numpy")


def _words(n=60, gap_at=(20,), gap=1.2):
    out, t = [], 0.0
    for i in range(n):
        out.append({"w": "money" if i % 17 == 5 else "word", "s": round(t, 3), "e": round(t + 0.3, 3)})
        t += 0.3 + (gap if i in gap_at else 0.04)
    return out


def test_pauses_cut_and_grid():
    ws = _words()
    end = ws[-1]["e"] + 0.2
    rng = D.keep_ranges(ws, 0.0, end, 0.4)
    assert len(rng) == 2 and rng[0][1] < ws[21]["s"] - 0.1  # the 1.2 s pause is gone
    segs = D.snap(rng, 0.0)
    assert all(abs(a * 30 - round(a * 30)) < 5e-3 and abs(b * 30 - round(b * 30)) < 5e-3 for a, b in segs)
    assert abs(D.tmap(segs, segs[1][0]) - (segs[0][1] - segs[0][0])) < 1e-6  # time after the cut maps to just after the first range


def test_no_cuts_for_sparse_speech():
    assert D.keep_ranges(_words(6), 0.0, 30.0, 0.4) == [(0.0, 30.0)]


def test_text_score_prefers_hooks_over_fluff():
    good = D.text_score("Nobody tells you the truth about money, but you lose 50 percent of it in fees.")
    bad = D.text_score("so yeah um welcome back and subscribe, use code SAVE at checkout")
    assert good >= 0.5 > bad


def test_sfx_and_bed(tmp_path):
    from clipper import sfxsynth as S
    ev = [{"t": 0.5, "kind": k} for k in S.SFX_LEN]
    ev = [{**e, "t": 0.5 + 1.2 * i} for i, e in enumerate(ev)]
    p = S.bed(tmp_path / "b.wav", 10.0, [{"w": "a", "s": 1, "e": 2}], "chill", -22, ev)
    assert probe(str(p))["duration"] == pytest.approx(10.0, abs=0.05)
    assert all(np.isfinite(S.sfx(k)).all() for k in S.SFX_LEN) and all(np.isfinite(S.music(m, 3)).all() for m in S.MOODS)


@pytest.mark.parametrize("layout,edit", [("fill", "viral"), ("split", "podcast"), ("fit", "hype")])
def test_render_synthetic(tmp_path, layout, edit):
    src = tmp_path / "s.mp4"
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=1280x720:r=25:d=14", "-f", "lavfi", "-i", "sine=f=220:d=14",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(src)], check=True)
    ws = _words(70, gap_at=(20, 45), gap=0.9)
    ws = [w for w in ws if w["e"] < 13.5]
    clip = {"id": 1, "final_start": 0.5, "final_end": 13.0, "layout": layout, "focus_x": 0.5, "title": "A test headline", "caption": {"style": None, "scale": 1.0}, "split_auto": [0.3, 0.7]}
    info = probe(str(src))
    f = R.render_clip(str(src), clip, tmp_path / "r", ws, info, opts={"style": "auto", "edit": "auto", "profile": "podcast", "src_fp": "t", "edit_opts": {"style": edit}})
    out = probe(str(f))
    assert (out["width"], out["height"]) == (1080, 1920) and out["audio"]
    assert out["duration"] == pytest.approx(clip["out_dur"], abs=0.15) and clip["out_dur"] < 12.5  # pauses were removed
    assert not R.qc(str(f), clip)[0]


def _talk(n=120, s0=100.0, pay=(60, 69)):
    """Unpunctuated speech, a pause every 8 words; words pay[0]..pay[1] are a short, punchy, money-heavy phrase."""
    out, t = [], s0
    for i in range(n):
        w = "million dollars money free secret never".split()[i % 6] if pay[0] <= i <= pay[1] else "okay"
        out.append({"w": w, "s": round(t, 3), "e": round(t + 0.3, 3)})
        t += 0.3 + (0.6 if i % 8 == 7 else 0.04)
    return out


def test_cold_open_goes_first_and_plan_adds_its_length():
    ws = _talk()
    s, e = ws[0]["s"] - 0.2, ws[-1]["e"] + 0.2
    tz = D.pick_teaser(ws, s, e)
    assert tz and "million" in tz[2] and tz[0] >= 7.9 and 2.0 <= tz[1] - tz[0] <= 7.0  # the money phrase from the body (>= 8 s in) is picked
    assert D.pick_teaser(ws[:10], s, s + 5) is None  # too short to need one


def test_cap_length_ends_inside_limit_even_without_punctuation():
    ws = _talk(300)
    c = {"final_start": ws[0]["s"], "final_end": ws[-1]["e"], "final_words": [0, 299], "text": ""}
    D.cap_length(c, ws, [(0, 299)])
    assert c["final_end"] - c["final_start"] <= 75.5 and c.get("capped")
    ws = [{"w": "yes" if i % 9 else "okay", "s": round(i * 0.34, 3), "e": round(i * 0.34 + 0.3, 3)} for i in range(400)]  # no pauses at all
    c = {"final_start": 0.0, "final_end": ws[-1]["e"], "final_words": [0, 399], "text": ""}
    D.cap_length(c, ws, [(0, 399)])
    assert c["final_end"] <= 75.5 and c.get("capped")


def test_loud_peaks_and_zoom_cap_and_game_geom():
    a = [1.0] * 100
    a[30] = a[70] = 9.0
    assert D.loud_peaks(a) == [30, 70] and D.loud_peaks([1.0] * 50) == []
    assert D.max_zoom(1080) > D.max_zoom(720) > D.max_zoom(360)
    from clipper import studio as S
    g = S.game_geom({"width": 1920, "height": 1080}, (0.62, 0.02, 0.38, 0.26))
    assert g["game_h"] + g["cam_h"] + 12 + 2 * 110 <= 1920 + 150 and g["y1"] > g["y0"]


def test_follow_keyframes_only_when_subject_moves():
    clip = {"focus_auto": [[[0.0, 0.5], [10.0, 0.5]]]}
    assert D.xkf(clip, [], 0.0, 8.0) is None
    clip = {"focus_auto": [[[0.0, 0.4], [1.0, 0.7], [10.0, 0.7]]]}
    kf = D.xkf(clip, [], 0.0, 6.0)
    assert kf and kf[0][0] == 0.0 and kf[-1][1] == 0.7
