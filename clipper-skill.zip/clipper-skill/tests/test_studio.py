"""Studio edit: cuts stay on the frame grid, text scoring ranks sensibly, and a synthetic clip renders to the planned length with sound."""
import subprocess
import pytest
from clipper import director as D, render as R
from clipper.util import ffmpeg, probe

np = pytest.importorskip("numpy")


def _words(n=60, gap_at=(20,), gap=1.2):
    out, t = [], 0.0
    for i in range(n):
        out.append({"w": "money" if i % 17 == 5 else "word", "s": round(t, 3), "e": round(t + 0.3, 3)})
        t += 0.3 + (gap if i in gap_at else 0.04)
    return out


def test_pauses_cut_and_grid():
    ws = _words()
    end = ws[-1]["e"] + 0.2
    rng = D.keep_ranges(ws, 0.0, end, 0.4)
    assert len(rng) == 2 and rng[0][1] < ws[21]["s"] - 0.1  # the 1.2 s pause is gone
    segs = D.snap(rng, 0.0)
    assert all(abs(a * 30 - round(a * 30)) < 5e-3 and abs(b * 30 - round(b * 30)) < 5e-3 for a, b in segs)
    assert abs(D.tmap(segs, segs[1][0]) - (segs[0][1] - segs[0][0])) < 1e-6  # time after the cut maps to just after the first range


def test_no_cuts_for_sparse_speech():
    assert D.keep_ranges(_words(6), 0.0, 30.0, 0.4) == [(0.0, 30.0)]


def test_text_score_prefers_hooks_over_fluff():
    good = D.text_score("Nobody tells you the truth about money, but you lose 50 percent of it in fees.")
    bad = D.text_score("so yeah um welcome back and subscribe, use code SAVE at checkout")
    assert good >= 0.5 > bad


def test_sfx_and_bed(tmp_path):
    from clipper import sfxsynth as S
    ev = [{"t": 0.5, "kind": k} for k in S.SFX_LEN]
    ev = [{**e, "t": 0.5 + 1.2 * i} for i, e in enumerate(ev)]
    p = S.bed(tmp_path / "b.wav", 10.0, [{"w": "a", "s": 1, "e": 2}], "chill", -22, ev)
    assert probe(str(p))["duration"] == pytest.approx(10.0, abs=0.05)
    assert all(np.isfinite(S.sfx(k)).all() for k in S.SFX_LEN) and all(np.isfinite(S.music(m, 3)).all() for m in S.MOODS)


@pytest.mark.parametrize("layout,edit", [("fill", "viral"), ("split", "podcast"), ("fit", "hype")])
def test_render_synthetic(tmp_path, layout, edit):
    src = tmp_path / "s.mp4"
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=s=1280x720:r=25:d=14", "-f", "lavfi", "-i", "sine=f=220:d=14",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(src)], check=True)
    ws = _words(70, gap_at=(20, 45), gap=0.9)
    ws = [w for w in ws if w["e"] < 13.5]
    clip = {"id": 1, "final_start": 0.5, "final_end": 13.0, "layout": layout, "focus_x": 0.5, "title": "A test headline", "caption": {"style": None, "scale": 1.0}, "split_auto": [0.3, 0.7]}
    info = probe(str(src))
    f = R.render_clip(str(src), clip, tmp_path / "r", ws, info, opts={"style": "auto", "edit": "auto", "profile": "podcast", "src_fp": "t", "edit_opts": {"style": edit}})
    out = probe(str(f))
    assert (out["width"], out["height"]) == (1080, 1920) and out["audio"]
    assert out["duration"] == pytest.approx(clip["out_dur"], abs=0.15) and clip["out_dur"] < 12.5  # pauses were removed
    assert not R.qc(str(f), clip)[0]
