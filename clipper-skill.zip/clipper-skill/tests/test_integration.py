"""Integration + end-to-end tests on real ffmpeg with synthetic media. No network, no models (stand-ins where a model would run)."""
import json, os, subprocess, sys, time
from pathlib import Path
import pytest
from clipper import captions, critics as C, flow, job as J, layouts, render as R, signals as S, transcribe as T, util
from clipper.util import probe
from tests import synth
from tests.synth import words

SCRIPT = ["Okay so here is the thing everybody keeps getting wrong about this.",       # 0   A speaker
          "I genuinely thought we were going to lose the whole game tonight.",           # 1
          "But nobody expected that to happen at all.",                                  # 2
          "And that is when I realized he was actually the one helping us all along.",   # 3
          "Why did nobody see that coming?",                                             # question (speaker B answers after a pause)
          ("Because the coach never trained them for it at all and everyone knew.", 0.5),
          "Wow.",                                                                        # reaction
          ("That was honestly the funniest thing I have ever seen in my life.", 2.0)]


@pytest.fixture(scope="module")
def spoken(tmp_path_factory, ff):
    d = tmp_path_factory.mktemp("spoken")
    ws = words(SCRIPT, t=2.0, pause=0.6)
    end = ws[-1]["e"] + 1
    v = synth.make_video(d / "s.mp4", dur=int(end) + 20, a_windows=[(2, end)], cuts=[25])
    (d / "w.json").write_text(json.dumps({"words": ws}))
    return d, v, ws


# --------------------------------------------------------------------------- rendering ---------------------------------------------------------
def test_render_produces_exact_spec_with_captions_and_passes_qc(spoken, tmp_path, ff):
    d, v, ws = spoken
    info = probe(v)
    clip = {"id": 1, "final_start": 2.0, "final_end": 14.0, "caption": {"style": None, "scale": 1.0}, "layout": "fill", "focus_auto": [[[0, .5]]], "split_auto": None}
    out = R.render_clip(v, clip, tmp_path, ws, info, opts={"style": "gaming_bold", "src_fp": "x", "quality": {"preset": "ultrafast", "crf": 23}})
    issues, i, warns = R.qc(out, clip)
    assert not issues, issues
    assert (i["width"], i["height"]) == (1080, 1920) and i["audio"] and abs(i["duration"] - 12.0) < 0.3
    assert clip["captions_n"] > 3 and clip["captions_overflow"] == 0 and (tmp_path / "fonts" / "Anton-Regular.ttf").exists()


def test_cache_key_follows_style_source_and_options(spoken, tmp_path, ff):
    d, v, ws = spoken
    info = probe(v)
    base = {"id": 1, "final_start": 2.0, "final_end": 8.0, "caption": {"style": None, "scale": 1.0}, "layout": "fill", "focus_auto": [[[0, .5]]], "split_auto": None}
    q = {"preset": "ultrafast", "crf": 28}
    a = R.render_clip(v, dict(base), tmp_path, ws, info, opts={"style": "bold_pop", "src_fp": "A", "quality": q})
    assert R.render_clip(v, dict(base), tmp_path, ws, info, opts={"style": "bold_pop", "src_fp": "A", "quality": q}) == a  # identical -> reused
    t0 = a.stat().st_mtime_ns
    b = R.render_clip(v, dict(base), tmp_path, ws, info, opts={"style": "karaoke", "src_fp": "A", "quality": q})
    assert b != a and not a.exists(), "a different style must re-render (and the stale file is removed)"
    c = R.render_clip(v, dict(base), tmp_path, ws, info, opts={"style": "karaoke", "src_fp": "OTHER-SOURCE", "quality": q})
    assert c != b, "the same clip spec from a different source must never reuse a render"


def test_missing_fonts_dir_and_hardware_encoder_failures_never_break_a_render(spoken, tmp_path, ff, monkeypatch):
    d, v, ws = spoken
    clip = {"id": 2, "final_start": 2.0, "final_end": 7.0, "caption": {"style": "cinematic", "scale": 1.0}, "layout": "fill", "focus_auto": [[[0, .5]]], "split_auto": None}
    monkeypatch.setattr(R, "_ENC", ["h264_nvenc"])  # pretend nvenc was chosen, but this machine has no NVIDIA GPU: the render must fall back
    out = R.render_clip(v, clip, tmp_path, ws, probe(v), opts={"quality": {"preset": "ultrafast", "crf": 28}, "src_fp": "z"})
    assert not R.qc(out, clip)[0] and "hardware encoder h264_nvenc" in util.skipped()


def test_qc_detects_real_defects(tmp_path, ff):
    bad = synth.make_video(tmp_path / "b.mp4", dur=6, size="640x360", audio=False)
    issues, _, _ = R.qc(bad, {"final_start": 0, "final_end": 6})
    assert "bad_size:640x360" in issues and "no_audio" in issues
    short = synth.make_video(tmp_path / "s.mp4", dur=3, size="1080x1920", beeps=[0.2])
    assert any(i.startswith("duration_off") for i in R.qc(short, {"final_start": 0, "final_end": 10})[0])
    black = tmp_path / "k.mp4"
    subprocess.run([ff, "-y", "-v", "error", "-f", "lavfi", "-i", "color=c=black:s=1080x1920:d=3", "-f", "lavfi", "-i", "sine=f=300:d=3", "-c:v", "libx264", "-c:a", "aac", "-pix_fmt", "yuv420p", str(black)], check=True)
    iss, _, warns = R.qc(black, {"final_start": 0, "final_end": 3})
    assert "black_frames" in iss and "frozen_picture" not in iss  # 3 s < freeze window; black is the failure
    trunc = tmp_path / "t.mp4"
    trunc.write_bytes(Path(short).read_bytes()[: len(Path(short).read_bytes()) // 2])
    assert "decode_error" in R.qc(trunc, {"final_start": 0, "final_end": 3})[0] or probe(trunc)["duration"] == 0


def test_logo_music_and_intro_outro_render(spoken, tmp_path, ff):
    d, v, ws = spoken
    logo = tmp_path / "logo.png"
    subprocess.run([ff, "-y", "-v", "error", "-f", "lavfi", "-i", "color=c=red:s=200x100", "-frames:v", "1", str(logo)], check=True)
    music = tmp_path / "m.wav"
    subprocess.run([ff, "-y", "-v", "error", "-f", "lavfi", "-i", "sine=f=500:d=5", str(music)], check=True)
    intro = synth.make_video(tmp_path / "intro.mp4", dur=1, size="640x360", audio=False)
    clip = {"id": 3, "final_start": 2.0, "final_end": 7.0, "caption": {"style": "boxed", "scale": 1.0}, "layout": "fill", "focus_auto": [[[0, .5]]], "split_auto": None,
            "music": {"file": str(music), "db": -22}, "audio": "clean"}
    out = R.render_clip(v, clip, tmp_path, ws, probe(v), opts={"logo": str(logo), "fade": True, "intro": str(intro), "quality": {"preset": "ultrafast", "crf": 28}, "src_fp": "m"})
    i = probe(out)
    assert abs(i["duration"] - 6.0) < 0.5 and (i["width"], i["height"]) == (1080, 1920) and i["audio"]


def test_styles_preview_command_renders_every_preset(tmp_path, ff, monkeypatch):
    from clipper import cli
    out = tmp_path / "sheet.png"
    cli.main(["styles", "--preview", str(out)])
    assert out.exists() and out.stat().st_size > 5000


# ------------------------------------------------------------------- transcription (stand-in model) ---------------------------------------------
class FakeSeg:
    def __init__(self, words): self.words = words


class FakeWord:
    def __init__(self, w, s, e): self.word, self.start, self.end, self.probability = f" {w}", s, e, 0.9


class FakeModel:
    calls = []

    def transcribe(self, wav, word_timestamps, vad_filter, language):
        FakeModel.calls.append(wav)
        return [FakeSeg([FakeWord("hello", 1.0, 1.4), FakeWord("there", 1.5, 1.9), FakeWord("edge", 1195.0, 1195.4), FakeWord("overlap", 1205.0, 1205.4)])], None


def test_chunked_transcription_offsets_dedupes_overlap_and_resumes(spoken, tmp_path, monkeypatch, ff):
    d, v, ws = spoken
    FakeModel.calls.clear()
    monkeypatch.setattr(T, "_model", lambda profile: FakeModel())
    monkeypatch.setattr(T, "CHUNK", 10)
    monkeypatch.setattr(T, "OVERLAP", 2)
    out = T.transcribe(v, 25, tmp_path / "wc", "light")
    assert len(FakeModel.calls) == 3 and out and all(w["s"] <= w["e"] for w in out)
    starts = [w["s"] for w in out]
    assert starts == sorted(starts), "chunks must be stitched in time order"
    n = len(FakeModel.calls)
    T.transcribe(v, 25, tmp_path / "wc", "light")
    assert len(FakeModel.calls) == n, "finished chunks are cached: a re-run (crash recovery) transcribes nothing"


# --------------------------------------------------------------------------- end to end ----------------------------------------------------------
def test_e2e_complete_sentence_boundaries_delayed_answer_and_reaction(spoken, tmp_path, ff):
    d, v, ws = spoken
    j = J.create(str(v), tmp_path / "jobs", clips=2, transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    J.run(j, "qc", log=lambda *_: None)
    plan, rep = util.jload(j.p("plan.json")), util.jload(j.p("report.json"))
    assert plan["clips"] and rep["clips"] and all(c["pass"] for c in rep["clips"]), rep["clips"]
    top = plan["clips"][0]
    assert top["text"].rstrip()[-1] in ".?!", top["text"]
    assert not {"starts_mid_sentence", "ends_mid_sentence", "truncates_word"} & set(top["issues"])
    for c in rep["clips"]:
        i = probe(c["file"])
        assert (i["width"], i["height"]) == (1080, 1920) and i["audio"]
    assert "judging" in rep["run"] and "run_id" in rep["run"]


def test_e2e_visual_only_highlight_found_without_any_speech(tmp_path, ff):
    v = synth.make_video(tmp_path / "g.mp4", dur=90, beeps=[50], cuts=[30], flash=(50, 53))
    j = J.create(str(v), tmp_path / "jobs", clips=3, profile="gaming", speakers="off", transcript=str(tmp_path / "none.json"), quality="draft")
    (tmp_path / "none.json").write_text(json.dumps({"words": []}))
    J.run(j, "qc", log=lambda *_: None)
    plan = util.jload(j.p("plan.json"))
    assert plan["clips"] and plan["clips"][0].get("kind") == "event"
    assert any(c["final_start"] <= 53 and c["final_end"] >= 50 for c in plan["clips"]), [(c["final_start"], c["final_end"]) for c in plan["clips"]]
    rep = util.jload(j.p("report.json"))
    assert rep["clips"] and all(c["file"] for c in rep["clips"])


def test_e2e_cache_reuse_and_targeted_invalidation_on_a_real_run(spoken, tmp_path, ff):
    d, v, ws = spoken
    kw = dict(transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    j = J.create(str(v), tmp_path / "jobs", clips=2, **kw)
    J.run(j, "qc", log=lambda *_: None)
    t_tr = (j.p("transcript.json")).stat().st_mtime_ns
    r1 = {c["id"]: c["file"] for c in util.jload(j.p("report.json"))["clips"]}
    assert J.run(J.create(str(v), tmp_path / "jobs", clips=2, **kw), "qc", log=lambda *_: None) is None  # complete: nothing re-runs
    j2 = J.create(str(v), tmp_path / "jobs", clips=2, style="karaoke", **kw)
    J.run(j2, "qc", log=lambda *_: None)
    assert j2.p("transcript.json").stat().st_mtime_ns == t_tr, "changing caption style must not touch transcription"
    r2 = {c["id"]: c["file"] for c in util.jload(j2.p("report.json"))["clips"]}
    assert all(r1[k] != r2[k] for k in r2), "but every render must have been redone with the new style"
    J.create(str(v), tmp_path / "jobs", clips=1, **kw)
    assert not j.done("select") and j.done("transcribe") and j.done("signals")


def test_e2e_edit_rerenders_only_that_clip_and_critic_polish_fixes_a_bad_open(spoken, tmp_path, ff):
    d, v, ws = spoken
    j = J.create(str(v), tmp_path / "jobs", clips=2, transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    J.run(j, "qc", log=lambda *_: None)
    ids = [c["id"] for c in util.jload(j.p("plan.json"))["clips"]]
    stamp = {c["id"]: Path(c["file"]).stat().st_mtime_ns for c in util.jload(j.p("report.json"))["clips"]}
    J.edit_clip(j, ids[0], {"captions": "karaoke"})
    J.run(j, "qc", log=lambda *_: None)
    now = {c["id"]: Path(c["file"]).stat().st_mtime_ns for c in util.jload(j.p("report.json"))["clips"]}
    assert now[ids[0]] != stamp[ids[0]] and all(now[i] == stamp[i] for i in ids[1:])
    summary = flow.polish(j, log=lambda *_: None)
    assert summary and all(v["overall"] is not None for v in summary.values())


def test_e2e_oneshot_run_exports_only_passing_clips_with_an_honest_report(spoken, tmp_path, ff):
    d, v, ws = spoken
    jj, fr = flow.run_video(str(v), tmp_path / "jobs", judge=False, clips=2, export_dir=tmp_path / "out", log=lambda *_: None, transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    meta = json.loads((tmp_path / "out" / "metadata.json").read_text())
    assert meta["clips"], meta
    assert all((tmp_path / "out" / m["file"]).exists() for m in meta["clips"])
    run = meta["run"]
    assert run["judging"]["judged"] == 0 and "features_skipped" in run and "local_models" in run
    assert all("unassessed" in v for v in meta["verdicts"]["verdicts"].values()) and "emotion" in next(iter(meta["verdicts"]["verdicts"].values()))["unassessed"]  # eyes not used: stated, not hidden


def test_e2e_missing_optional_models_degrade_without_failing(spoken, tmp_path, ff, monkeypatch):
    monkeypatch.setenv("CLIPPER_OFFLINE", "1")
    from clipper import models
    monkeypatch.setattr(models, "CACHE", tmp_path / "nomodels")
    d, v, ws = spoken
    j = J.create(str(v), tmp_path / "jobs", clips=1, transcript=str(d / "w.json"), profile="podcast", quality="draft")  # speakers=auto: needs models that are not there
    J.run(j, "qc", log=lambda *_: None)
    rep = util.jload(j.p("report.json"))
    assert rep["clips"] and all(c["pass"] for c in rep["clips"])
    assert rep["run"]["features_skipped"], "the report must say what was skipped"


def test_live_chat_alignment_helpers_and_merge(tmp_path):
    from clipper import live
    ev = live.merge_events([{"pts": 300, "kind": "chat", "x": 9}, {"pts": 340, "kind": "audio"}, {"pts": 900, "kind": "chat"}])
    assert len(ev) == 2 and ev[0]["kinds"] == ["audio", "chat"] and ev[0]["confidence"] > ev[1]["confidence"]
    s = live.Session(tmp_path)
    s.set("recording", parts=["record_000.ts"])
    s2 = live.Session(tmp_path)
    assert s2.d["state"] == "recording" and s2.d["parts"] == ["record_000.ts"]  # a restarted process sees the persisted state
    with pytest.raises(AssertionError):
        s.set("not-a-state")
    assert live.parse_chat_line('{"u":"a","m":"x","ts":5}') == (5.0, "a", "x") and live.parse_chat_line("nope") is None


def test_live_extraction_is_frame_accurate(spoken, tmp_path, ff):
    from clipper import live
    d, v, ws = spoken
    seg = tmp_path / "buf"
    seg.mkdir()
    subprocess.run([ff, "-y", "-v", "error", "-i", v, "-t", "40", "-c:v", "libx264", "-preset", "ultrafast", "-g", "100", "-c:a", "aac", "-f", "segment", "-segment_time", "4", "-segment_format", "mpegts", str(seg / "seg_%06d.ts")], check=True)
    names = sorted(p.name for p in seg.glob("seg_*.ts"))
    f = live.extract(seg, names, 2, 7, 10.7, 25.3, tmp_path / "pre.mkv")
    assert f and abs(probe(f)["duration"] - 14.6) < 0.25, probe(f)  # re-encoded: not off by a GOP (stream copy would be ~keyframe-snapped)


def test_event_only_highlight_survives_the_critics_and_polish_and_is_exported(tmp_path, ff):
    """Regression: the critics demanded speech, 'no_speech' dropped the only (visual/audio) highlight, and the one-shot run exported 0 clips."""
    v = synth.make_video(tmp_path / "e.mp4", dur=60, a_windows=[(0, 60)], beeps=[30, 31, 32], cuts=[15, 29, 34])  # busy picture + a loud 3 s reaction burst, no speech
    (tmp_path / "w.json").write_text(json.dumps({"words": []}))
    j, fr = flow.run_video(str(v), tmp_path / "jobs", judge=False, clips=2, export_dir=tmp_path / "out", log=lambda *_: None, transcript=str(tmp_path / "w.json"), profile="gaming", speakers="off", quality="draft")
    meta = json.loads((tmp_path / "out" / "metadata.json").read_text())
    assert meta["clips"], "an event-only highlight must be exported"
    assert not any(c.get("dropped") for c in util.jload(j.p("plan.json"))["clips"][:1])
    assert all(f["code"] != "no_speech" for r in C.load_reports(j).values() for cl in r["clips"].values() for f in cl["findings"])


# --------------------------------------------------------------------------- layouts + caption presets -----------------------------------------
@pytest.mark.parametrize("layout", list(layouts.LAYOUTS))
def test_every_layout_renders_to_spec_with_hook_and_progress(spoken, tmp_path, ff, layout):
    d, v, ws = spoken
    clip = {"id": 1, "final_start": 2.0, "final_end": 6.0, "caption": {"style": "hormozi", "scale": 1.0}, "layout": layout, "focus_auto": [[[0, .5]]], "split_auto": None,
            "regions": {"cam": [0, .5, .3, .5], "cam2": [.7, .5, .3, .5], "ui": [.7, 0, .3, .3]}, "filler": str(v), "swap": layout in ("basecam", "filler"),
            "headline": "why this works", "progress": True, "title": "t"}
    out = R.render_clip(v, clip, tmp_path, ws, probe(v), opts={"quality": {"preset": "ultrafast", "crf": 30}, "src_fp": "x"})
    assert not [i for i in R.qc(out, clip)[0] if not i.startswith("black")], R.qc(out, clip)[0]
    assert (probe(out)["width"], probe(out)["height"]) == (1080, 1920)


def test_layout_without_its_boxes_falls_back_to_fit_and_bad_boxes_are_rejected(spoken, tmp_path, ff):
    d, v, ws = spoken
    clip = {"id": 1, "final_start": 2.0, "final_end": 4.0, "caption": {"style": "none", "scale": 1.0}, "layout": "circle_facecam", "focus_auto": [[[0, .5]]], "split_auto": None}
    out = R.render_clip(v, clip, tmp_path, ws, probe(v), opts={"quality": {"preset": "ultrafast", "crf": 30}, "src_fp": "x"})
    assert probe(out)["height"] == 1920
    for bad in ("0.5,0.5,0.6,0.2", "1,2,3", "a,b,c,d", "0,0,0,1"):
        with pytest.raises(ValueError):
            layouts.parse_box(bad)


@pytest.mark.parametrize("name", sorted(captions.PRESETS) + sorted(captions.ALIASES))
def test_every_caption_preset_builds_without_overflow(name):
    ws = [{"w": w, "s": i * .4, "e": i * .4 + .35} for i, w in enumerate("this changed everything for me and unbelievable results".split())]
    st = captions.style(name)
    txt = captions.build(ws, 0, st, hook="why this works", progress=4)
    assert txt.count("\nDialogue:") >= len(ws) // 4 and captions.overflow(ws, st) == 0


# --------------------------------------------------------------------------- judging, captions, layouts end to end ---------------------------------------
@pytest.fixture
def cli_root(tmp_path, monkeypatch):
    from clipper import cli
    monkeypatch.setattr(cli, "ROOT", str(tmp_path / "jobs"))
    return cli


def run_cli(cli, *argv, capsys=None):
    cli.main(list(argv))
    return capsys.readouterr().out if capsys else ""


def test_e2e_the_model_judges_then_exports_with_its_scores_titles_and_hooks(spoken, tmp_path, ff, cli_root, capsys):
    d, v, ws = spoken
    jj, fr = flow.run_video(str(v), tmp_path / "jobs", clips=2, export_dir=tmp_path / "out", log=lambda *_: None, transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    assert fr["state"] == "awaiting_judge" and not (tmp_path / "out").exists(), "must pause for the model BEFORE rendering"
    run_cli(cli_root, "judge", jj.id, capsys=capsys)
    pk = json.loads((jj.p("judge", "packet.json")).read_text())
    assert pk["candidates"] and "[" in pk["candidates"][0]["text"] and set(pk["rubric"]) >= {"hook", "payoff", "emotion", "value", "shareability", "standalone"}
    k0, k1 = pk["candidates"][0]["key"], pk["candidates"][-1]["key"]
    sub = {"results": [{"key": k0, "hook": 9, "payoff": 9, "emotion": 8, "value": 7, "shareability": 8, "standalone": True, "title": "The model's title", "hook_text": "Wait for it", "reason": "r"},
                       {"key": "zzzzzzzz", "hook": 1, "payoff": 1, "emotion": 1, "value": 1, "shareability": 1}]}
    f = tmp_path / "sub.json"
    f.write_text(json.dumps(sub))
    out = run_cli(cli_root, "judge", jj.id, "--submit", str(f), capsys=capsys)
    assert "REJECTED" in out and "accepted 1/" in out
    assert jj.p("plan.json").exists() and util.jload(jj.p("plan.json"))["judging"]["judged"] == 1, "a submission re-selects immediately so captions/layouts can be reviewed"
    fr = flow.finish(jj, tmp_path / "out", True, log=lambda *_: None)[1]
    meta = json.loads((tmp_path / "out" / "metadata.json").read_text())
    plan = util.jload(jj.p("plan.json"))
    assert plan["judging"]["judged"] == 1 and any(c.get("judge") and c["title"] == "The model's title" for c in plan["clips"])
    assert meta["clips"] and all((tmp_path / "out" / m["file"]).exists() for m in meta["clips"]), (meta["not_exported"], util.jload(jj.p("render.json"))["errors"])


def test_e2e_caption_edits_emphasis_and_emoji_render_and_change_the_picture(spoken, tmp_path, ff):
    d, v, ws = spoken
    info = probe(v)
    base = {"id": 1, "final_start": 2.0, "final_end": 9.0, "layout": "fill", "focus_auto": [[[0, .5]]], "split_auto": None}
    q = {"preset": "ultrafast", "crf": 28}
    plain = R.render_clip(v, {**base, "caption": {"style": "hormozi", "scale": 1.0, "emoji": False, "emphasis": False}}, tmp_path / "a", ws, info, opts={"quality": q, "src_fp": "x"})
    rich_clip = {**base, "caption": {"style": "hormozi", "scale": 1.0, "emoji": True, "edits": {"emoji": [{"word": next(i for i, w in enumerate(ws) if w["s"] >= 3.0), "emoji": "fire", "dur": 2.0}], "text": {}}}}
    rich = R.render_clip(v, rich_clip, tmp_path / "b", ws, info, opts={"quality": q, "src_fp": "x"})
    assert not R.qc(rich, rich_clip)[0], R.qc(rich, rich_clip)
    crop = lambda p: subprocess.run([ff, "-v", "error", "-ss", "1.8", "-i", str(p), "-frames:v", "1", "-vf", "crop=300:300:390:1000,format=gray", "-f", "rawvideo", "-"], capture_output=True).stdout
    assert crop(plain) != crop(rich), "the emoji must actually be drawn above the captions"


def test_e2e_layout_proposal_preview_then_user_approval_then_render(spoken, tmp_path, ff, cli_root, capsys, monkeypatch):
    d, v, ws = spoken
    j = J.create(str(v), tmp_path / "jobs", clips=1, transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    J.run(j, "select", log=lambda *_: None)
    out = json.loads(run_cli(cli_root, "layout", j.id, "1", capsys=capsys))
    assert Path(out["grid_frame"]).is_file() and out["recommended_by_local_rules"] and "split" in out["layouts"]
    with pytest.raises(SystemExit):
        cli_root.main(["edit", j.id, "1", "--layout", "split"])
    with pytest.raises(SystemExit):
        cli_root.main(["layout", j.id, "1", "--propose", "split", "--reason", "x"])  # needs the cam box
    out = json.loads(run_cli(cli_root, "layout", j.id, "1", "--propose", "split", "--cam", "0.0,0.5,0.3,0.5", "--reason", "cam bottom-left", capsys=capsys))
    assert Path(out["preview"]).is_file() and "SHOW the user" in out["NEXT"]
    assert util.jload(j.p("plan.json"))["clips"][0]["layout"] != "split"
    run_cli(cli_root, "layout", j.id, "1", "--approve", capsys=capsys)
    assert util.jload(j.p("plan.json"))["clips"][0]["layout"] == "split"
    J.run(j, "qc", log=lambda *_: None)
    rep = util.jload(j.p("report.json"))
    assert rep["clips"] and rep["clips"][0]["pass"], rep["clips"]


def test_e2e_fast_mode_transcribes_only_the_windows_the_cheap_signals_choose(tmp_path, ff, monkeypatch):
    from clipper import transcribe as T
    v = synth.make_video(tmp_path / "long.mp4", dur=120, a_windows=[(0, 120)], beeps=[40, 41, 42, 90, 91], cuts=[40])
    asked = []

    def fake(mp, src, a, length, wav, language):
        asked.append((a, a + length))
        return [{"w": "hello", "s": a + 1, "e": a + 1.3, "p": 1.0}], "en"
    monkeypatch.setattr(T, "_model", lambda profile: (None, None))
    monkeypatch.setattr(T, "_chunk", fake)
    monkeypatch.setattr(J, "FAST_MIN_S", 60)
    j = J.create(str(v), tmp_path / "jobs", clips=1, fast=True, profile="gaming", speakers="off", quality="draft")
    J.run(j, "transcribe", log=lambda *_: None)
    assert asked and sum(b - a for a, b in asked) < 120 and all(a >= 0 and b <= 120 for a, b in asked)
    assert any(a <= 41 <= b for a, b in asked) or any(a <= 90 <= b for a, b in asked), "the loud moments must be inside a transcribed window"


def test_parallel_rendering_produces_every_clip_and_survives_the_shared_font_install(spoken, tmp_path, ff, monkeypatch):
    d, v, ws = spoken
    monkeypatch.setenv("CLIPPER_RENDER_WORKERS", "3")
    j = J.create(str(v), tmp_path / "jobs", clips=1, transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    J.run(j, "select", log=lambda *_: None)
    plan = util.jload(j.p("plan.json"))
    c0 = plan["clips"][0]
    plan["clips"] = [{**c0, "id": k + 1, "caption": {"style": ["hormozi", "mrbeast", "neon", "fire"][k], "scale": 1.0}} for k in range(4)]
    util.jsave(j.p("plan.json"), plan)
    j.invalidate("render")
    J.run(j, "qc", log=lambda *_: None)
    ren, rep = util.jload(j.p("render.json")), util.jload(j.p("report.json"))
    assert not ren["errors"] and len(ren["files"]) == 4 and all(c["pass"] for c in rep["clips"]), (ren["errors"], rep["clips"])


def test_edits_and_approved_layouts_survive_a_re_judging(spoken, tmp_path, ff):
    from clipper import judge
    d, v, ws = spoken
    j = J.create(str(v), tmp_path / "jobs", clips=2, transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    J.run(j, "select", log=lambda *_: None)
    c = util.jload(j.p("plan.json"))["clips"][0]
    J.edit_clip(j, 1, {"captions": "mrbeast", "caption_edits": {"emphasis": [c["final_words"][0]]}})
    J.edit_clip(j, 1, {"layout_proposal": {"layout": "fit"}})
    J.edit_clip(j, 1, {"layout_approve": True})
    J.edit_clip(j, 1, {"hook": "auto", "progress": True})
    util.jsave(j.p("judgments.json"), {c["key"]: {"key": c["key"], "hook": 9, "payoff": 9, "emotion": 9, "value": 9, "shareability": 9, "standalone": True, "title": "Judged", "hook_text": "Wait for it"}})
    j.invalidate("select")
    J.run(j, "select", log=lambda *_: None)
    new = next(x for x in util.jload(j.p("plan.json"))["clips"] if x["key"] == c["key"])
    assert new["caption"]["style"] == "mrbeast" and new["caption"]["edits"]["emphasis"] == [c["final_words"][0]] and new["layout"] == "fit"
    assert new["headline"] == "auto" and new["hook"] == c["hook"] and new["progress"] is True and new["hook_text"] == "Wait for it" and new["title"] == "Judged"


def test_headline_option_never_overwrites_the_local_hook_score_the_critics_read(spoken, tmp_path, ff):
    """Regression (found by running the real CLI): `edit --hook` stored its text in clip['hook'], the numeric local hook score, and crashed the critics."""
    d, v, ws = spoken
    j = J.create(str(v), tmp_path / "jobs", clips=1, transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    J.run(j, "qc", log=lambda *_: None)
    J.edit_clip(j, 1, {"hook": "auto", "progress": True})
    c = util.jload(j.p("plan.json"))["clips"][0]
    assert isinstance(c["hook"], (int, float)) and c["headline"] == "auto"
    flow.polish(j, log=lambda *_: None)  # runs every critic over the edited clip
    assert util.jload(j.p("report.json"))["clips"][0]["pass"]


def _mad(a, b):
    return sum(abs(x - y) for x, y in zip(a, b)) / max(1, min(len(a), len(b)))


def _px(ff, p, t, crop):
    return subprocess.run([ff, "-v", "error", "-ss", str(t), "-i", str(p), "-frames:v", "1", "-vf", f"crop={crop},format=gray", "-f", "rawvideo", "-"], capture_output=True).stdout


def test_story_card_renders_a_white_card_with_the_text_and_story_filler_loops_the_filler(spoken, tmp_path, ff):
    d, v, ws = spoken
    info, q = probe(v), {"preset": "ultrafast", "crf": 28}
    base = {"id": 1, "final_start": 2.0, "final_end": 8.0, "caption": {"style": "none", "scale": 1.0}, "focus_auto": [[[0, .5]]], "split_auto": None, "pair_auto": None}
    for layout, extra in (("story_card", {}), ("story_filler", {"filler": str(v)})):
        clip = {**base, "layout": layout, "card": "My roommate used my name for three years", **extra}
        out = R.render_clip(v, clip, tmp_path / layout, ws, info, opts={"quality": q, "src_fp": "x"})
        assert not R.qc(out, clip)[0], (layout, R.qc(out, clip))
        white = subprocess.run([ff, "-v", "error", "-ss", "1", "-i", str(out), "-frames:v", "1", "-vf", "crop=900:420:90:80,format=gray,signalstats,metadata=print:key=lavfi.signalstats.YAVG:file=-", "-f", "null", "-"],
                               capture_output=True, text=True).stdout
        assert float(white.split("YAVG=")[1].split()[0]) > 150, f"{layout}: the card should be mostly white"
    no_text = {**base, "layout": "story_card", "title": ""}
    out = R.render_clip(v, no_text, tmp_path / "nt", ws, info, opts={"quality": q, "src_fp": "x"})
    assert out.exists(), "no card text: falls back to fit instead of failing"


def test_speaker_pip_shows_a_round_window_of_the_other_person_and_falls_back_without_a_pair(spoken, tmp_path, ff):
    d, v, ws = spoken
    info, q = probe(v), {"preset": "ultrafast", "crf": 28}
    base = {"id": 1, "final_start": 2.0, "final_end": 8.0, "caption": {"style": "none", "scale": 1.0}, "focus_auto": [[[0, .3], [3.0, .7]]], "split_auto": None}
    plain = R.render_clip(v, {**base, "layout": "fill", "pair_auto": None}, tmp_path / "a", ws, info, opts={"quality": q, "src_fp": "x"})
    clip = {**base, "layout": "speaker_pip", "pair_auto": [0.3, 0.7]}
    pip = R.render_clip(v, clip, tmp_path / "b", ws, info, opts={"quality": q, "src_fp": "x"})
    assert not R.qc(pip, clip)[0]
    win = "300:300:700:150"  # top-right window (1080x1920 frame)
    assert _mad(_px(ff, plain, 1.0, win), _px(ff, pip, 1.0, win)) > 8, "the other person's window must be drawn"
    assert _mad(_px(ff, plain, 1.0, "300:300:40:900"), _px(ff, pip, 1.0, "300:300:40:900")) < 3, "the rest of the picture is the same speaker-following crop"
    one = {**base, "layout": "speaker_pip", "pair_auto": None}
    out = R.render_clip(v, one, tmp_path / "c", ws, info, opts={"quality": q, "src_fp": "x"})
    assert _mad(_px(ff, out, 1.0, win), _px(ff, plain, 1.0, win)) < 3, "one person only: plain fill"


def test_auto_style_is_the_default_and_the_result_is_what_gets_rendered(spoken, tmp_path, ff):
    d, v, ws = spoken
    info = probe(v)
    clip = {"id": 1, "final_start": 2.0, "final_end": 6.0, "caption": {"style": None, "scale": 1.0}, "layout": "fill", "focus_auto": [[[0, .5]]], "split_auto": None, "pair_auto": None,
            "judge": {"hook_type": "statistic", "emotion": 5}}
    q = {"preset": "ultrafast", "crf": 28}
    a = R.render_clip(v, clip, tmp_path / "a", ws, info, opts={"quality": q, "src_fp": "x", "profile": "podcast"})
    b = R.render_clip(v, {**clip, "caption": {"style": "hormozi", "scale": 1.0}}, tmp_path / "b", ws, info, opts={"quality": q, "src_fp": "x", "profile": "podcast"})
    assert (tmp_path / "a" / "clip_01.ass").read_text() == (tmp_path / "b" / "clip_01.ass").read_text(), "auto + statistic hook must produce exactly the hormozi captions"
    assert not R.qc(a, clip)[0]


def test_hardware_encoder_options_are_accepted_by_this_ffmpeg(ff):
    """No GPU here, so a hardware encoder can only fail at DEVICE open. What this proves: every option we pass is understood by this ffmpeg build (a typo or a
    removed option would say 'Unrecognized option'). The real GPU run is the one thing this sandbox cannot do."""
    listed = subprocess.run([ff, "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
    checked = 0
    for enc, fn in R.ENC_ARGS.items():
        if enc not in listed:
            continue
        r = subprocess.run([ff, "-hide_banner", "-y", "-f", "lavfi", "-i", "testsrc2=s=320x240:r=10", "-t", "1", "-c:v", enc, *fn({"preset": "medium", "crf": 20}), "-pix_fmt", "yuv420p", "-f", "null", "-"],
                           capture_output=True, text=True)
        assert not any(x in r.stderr for x in ("Unrecognized option", "Option not found", "Error setting option")), (enc, r.stderr[-400:])
        checked += 1
    assert checked >= 1


def test_default_style_auto_survives_the_whole_one_shot_run_including_the_critics(spoken, tmp_path, ff):
    """Regression (found by the 2-hour run): style defaulted to 'auto' and the editor-critic crashed on the unresolved name."""
    d, v, ws = spoken
    jj, fr = flow.run_video(str(v), tmp_path / "jobs", judge=False, clips=1, export_dir=tmp_path / "out", log=lambda *_: None, transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    assert jj.opts["style"] == "auto" and fr["clips_total"] >= 1 and (tmp_path / "out" / "metadata.json").exists()


def test_frame_strips_are_labelled_with_their_candidate_key(spoken, tmp_path, ff):
    """Regression (real YouTube run): the model opened several strips at once, got them back in a different order, and judged two candidates from each other's pictures."""
    from clipper import extras
    d, v, ws = spoken
    a = extras.frame_strip(v, 2, 8, tmp_path / "a.png")
    b = extras.frame_strip(v, 2, 8, tmp_path / "b.png", label="KEY 2b2abbe4  0-04-29")
    assert a and b
    corner = lambda p: subprocess.run([ff, "-v", "error", "-i", str(p), "-frames:v", "1", "-vf", "crop=300:50:12:12,format=gray", "-f", "rawvideo", "-"], capture_output=True).stdout
    assert corner(a) != corner(b) and sum(corner(b)) / len(corner(b)) < sum(corner(a)) / len(corner(a)) + 255, "the label box must change the corner"
    assert probe(a)["width"] == probe(b)["width"] and probe(b)["height"] == 360


def test_contact_sheets_stack_labelled_strips_in_rank_order(spoken, tmp_path, ff):
    from clipper import extras
    d, v, ws = spoken
    strips = [extras.frame_strip(v, 2 + k, 6 + k, tmp_path / f"s{k}.png", label=f"KEY k{k}") for k in range(7)]
    sheets = extras.contact_sheets(strips + [None, str(tmp_path / "missing.png")], tmp_path, per=5, width=800)
    assert [Path(s).name for s in sheets] == ["sheet_1.png", "sheet_2.png"]
    i1, i2 = probe(sheets[0]), probe(sheets[1])
    assert i1["width"] == 800 and i1["height"] == 5 * i2["height"] / 2 and i2["height"] > 0


def test_judge_reset_forgets_scores_and_carried_over_edits(spoken, tmp_path, ff, cli_root, capsys):
    d, v, ws = spoken
    j = J.create(str(v), tmp_path / "jobs", clips=2, transcript=str(d / "w.json"), profile="podcast", speakers="off", quality="draft")
    J.run(j, "select", log=lambda *_: None)
    c = util.jload(j.p("plan.json"))["clips"][0]
    J.edit_clip(j, 1, {"drop": True})
    util.jsave(j.p("judgments.json"), {c["key"]: {"key": c["key"], "hook": 9, "payoff": 9, "emotion": 9, "value": 9, "shareability": 9, "title": "Old"}})
    j.invalidate("select")
    J.run(j, "select", log=lambda *_: None)
    assert any(x.get("dropped") for x in util.jload(j.p("plan.json"))["clips"]), "a drop survives a re-selection by design"
    run_cli(cli_root, "judge", j.id, "--reset", capsys=capsys)
    plan = util.jload(j.p("plan.json"))
    assert not any(x.get("dropped") for x in plan["clips"]) and plan["judging"]["judged"] == 0 and not j.p("judgments.json").exists() and not j.p("plan.prev.json").exists()


def test_flat_slates_like_ad_breaks_are_not_moments_and_cannot_be_exported(tmp_path, ff):
    """Regression (real Twitch livestream): the streamer went to an ad break, 'Commercial break in progress' was ranked as a highlight and exported as a clip that passed QC."""
    from clipper import signals as S
    slate = tmp_path / "slate.mp4"
    subprocess.run([ff, "-y", "-v", "error", "-f", "lavfi", "-i", "gradients=s=640x360:r=10:d=40:speed=0.01,gblur=sigma=25", "-f", "lavfi", "-i", "sine=f=440:r=16000:d=40", "-t", "40", "-c:v", "libx264",
                    "-preset", "ultrafast", "-c:a", "aac", str(slate)], check=True)
    busy = synth.make_video(tmp_path / "busy.mp4", dur=40, a_windows=[(0, 40)])
    d_slate, d_busy = S.detail_series(str(slate), 40), S.detail_series(str(busy), 40)
    assert max(d_slate) < S.FLAT_T < min(d_busy[2:-2]), (max(d_slate), min(d_busy))
    assert S.flat_share(d_slate, 0, 40) == 1.0 and S.flat_share(d_busy, 0, 40) < 0.1 and S.flat_share([], 0, 5) == 0.0
    assert S.flat_share(d_slate[:10] + d_busy[:30], 0, 40) < S.FLAT_SHARE, "one short fade/calm shot inside a real clip must not count as a slate"
    assert S.visual_pass(str(busy), 40)[3] and len(S.visual_pass(str(busy), 40)[3]) == 41
    clip = {"id": 1, "final_start": 0.0, "final_end": 30.0}
    assert "flat_picture" in R.qc(slate, clip, detail=d_slate)[0]
    assert "flat_picture" not in R.qc(busy, {"id": 1, "final_start": 0.0, "final_end": 40.0}, detail=d_busy)[0]
    assert "flat_picture" not in R.qc(slate, clip)[0], "no source detail given: QC must not guess from the render (a blurred-background layout alone scores ~1.8)"
    v = tmp_path / "mix.mp4"  # 60 s: an ad slate in the middle of real footage
    fl = "".join(f"[{i}:v]scale=640:360,fps=10,setsar=1[v{i}];[{i}:a]aresample=48000,aformat=channel_layouts=stereo[a{i}];" for i in range(3)) + "[v0][a0][v1][a1][v2][a2]concat=n=3:v=1:a=1[v][a]"
    subprocess.run([ff, "-y", "-v", "error", "-i", str(busy), "-i", str(slate), "-i", str(busy), "-filter_complex", fl, "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "aac", str(v)], check=True)
    j = J.create(str(v), tmp_path / "jobs", clips=5, profile="gaming", speakers="off", transcript=str(tmp_path / "w.json"), quality="draft")
    (tmp_path / "w.json").write_text(json.dumps({"words": []}))
    J.run(j, "candidates", log=lambda *_: None)
    cd = util.jload(j.p("candidates.json"))
    assert all(S.flat_share(util.jload(j.p("signals.json"))["detail"], c["final_start"], c["final_end"]) < S.FLAT_SHARE for c in cd["candidates"])
