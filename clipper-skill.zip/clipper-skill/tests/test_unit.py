"""Unit tests: pure logic, no ffmpeg, no models, no network."""
import base64, collections, json, os, random, tarfile, time
from pathlib import Path
import pytest
from clipper import boundaries as B, captions, chat, critics, extras, judge, kick, layouts, models, render as R, score, signals as S, util
from tests.synth import words


# ---------------------------------------------------------------- boundary engine: the hard cases ----------------------------------------
def sent_ranges(ws):
    return B.sentences(ws)


def test_unpunctuated_run_is_split_at_pauses_not_swallowed():
    ws = words([("so this is a very long ramble with no punctuation at all " * 6).strip()], wd=0.4, gap=0.02)
    for i in (20, 45, 70):  # pauses of 0.3 s inside the ramble
        for w in ws[i:]:
            w["s"] += 0.3
            w["e"] += 0.3
    assert max(b - a for a, b in B.sentences(ws)) < len(ws) - 1, "a punctuation-free monologue must not be one sentence"


def test_long_pause_inside_a_sentence_still_ends_on_the_full_thought():
    ws = words(["I really thought we would lose", ("but then it happened and we won.", 1.0), "Amazing."], pause=1.2)  # pause > 0.8 s splits the sentence
    for w in ws[6:]:
        w["s"] += 1.0
        w["e"] += 1.0
    c = B.refine_checked(ws, 0, 5)
    assert c["text"].rstrip().endswith(("won.", "Amazing.")) and "ends_mid_sentence" not in c["issues"]


def test_question_followed_by_delayed_answer_includes_the_answer():
    ws = words(["Why did nobody see that coming?", ("Because the coach never trained them for it at all.", 0.5), "Next topic starts here with other words entirely now."], pause=0.5)
    for w in ws[6:]:
        w["s"] += 3.0
        w["e"] += 3.0  # 3.5 s of silence before the answer
    c = B.refine(ws, 0, 5, min_s=0)
    assert "coach never trained" in c["text"], c["text"]
    assert "Next topic" not in c["text"]


def test_delayed_punchline_with_laughter_tail_is_kept():
    ws = words(["So I asked the barista for the secret ingredient.", ("Honestly just more sugar.", 6.0), "Anyway moving on to something else completely different today."])
    laugh = [0] * 200
    end = ws[[w["w"] for w in ws].index("sugar.")]["e"]
    for t in range(int(end), int(end) + 4):
        laugh[t] = 1
    c = B.refine(ws, 0, 7, min_s=0, reaction=laugh)
    assert c["final_end"] >= int(end) + 3, c  # the audience reaction is not cut off
    assert c["final_end"] < ws[-9]["s"], "but it must not run into the next topic"


def test_interrupting_speakers_with_overlapping_timestamps_do_not_break_boundaries():
    ws = words(["I think the real problem is the budget.", "No wait that is not what happened at all."])
    ws[8]["s"] = ws[7]["e"] - 0.2  # overlap: second speaker starts before the first finishes
    sents = B.sentences(ws)
    c = B.refine_checked(ws, 0, len(ws) - 1)
    assert c["final_start"] >= 0 and c["final_end"] > c["final_start"] and sents


def test_reaction_after_main_statement_is_included():
    ws = words(["He just walked right through the door and won the whole thing outright.", "Wow.", ("Anyway.", 3.0), "Totally different subject starts a long way after this moment."])
    c = B.refine(ws, 0, 12, min_s=0)
    assert c["text"].rstrip().endswith("Wow."), c["text"]


def test_transcript_ending_at_end_of_video_is_safe():
    ws = words(["First sentence of the clip.", "Last sentence of the whole video ends right here."])
    c = B.refine_checked(ws, 3, len(ws) - 1)
    assert c["final_words"][1] == len(ws) - 1 and c["final_end"] >= ws[-1]["e"]
    assert not any(i in c["issues"] for i in ("ends_mid_sentence", "truncates_word"))


def test_dependent_opening_pulls_setup_and_quality_score_reflects_it():
    ws = words(["Everyone said the plan would fail.", "But I did it anyway.", "Three weeks later it worked brilliantly for us."])
    good = B.refine_checked(ws, 6, len(ws) - 1)
    assert good["text"].startswith("Everyone"), good["text"]
    bad = B._pack(ws, 6, 8, 6, 8)
    bad["issues"] = B.validate(ws, bad, min_s=0)
    assert "missing_setup" in bad["issues"] and B.quality(bad["issues"]) < good["boundary_quality"]


def test_sentence_continuing_across_a_scene_cut_is_not_split_by_the_cut():
    ws = words(["The thing that nobody expected was that the whole plan simply worked."])
    c = B.refine_checked(ws, 0, len(ws) - 1)
    cuts = R.shot_cuts(c["final_start"], c["final_end"], [3.0])
    assert c["text"].rstrip().endswith("worked.") and len(cuts) <= 1  # boundaries never depend on cuts; framing handles the cut separately


# ------------------------------------------------------------------ signals / chat -------------------------------------------------------
def test_chat_spike_detected_with_adaptive_baseline_and_no_false_alarm():
    random.seed(1)
    quiet = [15 + random.randint(-3, 3) for _ in range(120)]
    assert S.spikes(quiet) == []
    assert 80 in S.spikes(quiet[:80] + [120] + quiet[81:])


def test_spike_detector_memory_is_bounded():
    d = S.SpikeDetector(window=60)
    for i in range(100000):
        d.feed(i % 7)
    assert len(d.hist) == 60


def test_spam_giveaway_bots_and_single_user_floods_are_filtered_but_crowd_hype_is_kept():
    chat = [{"t": 5.1, "u": f"v{i}", "m": "KEKW"} for i in range(30)]                       # 30 different users: real reaction
    chat += [{"t": 5.2, "u": "bot", "m": "!giveaway enter now"}] * 10                          # command/giveaway spam
    chat += [{"t": 5.3, "u": "spam", "m": "BUY FOLLOWERS http://x.co"}] * 10                   # links
    chat += [{"t": 5.4 + i * 0.01, "u": "flooder", "m": "aaaa"} for i in range(40)]            # one user flooding
    s, info = S.chat_series(chat, 20, with_info=True)
    assert info["kept"] <= 32 and info["spam_dropped"] >= 55, info
    assert s[5] > 25


def test_heatmap_series_and_empty():
    assert S.heat_series(None, 10) == []
    h = S.heat_series([{"start_time": 2, "end_time": 4, "value": 0.9}], 10)
    assert h[3] == 0.9 and h[8] == 0.0


# --------------------------------------------------------------------- scoring ---------------------------------------------------------------
def test_event_only_candidates_without_any_words():
    n = 120
    audio = [10.0] * n
    for t in range(60, 64):
        audio[t] = 80.0
    visual = [0.1] * n
    for t in range(58, 66):
        visual[t] = 2.0
    cs = score.candidates([], n, {"audio": audio, "visual": visual}, "gaming", cuts=[58.0, 66.0])
    assert cs and all(c["kind"] == "event" and c["text"] == "" for c in cs)
    assert any(c["final_start"] <= 64 and c["final_end"] >= 60 for c in cs[:2]), [(c["final_start"], c["final_end"]) for c in cs[:3]]  # the 60-64 s burst is found


def test_auto_profile_and_live_candidates():
    assert score.auto_profile([], 100, {"visual": [2.0] * 100}) == "gaming"
    ws = words(["talk"] * 40)
    assert score.auto_profile(ws, 25, {}) in ("podcast", "irl")
    lc = score.live_candidates(ws, 100, [{"start": 0, "end": 10, "confidence": 1.0, "kinds": ["chat", "audio"]}])
    assert lc and lc[0]["live"] and lc[0]["score"] > 0.7


def test_duplicate_overlaps_are_merged_keeping_the_better_clip():
    a = {"final_start": 10, "final_end": 40, "score": .9}
    b = {"final_start": 12, "final_end": 41, "score": .5}
    c = {"final_start": 100, "final_end": 120, "score": .4}
    assert score.dedupe([a, b, c]) == [a, c]


# ------------------------------------------------------------------------ judging by the IDE model ------------------------------------------------------
def cand_for(ws, a, b, score=.5):
    return {"final_words": [a, b], "core_words": [a, b], "final_start": ws[a]["s"], "final_end": ws[b]["e"], "core_start": ws[a]["s"], "core_end": ws[b]["e"], "text": "",
            "score": score, "peak": 5, "issues": [], "boundary_quality": 1.0}


def good(key, **kw):
    return {"key": key, "hook": 8, "payoff": 8, "emotion": 8, "value": 8, "shareability": 8, **kw}


def test_judge_validation_rejects_bad_scores_unknown_keys_duplicates_and_spans_outside_the_window():
    from clipper import judge
    ws = words(["Sentence %d is right here and it has enough words in it." % i for i in range(30)])
    c = cand_for(ws, 60, 100)
    pk = judge.packet(ws, [c], 1)
    k, win = pk["candidates"][0]["key"], pk["candidates"][0]["window"]
    items, errs = judge.validate({"results": [good(k, start_word=win[0] + 5, end_word=win[1] - 5)]}, pk)
    assert items and items[0]["span"] == [win[0] + 5, win[1] - 5] and not errs
    for bad in ({"hook": 11}, {"hook": -1}, {"hook": "8"}, {"hook": True}, {"payoff": None}):
        items, errs = judge.validate({"results": [{**good(k), **bad}]}, pk)
        assert items == [] and errs, bad
    items, errs = judge.validate({"results": [good("nope"), good(k), good(k)]}, pk)
    assert len(items) == 1 and len(errs) == 2  # unknown key + duplicate
    items, errs = judge.validate({"results": [good(k, start_word=0, end_word=win[1])]}, pk)  # span outside THIS candidate's window: scores kept, span refused, reason given
    assert items and "span" not in items[0] and any("window" in e for e in errs)
    assert judge.validate("nope", pk)[0] == [] and judge.validate({"results": "x"}, pk)[0] == []
    it = judge.validate({"results": [good(k, title="x" * 500, flags=["profanity", "bogus"], hook_type="weird", standalone="yes")]}, pk)[0][0]
    assert len(it["title"]) == 100 and it["flags"] == ["profanity"] and it["hook_type"] == "none" and it["standalone"] is True


def test_judge_ranking_blends_local_and_model_scores_and_penalises_missing_context():
    from clipper import judge
    assert abs(sum(judge.WEIGHTS.values()) - 1) < 1e-9
    ws = words(["Sentence %d is right here and it has enough words in it." % i for i in range(60)])
    cs = [cand_for(ws, 10 + 40 * k, 40 + 40 * k, score=sc) for k, sc in enumerate((.7, .5, .5))]
    # keep them apart
    for k, c in enumerate(cs):
        c["final_start"], c["final_end"] = 100.0 * k, 100.0 * k + 30
    keys = [judge.key(c) for c in cs]
    j = {keys[1]: {**good(keys[1]), "standalone": True}, keys[2]: {**good(keys[2], standalone=False)}}
    top, rep = judge.select(ws, cs, 3, j)
    assert [judge.key(c) for c in top][0] == keys[1], "a model-approved clip beats a higher local score that nobody judged"
    assert top[-1]["standalone"] is False or judge.key(top[-1]) != keys[2] or top[-1]["final_score"] < top[1]["final_score"]
    assert rep["judged"] == 2 and rep["needs_judging"] is True
    top2, rep2 = judge.select(ws, cs, 3, {})
    assert [c["final_score"] for c in top2] == [.7, .5, .5] and rep2["judged"] == 0


def test_a_judge_span_is_only_adopted_if_boundaries_do_not_get_worse():
    from clipper import judge
    ws = words(["I really thought we would lose the whole game tonight.", "But then it happened and we won.", "Amazing.", "Anyway the weather is nice today and so on and so forth."], pause=0.4)
    c = B.refine_checked(ws, 0, 12)
    c.update(score=.5, peak=5)
    c["kind"] = "speech"
    k = judge.key(c)
    # span that ends mid-sentence is re-snapped to a sentence end by refine_checked, so quality never drops
    top, _ = judge.select(ws, [c], 1, {k: {**good(k), "span": [0, 5]}})
    assert top[0]["boundary_quality"] >= .7 and "ends_mid_sentence" not in top[0]["issues"]


def test_selection_hash_changes_when_the_model_submits_judgments(tmp_path):
    from clipper import job as J
    j, _ = make_job(tmp_path)
    assert j.done("select")
    util.jsave(j.p("judgments.json"), {"abc": {"hook": 9}})
    assert not j.done("select") and not j.done("render") and j.done("candidates")


def test_opening_review_drops_throat_clearing_and_hook_score_prefers_real_hooks():
    ws = words(["Yeah.", "Okay.", "Nobody tells you the real reason you keep losing money every single month and it drives me crazy.", "You never track the small stuff because it feels harmless.",
                "Then one day you check and it is gone.", "That is the whole story."], pause=0.3)
    c = B.refine_checked(ws, 0, len(ws) - 1)
    assert c["opening_trimmed"] == 2 and c["text"].startswith("Nobody") and c["core_words"][0] >= c["final_words"][0]
    assert score.hook_score("Nobody tells you the real reason you keep losing money.") > score.hook_score("So um and then we went there.")
    assert score.hook_score("Why did he do that?") > score.hook_score("And then we left.")


# ---------------------------------------------------------------- jobs: identity & invalidation -------------------------------------------------------
def make_job(tmp_path, **opts):
    from clipper import job as J
    src = tmp_path / "v.mp4"
    src.write_bytes(os.urandom(5000))
    j = J.create(str(src), tmp_path / "jobs", **opts)
    j.dir.mkdir(parents=True, exist_ok=True)
    util.jsave(j.p("source.json"), {"fingerprint": "abc"})
    for st in J.STAGES:  # pretend every stage already ran with its CURRENT inputs, in dependency order
        util.jsave(j.p(J.ART[st]), {"x": 1})
        j.mark(st, j.expected_hash(st))
    return j, src


def test_changing_caption_style_invalidates_only_render_and_qc(tmp_path):
    from clipper import job as J
    j, src = make_job(tmp_path)
    assert all(j.done(s) for s in J.STAGES)
    j2 = J.create(str(src), tmp_path / "jobs", style="karaoke")
    assert j2.id == j.id
    assert {s for s in J.STAGES if not j2.done(s)} == {"render", "qc"}


def test_changing_clip_count_invalidates_selection_and_everything_downstream_but_not_transcription(tmp_path):
    from clipper import job as J
    j, src = make_job(tmp_path)
    J.create(str(src), tmp_path / "jobs", clips=3)
    assert {s for s in J.STAGES if not j.done(s)} == {"select", "speakers", "render", "qc"}


def test_changing_whisper_model_invalidates_the_whole_chain_after_ingest(tmp_path):
    from clipper import job as J
    j, src = make_job(tmp_path)
    J.create(str(src), tmp_path / "jobs", model="quality")
    assert {s for s in J.STAGES if not j.done(s)} == set(J.STAGES) - {"ingest"}


def test_replacing_the_source_content_changes_job_identity_and_ingest_hash(tmp_path):
    from clipper import job as J
    j, src = make_job(tmp_path)
    old = j.expected_hash("ingest")
    src.write_bytes(os.urandom(7000))
    j2 = J.create(str(src), tmp_path / "jobs")
    assert j2.id != j.id, "different content must never share a job directory (or its renders)"
    assert j.expected_hash("ingest") != old


def test_editing_a_chat_file_invalidates_signals_and_downstream(tmp_path):
    from clipper import job as J
    chat = tmp_path / "chat.jsonl"
    chat.write_text('{"t":1,"u":"a","m":"x"}\n')
    j, src = make_job(tmp_path, chat=str(chat))
    assert j.done("signals")
    chat.write_text('{"t":1,"u":"a","m":"x"}\n{"t":2,"u":"b","m":"y"}\n')
    assert not j.done("signals") and j.done("transcribe")


def test_stage_invalidate_cascades_and_artifacts_are_atomic(tmp_path):
    from clipper import job as J
    j, _ = make_job(tmp_path)
    j.invalidate("signals")
    assert not any(j.p(J.ART[s]).exists() for s in ("signals", "candidates", "select", "speakers", "render", "qc")) and j.p("transcript.json").exists()
    util.jsave(j.p("a.json"), {"k": 1})
    assert not list(j.dir.glob("*.tmp")) and util.jload(j.p("a.json")) == {"k": 1}
    j.p("bad.json").write_text("{not json")
    assert util.jload(j.p("bad.json"), "fallback") == "fallback"  # a corrupt artifact is treated as missing, never crashes the job


def test_job_lock_blocks_a_second_writer_and_recovers_from_a_stale_lock(tmp_path):
    from clipper import job as J
    j, _ = make_job(tmp_path)
    assert j.lock()
    j2 = J.Job(tmp_path / "jobs", j.id)
    j2.p("job.lock").write_text(str(os.getppid()))  # another live process owns it
    j.unlock()
    j2.p("job.lock").write_text(str(os.getppid()))
    assert not j2.lock()
    j2.p("job.lock").write_text("99999999")  # dead pid
    assert j2.lock()
    j2.unlock()


# --------------------------------------------------------------------- model manager --------------------------------------------------------------
@pytest.fixture()
def fake_model(tmp_path, monkeypatch):
    import http.server, threading, hashlib
    data = os.urandom(300_000)

    class H(http.server.BaseHTTPRequestHandler):
        fail_first = [True]

        def do_GET(self):
            rng = self.headers.get("Range")
            start = int(rng.split("=")[1].split("-")[0]) if rng else 0
            body = data[start:]
            if H.fail_first[0] and not rng:  # first attempt dies half-way: the manager must RESUME with a Range request
                H.fail_first[0] = False
                self.send_response(200); self.send_header("Content-Length", str(len(data))); self.end_headers()
                self.wfile.write(data[:100_000]); self.wfile.flush(); self.connection.close(); return
            self.send_response(206 if rng else 200); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

        def log_message(self, *a):
            pass
    srv = http.server.HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    monkeypatch.setattr(models, "CACHE", tmp_path / "cache")
    entry = {"url": f"http://127.0.0.1:{srv.server_port}/m.bin", "sha256": hashlib.sha256(data).hexdigest(), "size": len(data), "license": "test", "dest": "m.bin", "needed_for": "test"}
    monkeypatch.setitem(models.MANIFEST, "fake", entry)
    yield entry, data
    srv.shutdown()


def test_model_download_resumes_verifies_and_replaces_atomically(fake_model, monkeypatch):
    monkeypatch.setattr(models.time, "sleep", lambda s: None)
    p = models.ensure("fake", log=lambda *_: None)
    assert p.read_bytes() == fake_model[1] and not p.with_name(p.name + ".part").exists()


def test_corrupted_model_is_discarded_and_offline_mode_refuses_to_download(fake_model, monkeypatch):
    monkeypatch.setattr(models.time, "sleep", lambda s: None)
    p = models.ensure("fake", log=lambda *_: None)
    p.write_bytes(b"corrupt")
    monkeypatch.setenv("CLIPPER_OFFLINE", "1")
    with pytest.raises(models.ModelUnavailable, match="offline|OFFLINE"):
        models.ensure("fake", log=lambda *_: None)
    assert not p.exists(), "a corrupted file must be removed, never used"


def test_wrong_checksum_from_upstream_is_rejected(fake_model, monkeypatch):
    monkeypatch.setattr(models.time, "sleep", lambda s: None)
    monkeypatch.setitem(models.MANIFEST, "fake", {**fake_model[0], "sha256": "0" * 64})
    with pytest.raises(models.ModelUnavailable, match="SHA-256"):
        models.ensure("fake", log=lambda *_: None)
    assert not list((models.CACHE).glob("*.part")) and not (models.CACHE / "m.bin").exists()


def test_manifest_is_complete_and_try_ensure_degrades_with_a_recorded_reason(monkeypatch, tmp_path):
    for n, e in models.MANIFEST.items():
        if not n.startswith("_"):
            assert len(e["sha256"]) == 64 and e["size"] > 0 and e["url"].startswith("http") and e["license"], n
    monkeypatch.setattr(models, "CACHE", tmp_path / "empty")
    monkeypatch.setenv("CLIPPER_OFFLINE", "1")
    assert models.try_ensure("yunet.onnx", "test feature") is None and "test feature" in util.skipped()


# ------------------------------------------------------------------- captions / render maths -----------------------------------------------------
PRESET_NAMES = ["bold_pop", "karaoke", "clean_lower", "boxed", "minimal_white", "highlight_words", "podcast_speaker", "gaming_bold", "cinematic"]


@pytest.mark.parametrize("name", PRESET_NAMES)
def test_every_caption_preset_builds_valid_timed_ass_without_overflow(name):
    ws = words(["This is the moment nobody saw coming at all.", "Wow that was crazy, honestly I did not expect it."])
    ass = captions.build(ws, 0.0, name, speaker_at=lambda t: 0 if t < 3 else 1)
    ev = [l for l in ass.splitlines() if l.startswith("Dialogue")]
    assert ev and "Fontname" in ass
    times = [l.split(",")[1:3] for l in ev]
    assert all(a <= b for a, b in times)
    assert captions.overflow(ws, captions.style(name)) == 0


def test_custom_style_from_file_rejects_unknown_keys_and_flags_system_fonts(tmp_path):
    f = tmp_path / "s.json"
    f.write_text(json.dumps({"font": "Anton", "size": 70, "hi": captions.GREEN, "words": 2, "mv": 500, "anim": "pop"}))
    st = captions.style("custom", f)
    assert st["font"] == "Anton" and st["words"] == 2 and not st["font_is_system"]
    f.write_text(json.dumps({"fontt": "x"}))
    with pytest.raises(ValueError):
        captions.style("custom", f)
    assert captions.style({"font": "Comic Sans MS"})["font_is_system"]


def test_bundled_fonts_and_licences_exist():
    names = {p.name for p in captions.FONTS.glob("*")}
    assert {"Poppins-ExtraBold.ttf", "Anton-Regular.ttf", "BebasNeue-Regular.ttf"} <= names and any(n.startswith("OFL") for n in names)


def test_caption_groups_never_overflow_and_a_single_oversize_word_is_isolated():
    ws = words(["Supercalifragilisticexpialidocious pneumonoultramicroscopicsilicovolcanoconiosis antidisestablishmentarianism extraordinarily."])
    for n in PRESET_NAMES:
        st = captions.style(n)
        ch = captions.chunks(ws, st, 1.0)
        assert all(len(g) == 1 for g in ch if sum(len(w["w"]) + 1 for w in g) * st["size"] * 0.58 > captions.W - 100), n  # an oversize word sits ALONE; it never drags neighbours off-screen
    ok = words(["This is a perfectly normal caption line for any style."])
    assert all(captions.overflow(ok, captions.style(n), 1.0) == 0 for n in PRESET_NAMES)


def test_crop_expression_changes_only_at_cuts_and_zoom_never_crosses_a_cut():
    assert R.crop_expr([[[0, .2]], [[10, .7]]], [10]) == "if(lt(t,10),0.200,0.700)"
    assert "if(" not in R.crop_expr([[[0, .48]], [[10, .5]], [[20, .52]]], [10, 20])
    assert "(t-" in R.crop_expr([[[0, .3], [4, .3], [5, .7]]], [])
    assert R.shot_cuts(100, 130, [100.5, 110, 110.8, 129.5, 120]) == [10.0, 20.0]
    assert "0.120*max(0" in R.zoom_expr(1, [{"t": 3, "dur": 2, "amt": 1.12}])


def test_filtergraph_uses_bundled_fonts_dir_and_overlays_in_order():
    info = {"width": 1280, "height": 720, "fps": 25, "audio": True}
    vf = R.vfilter(info, "fill", "0.5", "c.ass", None, logo={"file": "l.png", "pos": "tr"}, fade=10.0)
    assert "subtitles=c.ass:fontsdir=fonts" in vf and vf.index("overlay") < vf.index("subtitles") and "fade=t=in" in vf


def test_encoder_selection_uses_a_real_test_encode_and_falls_back(monkeypatch):
    seen = []
    monkeypatch.setattr(R, "_ENC", [])
    monkeypatch.setattr(R, "run", lambda cmd, **kw: type("P", (), {"stdout": " V..... h264_nvenc\n V..... h264_qsv\n V..... libx264", "stderr": "", "returncode": 0})())
    monkeypatch.setattr(R, "_test_encode", lambda e: (seen.append(e), e == "h264_qsv")[1])
    assert R.encoder() == "h264_qsv" and seen == ["h264_nvenc", "h264_qsv"]  # nvenc is LISTED but fails its test encode -> next candidate
    monkeypatch.setattr(R, "_ENC", [])
    monkeypatch.setattr(R, "_test_encode", lambda e: False)
    assert R.encoder() == "libx264"
    assert set(R.ENC_ARGS) == {"libx264", "h264_nvenc", "h264_qsv", "h264_amf", "h264_videotoolbox"}


# ---------------------------------------------------------------------- ingest / validation ----------------------------------------------------------
@pytest.mark.parametrize("bad", ["", "-rf", "--exec=touch x", "file:///etc/passwd", "ftp://x/y", "javascript:alert(1)", "data:text/html,x", "http://user:pw@host/x", "http://", "a\nb", "x" * 5000])
def test_hostile_sources_are_rejected(bad):
    with pytest.raises(ValueError):
        util.validate_source(bad)


@pytest.mark.parametrize("ok", ["https://www.youtube.com/watch?v=abc", "https://twitch.tv/videos/1", "rtmp://127.0.0.1:1935/live/k", "https://x.com/a.m3u8", "video.mp4", "C:\\Videos\\a.mp4", "/home/u/a.mkv"])
def test_legit_sources_pass(ok):
    assert util.validate_source(ok) == ok


def test_path_and_archive_traversal_blocked(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    util.safe_path(tmp_path / "a" / "b")
    with pytest.raises(ValueError):
        util.safe_path("../../etc/passwd")
    evil = tmp_path / "evil.tar"
    with tarfile.open(evil, "w") as tf:
        (tmp_path / "x.txt").write_text("x")
        ti = tf.gettarinfo(str(tmp_path / "x.txt"), arcname="../escape.txt")
        tf.addfile(ti, open(tmp_path / "x.txt", "rb"))
    with tarfile.open(evil) as tf, pytest.raises(ValueError, match="unsafe"):
        util.safe_extract_tar(tf, tmp_path / "out")
    assert not (tmp_path / "escape.txt").exists()


def test_subprocess_helper_refuses_strings_and_survives_timeouts():
    with pytest.raises(AssertionError):
        util.run("echo hi; rm -rf /")
    r = util.run(["sleep", "5"], timeout=0.3) if os.name != "nt" else util.run(["ping", "-n", "6", "127.0.0.1"], timeout=0.3)
    assert r.returncode == 124


def test_chat_loaders_and_fingerprint(tmp_path):
    from clipper import ingest
    j = tmp_path / "t.json"
    j.write_text(json.dumps({"comments": [{"content_offset_seconds": 3.0, "commenter": {"name": "a"}, "message": {"body": "hi"}}]}))
    assert ingest.load_chat(j)[0]["t"] == 3.0
    y = tmp_path / "y.jsonl"
    y.write_text(json.dumps({"replayChatItemAction": {"videoOffsetTimeMsec": "4000", "actions": [{"addChatItemAction": {}}, {"addChatItemAction": {}}]}}) + "\n")
    assert len(ingest.load_chat(y)) == 2
    a = tmp_path / "a.bin"
    a.write_bytes(b"x" * 3_000_000)
    f1 = util.file_fingerprint(a)
    a.write_bytes(b"x" * 1_500_000 + b"y" + b"x" * 1_499_999)
    assert util.file_fingerprint(a) != f1


# ------------------------------------------------------------------------- kick ---------------------------------------------------------------------
def test_kick_signature_replay_tamper_and_idempotency():
    crypto = pytest.importorskip("cryptography")
    from cryptography.hazmat.primitives.asymmetric import rsa, padding
    from cryptography.hazmat.primitives import hashes, serialization
    k = rsa.generate_private_key(65537, 2048)
    pub = kick.parse_public_key(k.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
    body = json.dumps({"sender": {"username": "v1"}, "content": "KEKW"}).encode()
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    sig = base64.b64encode(k.sign(f"m1.{ts}.".encode() + body, padding.PKCS1v15(), hashes.SHA256())).decode()
    H = {"Kick-Event-Message-Id": "m1", "Kick-Event-Message-Timestamp": ts, "Kick-Event-Signature": sig, "Kick-Event-Type": "chat.message.sent"}
    got = []
    assert kick.handle(H, body, pub, lambda *a: got.append(a))[0] == 200 and len(got) == 1
    assert kick.handle(H, body, pub, lambda *a: got.append(a)) == (200, "duplicate") and len(got) == 1  # redelivery is processed once
    kick._SEEN.clear()
    assert kick.handle(H, body + b"x", pub, lambda *a: None)[0] == 401
    assert kick.handle(H, body, pub, lambda *a: None, now=time.time() + 3600)[0] == 401
    assert kick.handle({}, body, pub, lambda *a: None)[0] == 401


# ----------------------------------------------------------------------- critics ---------------------------------------------------------------
def test_weights_sum_and_critic_criteria_cover_murch_six():
    assert abs(sum(v for k, v in critics.WEIGHT.items() if k != "craft") - 1.0) < 1e-9
    assert {"emotion", "story", "rhythm", "eye_trace", "plane", "space"} <= set(critics.WEIGHT)


def test_audio_rms_gives_one_value_per_second_aligned_to_the_signal(tmp_path):
    """Regression: asetnsamples counted samples at the INPUT rate, so a 'second' was 1/6 s and every audio peak was placed at the wrong time."""
    import subprocess
    try:
        ff = util.ffmpeg()
    except SystemExit:
        pytest.skip("no ffmpeg")
    w = tmp_path / "step.wav"
    subprocess.run([ff, "-y", "-v", "error", "-f", "lavfi", "-i", "anullsrc=r=48000:cl=mono:d=4", "-f", "lavfi", "-i", "sine=f=440:d=4:r=48000", "-f", "lavfi", "-i", "sine=f=440:d=4:r=48000",
                    "-filter_complex", "[1:a]volume=0.05[q];[0:a][q][2:a]concat=n=3:v=0:a=1[a]", "-map", "[a]", str(w)], check=True)
    r = S.audio_rms(str(w), 12)
    assert len(r) == 13 and max(r[:3]) == -90 and -50 < r[5] < -40 and r[9] > -25, r  # silence, quiet tone, loud tone at 4 s each


def test_critic_trims_back_when_the_source_itself_ends_mid_sentence(tmp_path):
    """A clip cannot be 'extended' to a sentence end that does not exist in the media: trim to the last finished sentence instead."""
    from clipper import job as J
    ws = words(["This is the first complete sentence of the clip.", "And here is a second one that is also finished properly.", "But the footage stops while he is saying that the"])
    j = J.Job(tmp_path / "jobs", "0123456789")
    plan = {"clips": [{"id": 1, "final_start": 0.0, "final_end": ws[-1]["e"] + 0.1, "final_words": [0, len(ws) - 1], "final_score": .5, "caption": {"style": None, "scale": 1.0},
                       "layout": "fill", "zooms": [], "text": "", "hook": .5, "score": .5}], "cost": {}}
    util.jsave(j.p("plan.json"), plan), util.jsave(j.p("transcript.json"), {"words": ws}), util.jsave(j.p("job.json"), {"profile": "auto"})
    util.jsave(j.p("source.json"), {"info": {"duration": 60, "width": 1280, "height": 720, "audio": True, "fps": 25}})
    x = critics.Ctx(j)
    r = critics.Rep("cut")
    critics.cut(x, r)
    f = next(f for f in r.clips[1] if f["code"] == "cut_mid_sentence")
    assert f["edit"] and f["edit"]["end_shift"] < 0, f  # trims BACK; never extends past the end of the media


# ------------------------------------------------------------------------ Twitch / Kick chat as a signal -----------------------------------------------------
def _tw_rows(offsets, prefix="m"):
    return [{"id": f"{prefix}{o}", "t": float(o), "u": f"u{k % 7}", "m": "KEKW"} for k, o in enumerate(offsets)]


def test_twitch_and_kick_urls_are_recognised_and_page_parsing_survives_missing_fields():
    assert chat.twitch_video_id("https://www.twitch.tv/videos/2932067529?t=1h") == "2932067529" and chat.twitch_video_id("https://twitch.tv/x/v/123") == "123"
    assert chat.twitch_video_id("https://www.twitch.tv/gaules") is None
    assert chat.kick_video_uuid("https://kick.com/video/716d63b6-afa9-4afd-a1a6-d9aedf3e3a23") == "716d63b6-afa9-4afd-a1a6-d9aedf3e3a23"
    assert chat.kick_slug("https://kick.com/xqc") == "xqc" and chat.kick_slug("https://kick.com/video/abc") is None
    assert chat._kick_text("hi [emote:5882722:BANG][emote:1:KEKW]") == "hi BANGKEKW"


def test_twitch_page_reader_joins_fragments_and_reports_unavailable_chat(monkeypatch):
    node = {"id": "a", "contentOffsetSeconds": 12, "commenter": None, "message": {"fragments": [{"text": "no "}, {"text": "way", "emote": None}]}}
    monkeypatch.setattr(chat, "_http", lambda *a, **k: [{"data": {"video": {"comments": {"edges": [{"node": node}]}}}}])
    assert chat._tw_page("1", 0) == [{"id": "a", "t": 12.0, "u": None, "m": "no way"}]
    monkeypatch.setattr(chat, "_http", lambda *a, **k: [{"data": {"video": {"comments": None}}, "errors": [{"message": "failed integrity check"}]}])
    with pytest.raises(RuntimeError, match="integrity"):
        chat._tw_page("1", 0)
    monkeypatch.setattr(chat, "_http", lambda *a, **k: [{"data": {"video": None}}])
    with pytest.raises(RuntimeError):
        chat._tw_page("1", 0)


def test_sampled_fetch_reads_hot_windows_fully_dedupes_and_never_reports_unread_time_as_covered():
    hot = list(range(600, 660))  # the only busy minute

    def probe(t):
        rows = _tw_rows(range(int(t), int(t) + 3)) if not 600 <= t < 660 else _tw_rows(hot[:20])
        return rows, (t, t + 3), 1

    def full(a, b):
        return (_tw_rows(hot) if a <= 600 < b else []), 1
    rows, cov, st = chat.sampled_fetch(1200, probe, full, step=60, workers=2, budget_calls=25)
    assert len({(r["t"], r["u"]) for r in rows}) <= len(rows) and sum(1 for r in rows if 600 <= r["t"] < 660) >= 60
    assert any(a <= 600 and b >= 660 for a, b in cov) and st["covered_s"] < 1200 and not st["complete"] and st["calls"] <= 30
    assert all(b <= 1200 for _, b in cov)
    rows2, cov2, st2 = chat.sampled_fetch(120, lambda t: ([], (t, t + 5), 1), lambda a, b: ([], 1), step=30, workers=2)
    assert rows2 == [] and st2["errors"] == 0


def test_sampled_fetch_survives_failing_requests_and_respects_the_call_budget():
    def probe(t):
        if int(t) % 120 == 0:
            raise OSError("429")
        return _tw_rows([t]), (t, t + 1), 1
    rows, cov, st = chat.sampled_fetch(600, probe, lambda a, b: (_ for _ in ()).throw(OSError("x")), step=30, workers=2, budget_calls=5)
    assert st["errors"] >= 1 and rows and st["calls"] <= 25


def test_kick_slice_rows_use_wall_clock_offsets_and_live_poller_dedupes(monkeypatch):
    t0 = chat._parse_iso("2026-11-18T06:27:54Z")
    msgs = [{"id": "a", "created_at": "2026-11-18T06:28:00Z", "content": "[emote:1:KEKW]", "sender": {"slug": "bob"}}, {"id": "b", "created_at": "2026-11-18T06:35:00Z", "content": "late"}]
    rows = chat._kick_rows(msgs, t0, 0, 100)
    assert rows == [{"id": "a", "t": 6.0, "u": "bob", "m": "KEKW"}]
    import threading
    got, stop, calls = [], threading.Event(), []
    monkeypatch.setattr(chat, "kick_channel_id", lambda slug: 668)

    def get(cid):
        calls.append(1)
        if len(calls) >= 3:
            stop.set()
        return {"data": {"messages": msgs}}
    chat.kick_chat("xqc", lambda ts, u, m: got.append((u, m)), stop, poll=0.01, get=get)
    assert got == [("bob", "KEKW"), (None, "late")], "the same message must be delivered once however often the endpoint repeats it"


def test_chat_signal_counts_hype_and_clip_requests_and_interpolates_unread_time():
    base = [{"t": 10.2, "u": f"u{i}", "m": "ok"} for i in range(5)]
    hype = [{"t": 10.2, "u": f"u{i}", "m": "KEKW"} for i in range(5)]
    req = [{"t": 10.2, "u": f"u{i}", "m": "clip that"} for i in range(5)]
    a, b, c = (S.chat_series(x, 30)[10] for x in (base, hype, req))
    assert a < b < c
    ch = [{"t": 5.5, "u": "a", "m": "x"}] * 1 + [{"t": 95.5 + k * 0.1, "u": f"u{k}", "m": "KEKW"} for k in range(40)]
    s = S.chat_series_covered(ch, 200, [(0, 10), (90, 100)])
    assert s[50] == pytest.approx((s[10] + s[90]) / 2, abs=s[95] * 0.5) or 0 < s[50] < max(s)
    assert S.chat_series_covered(ch, 200, None) == S.chat_series(ch, 200)
    assert s[150] == sorted(x for i, x in enumerate(s) if i <= 10 or 90 <= i <= 100)[len([1 for i in range(len(s)) if i <= 10 or 90 <= i <= 100]) // 2]  # >360 s from data: median of read seconds


def test_chat_coverage_is_only_used_for_sampled_files(tmp_path):
    (tmp_path / "chat.jsonl").write_text("")
    assert chat.load_coverage(tmp_path / "chat.jsonl") is None
    (tmp_path / "chat.coverage.json").write_text(json.dumps({"coverage": [[0, 10], [50, 60]]}))
    assert chat.load_coverage(str(tmp_path / "chat.jsonl")) == [(0, 10), (50, 60)]
    assert chat.load_coverage(tmp_path / "other.jsonl") is None and chat.load_coverage(None) is None


# ------------------------------------------------------------------------ captions: emphasis, emoji, model edits --------------------------------------------------
def _cw(text, t0=0.0):
    return [{"w": x, "s": t0 + i * .4, "e": t0 + i * .4 + .35, "i": 100 + i} for i, x in enumerate(text.split())]


def test_emphasis_marks_power_words_but_not_everything():
    st = captions.style("hormozi")
    pw = captions.prepare(_cw("I lost 50000 dollars and it was insane never again"), st, None)
    em = {w["w"] for w in pw if w["_em"]}
    assert {"50000", "insane", "never"} <= em and "was" not in em
    assert not any(w["_em"] for w in captions.prepare(_cw("never always every best worst never always every best"), st, None)), "emphasis everywhere = emphasis nowhere"
    assert not any(w["_em"] for w in captions.prepare(_cw("never 50000"), st, {"emphasis": False}))
    assert not any(w["_em"] for w in captions.prepare(_cw("never 50000 and then something happened"), captions.style("karaoke"), None)), "presets without an emphasis colour stay plain by default"


def test_model_edits_fix_text_force_emphasis_and_are_validated_against_the_clip():
    ws, st = _cw("this is the bst moment ever"), captions.style("hormozi")
    cap = {"edits": {"text": {"103": "best"}, "emphasis": [105], "unemphasis": [104]}}
    pw = captions.prepare(ws, st, cap)
    assert pw[3]["_t"] == "BEST" and pw[5]["_em"] and not pw[4]["_em"]
    ok, errs = captions.validate_edits({"text": {"103": "best", "999": "x", "x": "y", "101": ""}, "emphasis": [100, 5000], "emoji": [{"word": 101, "emoji": "fire"}, {"word": 101, "emoji": "zzz"}, {"word": 7, "emoji": "fire"}], "bogus": 1}, 100, 105)
    assert ok["text"] == {"103": "best"} and ok["emphasis"] == [100] and len(ok["emoji"]) == 1 and len(errs) >= 5
    assert captions.validate_edits("x", 0, 1)[1]
    txt = captions.build(ws, 0, "hormozi", cap={"edits": {"text": {"100": "{\\evil}"}}})
    assert "EVIL" in txt and "{\\evil}" not in txt.lower(), "ASS override characters in a model-supplied word must be stripped"


def test_emoji_events_are_spaced_capped_and_explicit_ones_win():
    ws = _cw("money fire crazy dead love money win goal secret rocket idea game car lock", 0.0)
    st = captions.style("hormozi")
    ev = captions.emoji_events(ws, 0, st, None, 30.0)
    assert 1 <= len(ev) <= captions.EMOJI_MAX and all(b["t"] - a["t"] >= captions.EMOJI_MIN_GAP - 1e-6 for a, b in zip(ev, ev[1:])) and ev[0]["t"] >= 0.4
    assert all(Path(e["file"]).is_file() for e in ev)
    assert captions.emoji_events(ws, 0, captions.style("karaoke"), None, 30.0) == [], "off by default for styles that do not use emoji"
    assert len(captions.emoji_events(ws, 0, captions.style("karaoke"), {"emoji": True}, 30.0)) >= 1
    assert captions.emoji_events(ws, 0, st, {"emoji": False}, 30.0) == []
    ex = captions.emoji_events(ws, 0, captions.style("karaoke"), {"edits": {"emoji": [{"word": 103, "emoji": "skull", "dur": 1.0}]}}, 30.0)
    assert len(ex) == 1 and ex[0]["file"].endswith("1f480.png") and abs(ex[0]["t"] - 1.2) < 1e-6
    assert captions.emoji_events(ws, 0, st, {"edits": {"no_emoji": [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113]}}, 30.0) == []
    assert captions.emoji_file("fire") and captions.emoji_file("1f525") and captions.emoji_file("\U0001F525") and captions.emoji_file("nope") is None and captions.emoji_file("") is None


def test_every_emoji_in_the_table_is_bundled_with_its_licence():
    assert all(captions.emoji_file(n) for n in captions.EMOJI), [n for n in captions.EMOJI if not captions.emoji_file(n)]
    assert (captions.EMOJI_DIR / "LICENSE-GRAPHICS.txt").is_file()


# ------------------------------------------------------------------------ layouts: the user approves ---------------------------------------------------------------
def _planned_job(tmp_path):
    from clipper import job as J
    j, _ = make_job(tmp_path)
    ws = words(["I really thought we would lose the whole game tonight and it was close.", "But then it happened and we won the whole thing."], pause=0.4)
    c = B.refine_checked(ws, 0, len(ws) - 1)
    clip = {**c, "id": 1, "caption": {"style": None, "scale": 1.0}, "layout": "fit", "zooms": [], "score": .5, "final_score": .5}
    util.jsave(j.p("plan.json"), {"clips": [clip], "judging": {}, "profile": "gaming"})
    util.jsave(j.p("transcript.json"), {"words": ws})
    return j, J


def test_multi_region_layouts_cannot_be_set_directly_only_proposed_then_approved(tmp_path):
    j, J = _planned_job(tmp_path)
    with pytest.raises(SystemExit, match="approval"):
        J.edit_clip(j, 1, {"layout": "split"})
    assert util.jload(j.p("plan.json"))["clips"][0]["layout"] == "fit"
    with pytest.raises(SystemExit):
        J.edit_clip(j, 1, {"layout_approve": True})  # nothing proposed yet
    pr = {"layout": "split", "regions": {"cam": layouts.parse_box("0,0.6,0.3,0.4")}, "pct": .4, "reason": "streamer cam bottom-left"}
    J.edit_clip(j, 1, {"layout_proposal": pr})
    c = util.jload(j.p("plan.json"))["clips"][0]
    assert c["layout"] == "fit" and c["layout_proposal"]["status"] == "proposed", "a proposal must not change the render"
    J.edit_clip(j, 1, {"layout_approve": True})
    c = util.jload(j.p("plan.json"))["clips"][0]
    assert c["layout"] == "split" and c["regions"]["cam"] == [0, .6, .3, .4] and c["pct"] == .4 and c["layout_proposal"]["status"] == "approved"
    J.edit_clip(j, 1, {"layout": "fill"})  # fill/fit stay a plain edit
    assert util.jload(j.p("plan.json"))["clips"][0]["layout"] == "fill"
    J.edit_clip(j, 1, {"layout_proposal": {**pr, "layout": "half"}})
    J.edit_clip(j, 1, {"layout_reject": True})
    assert "layout_proposal" not in util.jload(j.p("plan.json"))["clips"][0]


def test_layout_recommendation_and_box_validation():
    assert layouts.recommend("gaming", 16 / 9)[0]["layout"] == "split" and layouts.recommend("podcast", 9 / 16)[0]["layout"] == "fill"
    assert layouts.recommend("podcast", 16 / 9, 2)[0]["layout"] == "split"
    assert layouts.missing("split", {}) == ["cam"] and layouts.missing("filler", {}, None) == ["filler"] and layouts.missing("fullscreen", {}) == []


def test_caption_edit_ops_validate_all_or_nothing_and_merge(tmp_path):
    j, J = _planned_job(tmp_path)
    with pytest.raises(SystemExit, match="rejected"):
        J.edit_clip(j, 1, {"caption_edits": {"text": {"2": "ok", "9999": "bad"}}})
    assert "edits" not in util.jload(j.p("plan.json"))["clips"][0]["caption"], "one bad item must apply nothing"
    J.edit_clip(j, 1, {"caption_edits": {"text": {"2": "fixed"}, "emphasis": [3]}})
    J.edit_clip(j, 1, {"caption_edits": {"emphasis": [1]}, "caption_emoji": False})
    cap = util.jload(j.p("plan.json"))["clips"][0]["caption"]
    assert cap["edits"]["text"] == {"2": "fixed"} and cap["edits"]["emphasis"] == [1, 3] and cap["emoji"] is False
    J.edit_clip(j, 1, {"caption_edits": {}})
    assert "edits" not in util.jload(j.p("plan.json"))["clips"][0]["caption"]


# ------------------------------------------------------------------------ ingest + speed ------------------------------------------------------------------------
def test_sources_from_many_sites_are_classified_and_cookie_options_are_safe():
    from clipper import ingest
    for u, p in (("https://www.tiktok.com/@a/video/1", "tiktok"), ("https://x.com/a/status/1", "x"), ("https://www.instagram.com/reel/abc/", "instagram"), ("https://kick.com/video/uuid", "kick"),
                 ("https://clips.twitch.tv/Abc", "twitch_clip"), ("https://www.reddit.com/r/a/comments/1/x/", "reddit")):
        assert ingest.classify(u)["platform"] == p, u
    assert ingest._cookies("browser:chrome") == ["--cookies-from-browser", "chrome"] and ingest._cookies("browser:chrome;rm") == ["--cookies", "browser:chrome;rm"] and ingest._cookies(None) == []
    assert "--no-playlist" in ingest.YT


def test_fast_mode_picks_separated_windows_and_merges_overlaps():
    from clipper import transcribe as T
    s = [0.0] * 3600
    for t in (500, 520, 2000, 3000):
        s[t] = 10
    rs = T.pick_ranges(s, 3600, 3, win=150)
    assert rs == [(425.0, 575.0), (1925.0, 2075.0), (2925.0, 3075.0)] or len(rs) == 3
    assert sum(b - a for a, b in rs) <= 3 * 150 and all(rs[i][1] < rs[i + 1][0] for i in range(len(rs) - 1))


def test_ytdlp_errors_are_classified_with_actionable_hints():
    from clipper import ingest
    import re
    cls = lambda e: next((s for rx, s, h in ingest.HINTS if re.search(rx, e, re.I)), None)
    assert cls("ERROR: Sign in to confirm you're not a bot") == "auth_required" and cls("HTTP Error 429: Too Many Requests") == "unavailable"
    assert cls("ERROR: [generic] Unsupported URL: https://example.com/page") == "unavailable" and cls("The video message was removed") is None


# ------------------------------------------------------------------------ chat: skew, fallback, self-check, languages --------------------------------------------------
def _burst_audio(n, bursts, base=10.0, amp=30.0):
    a = [base + (3 * ((i * 7919) % 5) / 5) for i in range(n)]
    for b in bursts:
        for k in range(-3, 4):
            if 0 <= b + k < n:
                a[b + k] += amp * (1 - abs(k) / 4)
    return a


def _burst_chat(bursts, lag, per=25):
    return [{"t": b + lag + (k % 5) * 0.4, "u": f"u{k}", "m": "KEKW"} for b in bursts for k in range(per)]


@pytest.mark.parametrize("lag", [-12, -6, 0, 7, 15])
def test_estimate_shift_recovers_the_clock_offset_between_chat_and_audio(lag):
    bursts = [100, 260, 430, 610, 800, 950, 1130]
    audio = _burst_audio(1300, bursts)
    shift, c = chat.estimate_shift(_burst_chat(bursts, lag), audio)
    assert shift == pytest.approx(-lag, abs=1.5), (lag, shift, c)


def test_estimate_shift_refuses_to_move_chat_that_does_not_match_the_audio_or_is_too_thin():
    audio = _burst_audio(1300, [100, 400, 700])
    noise = [{"t": (i * 37) % 1300 + 0.1, "u": "a", "m": "x"} for i in range(400)]
    assert chat.estimate_shift(noise, audio)[0] == 0.0
    assert chat.estimate_shift(_burst_chat([100], 5, per=5), audio)[0] == 0.0, "too few messages: leave it alone"
    assert chat.estimate_shift([], audio) == (0.0, 0.0) and chat.estimate_shift(noise, [1.0] * 50) == (0.0, 0.0)


def test_vod_chat_falls_back_to_chat_downloader_and_reports_why_when_nothing_works(tmp_path, monkeypatch):
    import sys, types
    monkeypatch.setattr(chat, "twitch_vod_chat", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("failed integrity check")))

    class FakeCD:
        def get_chat(self, url, **kw):
            assert kw["end_time"] == 600 and kw["message_types"] == ["text_message"]
            return [{"time_in_seconds": 12.5, "author": {"name": "bob"}, "message": "KEKW"}, {"time_in_seconds": -3, "message": "pre-roll"}, {"time_in_seconds": 9999, "message": "late"}]
    monkeypatch.setitem(sys.modules, "chat_downloader", types.SimpleNamespace(ChatDownloader=FakeCD))
    p = chat.fetch_vod_chat("https://www.twitch.tv/videos/1", 600, tmp_path, log=lambda *_: None)
    rows = [json.loads(x) for x in open(p)]
    assert rows == [{"t": 12.5, "u": "bob", "m": "KEKW"}] and json.loads((tmp_path / "chat.coverage.json").read_text())["stats"]["via"] == "chat-downloader"
    monkeypatch.setitem(sys.modules, "chat_downloader", None)  # not installed
    util.skipped().clear() if hasattr(util.skipped(), "clear") else None
    assert chat.fetch_vod_chat("https://www.twitch.tv/videos/1", 600, tmp_path / "x", log=lambda *_: None) is None
    assert "integrity" in json.dumps(util.skipped()) and "chat-downloader" in json.dumps(util.skipped())


def test_kick_vod_chat_is_flagged_for_alignment_and_full_mode_widens_the_budget(tmp_path, monkeypatch):
    seen = {}
    monkeypatch.setattr(chat, "kick_vod_chat", lambda uuid, dur, **kw: (seen.update(kw), ([{"t": 1.0, "u": "a", "m": "x"}], [(0, 10)], {"complete": False}))[1])
    p = chat.fetch_vod_chat("https://kick.com/video/716d63b6-afa9-4afd-a1a6-d9aedf3e3a23", 600, tmp_path, log=lambda *_: None, full=True)
    assert chat.load_align(p) is True and seen["budget_calls"] == chat.FULL["budget_calls"] and seen["step"] == 30.0
    monkeypatch.setattr(chat, "twitch_vod_chat", lambda vid, dur, **kw: ([{"t": 1.0, "u": "a", "m": "x"}], [(0, 10)], {"complete": False}))
    p2 = chat.fetch_vod_chat("https://www.twitch.tv/videos/5", 600, tmp_path / "t", log=lambda *_: None)
    assert chat.load_align(p2) is False and chat.load_align(None) is False


def test_selfcheck_names_the_endpoint_that_broke():
    def get(url, body=None, headers=None, timeout=25):
        if "gql.twitch" in url:
            return {"data": {"user": {"videos": {"edges": []}}}}
        if url.endswith("/videos"):
            raise OSError("HTTP 403")
        raise AssertionError(url)
    out = chat.selfcheck(get)
    assert out["twitch_vod_chat"][0] is False and "past broadcast" in out["twitch_vod_chat"][1]
    assert out["kick_vod_chat"][0] is False and "403" in out["kick_vod_chat"][1] and out["kick_live_chat"][0] is False


def test_hooks_openers_laughter_and_dependent_sentences_work_in_spanish_portuguese_french_german_italian():
    plain = "Y luego fuimos allí y ya."
    for t in ("¿Por qué nadie te cuenta la verdad sobre el dinero?", "Ninguém te conta o verdadeiro segredo do dinheiro.", "Pourquoi personne ne dit la vérité sur l'argent ?",
              "Warum sagt dir niemand die Wahrheit über Geld?", "Perché nessuno ti dice il segreto dei soldi?"):
        assert score.hook_score(t) >= .6, t
    assert score.hook_score(plain) < .2 and score.hook_score("Pues entonces fuimos allí y ya.") < .2
    assert S.LAUGH.search("jajaja qué locura") and S.LAUGH.search("kkkkk nossa") and S.LAUGH.search("mdr") and S.HYPE.search("jajaja") and S.HYPE.search("clipa isso")
    w = lambda txt: [{"w": x, "s": i * .3, "e": i * .3 + .25} for i, x in enumerate(txt.split())]
    ws = w("Bueno. Nadie te cuenta la verdad sobre el dinero y por eso lo pierdes cada mes sin darte cuenta de nada. Pero la razón es simple porque nunca controlas los gastos pequeños. Entonces un día miras y ya no hay nada.")
    assert B.refine_checked(ws, 0, 35)["opening_trimmed"] == 1
    c = B.refine_checked(ws, 18, 30)
    assert c["text"].startswith("Nadie te cuenta"), "a sentence opening with 'Pero' must pull in its setup"


# ------------------------------------------------------------------------ auto style, story cards, webcam detection ------------------------------------------------
def test_auto_style_picks_a_preset_per_moment_from_profile_and_the_models_judgment():
    a = captions.auto_style
    assert a("gaming", {"kind": "event"}) == "fire" or a("gaming", {"kind": "event"}) == "gaming_bold"
    assert a("gaming", {"judge": {"emotion": 9}}) == "fire" and a("gaming", {"judge": {"emotion": 3}}) == "gaming_bold" and a("sports") == "fire"
    assert a("podcast", {"judge": {"hook_type": "statistic"}}) == "hormozi" and a("podcast", {"judge": {"hook_type": "story"}}) == "cinematic"
    assert a("podcast", {}, speakers_reliable=True) == "podcast_speaker" and a("podcast", {}, speakers_reliable=False) == "hormozi"
    assert a("comedy", {"judge": {"emotion": 8}}) == "mrbeast" and a("irl", {}) == "tiktok" and a("auto", {}) == "bold_pop"
    assert a("podcast", {"judge": {"hook_type": "reaction"}}) == "mrbeast" and a("irl", {"judge": {"hook_type": "question"}}) == "tiktok"
    for p in ("gaming", "sports", "podcast", "interview", "irl", "comedy", "auto"):
        for ht in (None, "story", "statistic", "reaction", "question", "none"):
            assert a(p, {"judge": {"hook_type": ht, "emotion": 5}}) in captions.PRESETS


def test_story_card_text_wraps_and_fits_its_card_and_is_stripped_of_ass_syntax():
    for text in ("Short.", "I found out my roommate had been using my name for three years " * 3, "x" * 400):
        lines, size = captions.card_lines(text, 576 - 150)
        assert lines and len(lines) * size * 1.3 <= 576 - 150 + size * 1.3 and all(len(l) <= 40 for l in lines)
    assert "{" not in "".join(captions.card_lines("a {\\b1} b", 400)[0])
    ass = captions.build([], 0, "bold_pop", card=("My roommate stole my identity", 576, 12.0))
    assert "Style: Card" in ass and ass.count("Dialogue:") == 2 and "\\p1" in ass and "My roommate stole" in ass


def test_story_and_speaker_layouts_are_registered_with_the_right_needs():
    assert {"story_card", "story_filler", "speaker_pip"} <= set(layouts.LAYOUTS) and len(layouts.LAYOUTS) == 14
    assert layouts.missing("story_card", {}) == [] and layouts.missing("story_filler", {}, None) == ["filler"] and layouts.missing("story_filler", {}, "x.mp4") == []
    g = layouts.graph("story_filler", {}, 540, 960, 25.0, filler_idx=1)
    assert "[0:v]" not in g and "[1:v]" in g and g.endswith("[base]")
    g2 = layouts.graph("story_card", {}, 540, 960, 25.0)
    assert g2.count("[base]") == 1 and "null[base]" in g2


def _fake_frames(n, with_cam=True, jitter=0.01):
    import numpy as np
    out = []
    for k in range(n):
        fr = np.full((360, 640, 3), 60, np.uint8)
        fr[::7, :] = 120 + (k * 9) % 100  # busy "game"
        if with_cam:
            fr[250:360, 0:160] = 200  # a bright rectangle in the bottom-left: the webcam
        out.append(fr)
    return out


def test_webcam_detection_clusters_small_persistent_faces_and_ignores_the_main_subject():
    from clipper import webcam
    pytest.importorskip("cv2")
    frames = _fake_frames(10)
    it = iter(range(100))
    grab = lambda src, t, w, h: frames[next(it) % 10]
    import numpy as _np
    small = lambda fr: [{"cx": 0.12 + 0.002 * (hash(fr.tobytes()[:50]) % 3), "cy": 0.84, "size": 0.01, "box": tuple(_np.float32(v) for v in (0.07, 0.76, 0.10, 0.16))}, {"cx": 0.6, "cy": 0.5, "size": 0.3, "box": (0.4, 0.2, 0.4, 0.6)}]
    info = {"width": 1920, "height": 1080, "duration": 100.0}
    r = webcam.detect("x.mp4", info, detect_fn=small, grab=grab)
    import json as _j
    _j.dumps(r)  # must be plain JSON types (a numpy float32 here crashed `clipper layout` on real footage)
    assert r and r["frames"] == 10 and r["hits"] == 10 and 0.0 <= r["box"][0] <= 0.02 and r["box"][1] > 0.6 and r["box"][0] + r["box"][2] <= 1.0 and r["confidence"] == 1.0
    it2 = iter(range(100))
    only_big = lambda fr: [{"cx": 0.5, "cy": 0.5, "size": 0.3, "box": (0.3, 0.2, 0.4, 0.6)}]
    assert webcam.detect("x.mp4", info, detect_fn=only_big, grab=lambda *a: frames[next(it2) % 10]) is None, "the main subject is not a webcam"
    flicker = iter(range(100))
    seen = lambda fr: [{"cx": 0.1, "cy": 0.8, "size": 0.01, "box": (0.05, 0.75, 0.1, 0.1)}] if next(flicker) % 5 == 0 else []
    assert webcam.detect("x.mp4", info, detect_fn=seen, grab=lambda *a: frames[0]) is None, "a face seen in 2 of 10 frames is not a webcam"
    assert webcam.detect("x.mp4", {"width": 0, "height": 0, "duration": 0}, detect_fn=small, grab=grab) is None


def test_emoji_images_are_high_resolution():
    Image = pytest.importorskip("PIL.Image")
    sizes = {Image.open(f).size for f in captions.EMOJI_DIR.glob("*.png")}
    assert sizes == {(256, 256)}, sizes


def test_effective_style_resolves_auto_everywhere_a_name_becomes_a_preset():
    assert captions.effective_style("auto", "gaming", {}) == "gaming_bold" and captions.effective_style(None, "podcast", {}) == captions.auto_style("podcast", {})
    assert captions.effective_style("karaoke", "gaming", {}) == "karaoke" and captions.effective_style("none", "gaming", {}) == "none"
    for n in ("auto", None):
        assert captions.style(captions.effective_style(n, "irl", {}))


def test_download_never_mistakes_an_unmerged_video_only_stream_for_the_source(tmp_path, monkeypatch):
    """Regression (real YouTube): yt-dlp could not find ffmpeg, left source.f399.mp4 (video only) + source.f258.m4a, and clipper used the video-only file."""
    from clipper import ingest
    d = tmp_path / "m"
    seen = {}

    def fake(cmd, **kw):
        seen["cmd"] = cmd
        d.mkdir(exist_ok=True)
        (d / "source.f399.mp4").write_bytes(b"v")
        (d / "source.f258.m4a").write_bytes(b"a")
        return type("R", (), {"returncode": 0, "stderr": "", "stdout": ""})()
    monkeypatch.setattr(ingest, "run", fake)
    monkeypatch.setattr(ingest, "ffmpeg", lambda: "/opt/ff/ffmpeg")
    with pytest.raises(RuntimeError, match="unmerged"):
        ingest.download("https://www.youtube.com/watch?v=x", d)
    assert "--ffmpeg-location" in seen["cmd"] and "/opt/ff/ffmpeg" in seen["cmd"]
    assert ingest._merged(d) is None, "a leftover fragment is not a source, and must not be 'resumed'"
    (d / "source.mp4").write_bytes(b"merged")
    assert ingest._merged(d).name == "source.mp4" and ingest.download("https://www.youtube.com/watch?v=x", d).name == "source.mp4"
    (d / "source.live_chat.json").write_text("{}")
    assert ingest._merged(d).name == "source.mp4"


def test_ytdlp_command_falls_back_to_python_m_yt_dlp_and_js_runtime_flag_is_chosen(monkeypatch):
    from clipper import ingest
    monkeypatch.setattr(ingest.shutil, "which", lambda n: "/usr/bin/yt-dlp" if n == "yt-dlp" else None)
    assert ingest.ytdlp() == ["yt-dlp"]
    monkeypatch.setattr(ingest.shutil, "which", lambda n: None)
    assert ingest.ytdlp()[-2:] == ["-m", "yt_dlp"] or ingest.ytdlp() is None
    monkeypatch.setattr(ingest.shutil, "which", lambda n: "/x/node" if n == "node" else None)
    assert ingest._js_runtime() == ["--js-runtimes", "node"]
    monkeypatch.setattr(ingest.shutil, "which", lambda n: None)
    assert ingest._js_runtime() == []


def test_webcam_detection_without_opencv_reports_and_returns_none_instead_of_crashing():
    """Regression (real YouTube run on a machine without opencv): `clipper layout JOB N` crashed with ModuleNotFoundError: cv2."""
    from clipper import webcam
    pytest.importorskip("numpy")
    def no_cv2(fr):
        raise ModuleNotFoundError("No module named 'cv2'")
    assert webcam.detect("x.mp4", {"width": 1920, "height": 1080, "duration": 60.0}, detect_fn=no_cv2, grab=lambda *a: _fake_frames(1)[0]) is None
    assert "webcam detection" in json.dumps(util.skipped())
